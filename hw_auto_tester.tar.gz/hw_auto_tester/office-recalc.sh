#!/bin/bash


# for MacOS: Path to python binary inside Libreoffice 
# export PATH=/Applications/LibreOffice.app/Contents/Resources:$PATH

EXCEL_FILE="${1}"


# Run libreoffice in bg
#libreoffice --nologo --norestore -accept="socket,host=localhost,port=2002;urp;" "${EXCEL_FILE}" &
soffice --accept="socket,host=localhost,port=2002;urp;" --norestore --nologo --nodefault &# --headless
sleep 3

# Focus on window and send CTRL+S keys
python3 ./office-recalc.py "${EXCEL_FILE}"
sleep 3

# Killing libre gracefully (xdotool killing with X errors)
#echo "Killing window"
#pkill "soffice.bin"

sleep 1
echo "File saved"

