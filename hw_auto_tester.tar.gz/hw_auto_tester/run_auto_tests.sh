#!/bin/bash 

python3 -u ./smart_rack_5_5.py --debug