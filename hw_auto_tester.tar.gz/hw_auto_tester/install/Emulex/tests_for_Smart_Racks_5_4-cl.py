import os
import openpyxl
from datetime import datetime
import subprocess
import time
START_ALL_TESTS = "1"
START_BMS_TEST = "2" 
START_ID_COMMON_TEST = "3"
START_ID_CPU_TEST = "4"
START_ID_DISCS_TEST = "5"
START_ID_MEMORY_TEST = "6"
START_ID_ETHERNET_TEST = "7"
START_SHORT_LOAD_TEST = "8"
OUT_CHOICE = "*"
FOLDER_FOR_TEST_REPORTS = 'Smatr_Rack_test_reports'
FOLDER_FOR_MOUNT_USB = 'MOUNT_USB'
FOLDER_FOR_UPDATE = 'Copy_to_home'
FOLDER_FOR_MOUNT = "Reports"
CONF_1_2U2N = "ACH2120A-23001" 
CONF_1_2U1N = "ACH1120C-23001" 
CONF_2_2U1N = "ACH1120C-23002" 
def main():                 
    choice = "1"
    if not os.path.exists(FOLDER_FOR_TEST_REPORTS):
        os.makedirs(FOLDER_FOR_TEST_REPORTS)
    name_date_sample_xlsx_file = find_xlsx()
    print("V 5.2")
    print ("Uploaded a file to work :\n", name_date_sample_xlsx_file[0], 
           'The date of last changes:', name_date_sample_xlsx_file[1], "\n")
    while choice != OUT_CHOICE: 
        logs_data_bmc         = None
        logs_data_id_common   = None
        logs_data_id_cpu      = None
        logs_data_id_discs    = None
        logs_data_id_memory   = None
        logs_data_id_ethernet = None        
        logs_data_load        = None
        if choice == START_ALL_TESTS:  
            print("Start tests step by step")
            logs_data_bmc = bmc_tests()
            logs_data_id_common   = id_common_tests()
            logs_data_id_cpu      = id_cpu_tests()
            logs_data_id_discs    = id_discs_tests()
            logs_data_id_memory   = id_memory_tests()
            logs_data_id_ethernet = id_ethernet_tests()
            logs_data_load        = load_tests()
            pass_to_log_file = save_log_xsls(logs_data_bmc, logs_data_id_common, logs_data_id_cpu, logs_data_id_discs, 
                          logs_data_id_memory, logs_data_id_ethernet, logs_data_load)
        elif choice == START_BMS_TEST: 
            logs_data_bmc = bmc_tests()
            pass_to_log_file = save_log_xsls(logs_data_bmc, logs_data_id_common, logs_data_id_cpu, logs_data_id_discs, 
                          logs_data_id_memory, logs_data_id_ethernet, logs_data_load)
        elif choice == START_ID_COMMON_TEST: 
            logs_data_id_common = id_common_tests()
            pass_to_log_file = save_log_xsls(logs_data_bmc, logs_data_id_common, logs_data_id_cpu, logs_data_id_discs, 
                          logs_data_id_memory, logs_data_id_ethernet, logs_data_load)
        elif choice == START_ID_CPU_TEST: 
            logs_data_id_cpu = id_cpu_tests()
            pass_to_log_file = save_log_xsls(logs_data_bmc, logs_data_id_common, logs_data_id_cpu, logs_data_id_discs, 
                          logs_data_id_memory, logs_data_id_ethernet, logs_data_load)
        elif choice == START_ID_DISCS_TEST: 
            logs_data_id_discs = id_discs_tests()
            pass_to_log_file = save_log_xsls(logs_data_bmc, logs_data_id_common, logs_data_id_cpu, logs_data_id_discs, 
                          logs_data_id_memory, logs_data_id_ethernet, logs_data_load)
        elif choice == START_ID_MEMORY_TEST: 
            logs_data_id_memory = id_memory_tests()
            pass_to_log_file = save_log_xsls(logs_data_bmc, logs_data_id_common, logs_data_id_cpu, logs_data_id_discs, 
                          logs_data_id_memory, logs_data_id_ethernet, logs_data_load)
        elif choice == START_ID_ETHERNET_TEST: 
            logs_data_id_ethernet = id_ethernet_tests()
            pass_to_log_file = save_log_xsls(logs_data_bmc, logs_data_id_common, logs_data_id_cpu, logs_data_id_discs, 
                          logs_data_id_memory, logs_data_id_ethernet, logs_data_load)
        elif choice == START_SHORT_LOAD_TEST: 
            logs_data_load = load_tests()
            pass_to_log_file = save_log_xsls(logs_data_bmc, logs_data_id_common, logs_data_id_cpu, logs_data_id_discs, 
                          logs_data_id_memory, logs_data_id_ethernet, logs_data_load)
        elif choice == OUT_CHOICE: 
            pass
        else:
            print("You entered an incorrect value.")
        pass_to_past_folder = copy_and_past_to_usb_disc(pass_to_log_file)
        errors = open_and_chek_errors_in_exel(pass_to_log_file)
        check_update_scripts (pass_to_log_file, pass_to_past_folder)
        "Uncoment line below for manual checing"
        if  errors > 0:
            time.sleep (30)
            tern_off_server()
        tern_off_server()
    print ("The work of the program is completed.")
    input('Press Ctrl+Shift+Q to close Terminal Linux.\n')
    exit()    
def display_maim_menu():    
    print ('\n','Menu:')
    print ('1. Collect all the data, run a short load test and create a report.')
    print ('2. Collect data only from BMC and create a report.')
    print ('3. Collect commodity data and create a report.')
    print ('4. Collect CPUs data and create a report.')    
    print ('5. Collect data about discs and create a report.')    
    print ('6. Collect memory data and create a report.') 
    print ('7. Collect data about ethernet devices create a report.') 
    print ('8. Run a short load test and create a report')    
    print ('*. Exit the program.')
    print('Press Ctrl+Shift+Q to close Terminal Linux.\n')
    return input('Select a menu item...\n ')
def bmc_tests():            
    print("Start BMC test.")
    logs_data_bmc = []
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'mc', "info"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    logs_data_bmc.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'getsysinfo', "system_fw_version"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    logs_data_bmc.append(log_ipmitool_decode)    
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sdr'], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    logs_data_bmc.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor'], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    logs_data_bmc.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'fru'], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    logs_data_bmc.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'dcmi', "sensors"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    logs_data_bmc.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'dcmi', "get_temp_reading"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    logs_data_bmc.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'dcmi', "get_mc_id_string"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    logs_data_bmc.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'nm', "alert", "get"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    logs_data_bmc.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'lan', "print"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    logs_data_bmc.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'chassis', "identify", "255"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    logs_data_bmc.append(log_ipmitool_decode)
    print('\nCheck the flashing of the blue LED on the front panel. LED will be blinling about 4,5 minuets.\n')
    logs_data_bmc_str = ''.join(logs_data_bmc)
    logs_data_bmc_str_separeted = logs_data_bmc_str.splitlines()    
    return logs_data_bmc_str_separeted
def id_common_tests():      
    print("Start reading data from commodity.", "\n")
    logs_id_common = []
    log_inxi = subprocess.run(["sudo", 'inxi', '-Fx'], capture_output=True)
    logs_inxi = log_inxi.stdout.decode()
    logs_id_common.append(logs_inxi)    
    logs_id_common_str = ''.join(logs_id_common)
    logs_id_common_separeted = logs_id_common_str.splitlines()    
    return logs_id_common_separeted
def id_cpu_tests():         
    print("Start reading data from CPU.")
    logs_id_cpu = []
    log_lscpu = subprocess.run(["sudo", 'lscpu'], capture_output=True)
    logs_lscpu_decode = log_lscpu.stdout.decode()
    logs_id_cpu.append(logs_lscpu_decode)    
    logs_id_cpu_str = ''.join(logs_id_cpu)
    logs_id_cpu_separeted = logs_id_cpu_str.splitlines()
    return logs_id_cpu_separeted
def id_discs_tests():       
    print("Start reading data from discs.")
    logs_id_discs = []
    log_smartctl = subprocess.run(["sudo", "mdadm", '--detail', '--scan', "--verbose"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", "mdadm", '-D', '/dev/md125'], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", "mdadm", '-D', '/dev/md126'], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", "mdadm", '-D', '/dev/md127'], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["lsblk"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '--scan'], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sda"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sdb"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sdc"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sdd"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sde"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sdf"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sdg"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sdh"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sdi"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sdj"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sdk"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sdl"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sdm"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sdn"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sdo"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sdp"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sdq"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sdr"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sds"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sdt"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sdu"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sdv"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sdw"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sdx"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sdy"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/sdz"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/nvme0"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/nvme1"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/nvme2"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/nvme3"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/nvme4"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/nvme5"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/nvme6"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/nvme7"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/nvme8"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/nvme9"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/nvme10"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/nvme11"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/nvme12"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/nvme13"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/nvme14"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    log_smartctl = subprocess.run(["sudo", 'smartctl', '-a', "/dev/nvme15"], capture_output=True)
    log_smartctl_decode = log_smartctl.stdout.decode()
    logs_id_discs.append(log_smartctl_decode)
    logs_id_discs_str = ''.join(logs_id_discs)
    logs_id_discs_str_separeted = logs_id_discs_str.splitlines()    
    return logs_id_discs_str_separeted
def id_memory_tests():      
    print("Start reading data from DIMM memory.")
    logs_id_memory = []
    log_dmidecode = subprocess.run(["sudo", 'dmidecode', '-t', 'memory'], capture_output=True)
    log_dmidecode_decode = log_dmidecode.stdout.decode()
    logs_id_memory.append(log_dmidecode_decode)
    logs_id_memory_str = ''.join(logs_id_memory)
    logs_id_memory_str_separeted = logs_id_memory_str.splitlines()
    return logs_id_memory_str_separeted
def id_ethernet_tests():    
    print("Start reading data from pci ethernet cards.")
    logs_id_ethernet = []
    log_lspci = subprocess.run(["sudo", 'lspci', '-v', '–mm', '-nn'], capture_output=True)
    log_lspci_decode = log_lspci.stdout.decode()
    logs_id_ethernet.append(log_lspci_decode)
    log_ip = subprocess.run(["sudo", 'ip', 'address'], capture_output=True)
    log_ip_decode = log_ip.stdout.decode()
    logs_id_ethernet.append(log_ip_decode)
    logs_id_ethernet_str = ''.join(logs_id_ethernet)
    logs_id_ethernet_separeted = logs_id_ethernet_str.splitlines()
    return logs_id_ethernet_separeted
def load_tests():           
    print("Start load tests 15m.")
    logs_load_tests = []
    load_tests_data_separeted = []
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN1_TACH0"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN1_TACH1"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN2_TACH0"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN2_TACH1"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN3_TACH0"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN3_TACH1"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN4_TACH0"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN4_TACH1"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN5_TACH0"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN5_TACH1"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN6_TACH0"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN6_TACH1"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN7_TACH0"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN7_TACH1"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    quantity_cpus = subprocess.run(["nproc"], capture_output=True, text=True, encoding='utf-8')
    quantity_cpus_decode = quantity_cpus.stdout
    quantity_cpus_str_separeted = quantity_cpus_decode.splitlines()
    cpus_read = str(quantity_cpus_str_separeted[0])
    load_tests_data = subprocess.run(["sudo", 'stress-ng', '--cpu', cpus_read, "--vm", "1", "--vm-bytes", "80%", "--iomix",
                                       cpus_read, "--metrics-brief", "--timeout", "90s", "--metrics-brief"], capture_output=True, text=True, encoding='utf-8')
    load_tests_decode = load_tests_data.stderr
    logs_load_tests.append(load_tests_decode)
    load_tests_data_str = ''.join(logs_load_tests)
    load_tests_data_separeted = load_tests_data_str.splitlines()
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN1_TACH0"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN1_TACH1"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN2_TACH0"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN2_TACH1"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN3_TACH0"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN3_TACH1"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN4_TACH0"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN4_TACH1"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN5_TACH0"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN5_TACH1"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN6_TACH0"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN6_TACH1"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN7_TACH0"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'sensor', "FAN7_TACH1"], capture_output=True)
    log_ipmitool_decode = log_ipmitool.stdout.decode()
    load_tests_data_separeted.append(log_ipmitool_decode)
    return load_tests_data_separeted
def save_log_xsls(logs_data_bmc, logs_data_id_common, logs_data_id_cpu, logs_data_id_discs, 
                          logs_data_id_memory, logs_data_id_ethernet, logs_data_load): 
    sn_server_full_name = []
    sn_server_clear = []
    print("Save report to a local forder.")
    name_date_sample_xlsx_file = find_xlsx()
    way_to_the_sample_xlsx = name_date_sample_xlsx_file[0]
    all_wokr_book = openpyxl.load_workbook(way_to_the_sample_xlsx)
    all_sheets = all_wokr_book.sheetnames
    if  logs_data_bmc != None:
        all_wokr_book.active = 1
        sheet = all_wokr_book.active    
        for i in range(len(logs_data_bmc)):
            cell_column = "A"
            cell_row = str(i+1)
            cell_offset = str(cell_column +  cell_row)
            data_cell = str(logs_data_bmc[i])
            sheet[cell_offset] = data_cell
    if  logs_data_id_common != None:
        all_wokr_book.active = 2
        sheet = all_wokr_book.active
        for i in range(len(logs_data_id_common)):
            cell_column = "A"
            cell_row = str(i+1)
            cell_offset = str(cell_column +  cell_row)
            data_cell = str(logs_data_id_common[i])
            sheet[cell_offset] = data_cell
    if  logs_data_id_cpu != None:
        all_wokr_book.active = 3
        sheet = all_wokr_book.active
        for i in range(len(logs_data_id_cpu)):
            cell_column = "A"
            cell_row = str(i+1)
            cell_offset = str(cell_column +  cell_row)
            data_cell = str(logs_data_id_cpu[i])
            sheet[cell_offset] = data_cell
    if  logs_data_id_discs != None:
        all_wokr_book.active = 4
        sheet = all_wokr_book.active
        for i in range(len(logs_data_id_discs)):
            cell_column = "A"
            cell_row = str(i+1)
            cell_offset = str(cell_column +  cell_row)
            data_cell = str(logs_data_id_discs[i])
            sheet[cell_offset] = data_cell
    if  logs_data_id_memory != None:
        all_wokr_book.active = 5
        sheet = all_wokr_book.active
        for i in range(len(logs_data_id_memory)):
            cell_column = "A"
            cell_row = str(i+1)
            cell_offset = str(cell_column +  cell_row)
            data_cell = str(logs_data_id_memory[i])
            sheet[cell_offset] = data_cell
    if  logs_data_id_ethernet != None:
        all_wokr_book.active = 6
        sheet = all_wokr_book.active
        for i in range(len(logs_data_id_ethernet)):
            cell_column = "A"
            cell_row = str(i+1)
            cell_offset = str(cell_column +  cell_row)
            data_cell = str(logs_data_id_ethernet[i])
            sheet[cell_offset] = data_cell
    if  logs_data_load != None:
        all_wokr_book.active = 7
        sheet = all_wokr_book.active
        for i in range(len(logs_data_load)):
            cell_column = "A"
            cell_row = str(i+1)
            cell_offset = str(cell_column +  cell_row)
            data_cell = str(logs_data_load[i])
            sheet[cell_offset] = data_cell
    current_dir = os.getcwd()
    current_datetime = datetime.now()
    current_datetime_readeble = current_datetime.strftime('%d.%m.%Y_%H-%M')
    if  logs_data_bmc != None:
        sn_server_all_info = id_common_tests()
        if len(sn_server_all_info) > 1 :
            sn_server_full_name.append(sn_server_all_info[5])
            sn_server_str = ''.join(sn_server_full_name)
            sn_server_split = sn_server_str.split(":", 1)
            sn_server_clear.append(sn_server_split[1])
            sn_server_clear_str = ''.join(sn_server_clear)
            sn_server = sn_server_clear_str.replace(' ', '')
    else:
        sn_server = input("Enter the sample number... ")
    name_new_log_file = ("Test_report_Smart_Rack_№" + sn_server + '_' + current_datetime_readeble + '.xlsx')
    new_log_file = os.path.join(current_dir, FOLDER_FOR_TEST_REPORTS, name_new_log_file)
    all_wokr_book.active = 0
    all_wokr_book.save(new_log_file)
    subprocess.run(["sudo", '/home/ubuntu/excel-recalc.sh', new_log_file])  
    return new_log_file
def copy_and_past_to_usb_disc(pass_to_log_file):    
    print("\nStart copy folders.")
    print("Tern on led = I am ready for copy logs.", 
            "I`m wating for plug in USB disc...", "\n")
    all_disc = []
    all_disc_and_usb = []
    path_to_usb = []
    all_disc_and_usb_source = []
    all_disc_and_usb_target = []
    pass_to_mount_folder = os.path.join(os.getcwd(), FOLDER_FOR_MOUNT)
    while len(all_disc) != len(all_disc_and_usb)-1 :
        all_disc.clear()
        all_disc_and_usb.clear()
        list_dics = subprocess.run(["df", '--output=source,target'], capture_output=True)
        list_dics_decode = list_dics.stdout.decode()
        list_dics_decode_str = ''.join(list_dics_decode)
        all_disc = list_dics_decode_str.splitlines()
        log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'chassis', "identify", "10"], capture_output=True)
        if not os.path.exists(pass_to_mount_folder):
            os.makedirs(pass_to_mount_folder)
        subprocess.run(["sudo", 'mount', "/dev/sdb1", pass_to_mount_folder], capture_output=True)
        time.sleep (2)
        list_dics_and_usb = subprocess.run(["df", '--output=source,target'], capture_output=True)
        list_dics_and_usb_decode = list_dics_and_usb.stdout.decode()
        list_dics_and_usb_decode_str = ''.join(list_dics_and_usb_decode)
        all_disc_and_usb = list_dics_and_usb_decode_str.splitlines()
    path_to_usb = list(set(all_disc_and_usb) - set(all_disc))
    path_to_usb_str = "".join(path_to_usb)
    list_dics_and_usb_split = path_to_usb_str.split(" ", 1)
    all_disc_and_usb_source.append(list_dics_and_usb_split[0])
    all_disc_and_usb_target.append(list_dics_and_usb_split[1])
    all_disc_and_usb_target_str = ''.join(all_disc_and_usb_target)
    path_to_usb_clear = all_disc_and_usb_target_str.replace(' ', '')
    if not os.path.exists(path_to_usb_clear):
        os.makedirs(pass_to_mount_folder)
        z = subprocess.run(["sudo", 'mount', all_disc_and_usb_source, FOLDER_FOR_MOUNT_USB], capture_output=True)
        copy_folder = os.path.join(os.getcwd(), FOLDER_FOR_TEST_REPORTS, ".")
        past_folder = os.path.join(FOLDER_FOR_MOUNT_USB, FOLDER_FOR_TEST_REPORTS)
        print ("Usb was founded and mounted to: ", past_folder)
        print(subprocess.run(['cp', "-a", copy_folder, past_folder], capture_output=True))
    else:
        copy_folder = os.path.join(os.getcwd(), FOLDER_FOR_TEST_REPORTS, ".")
        past_folder = os.path.join(path_to_usb_clear, FOLDER_FOR_TEST_REPORTS)
        print ("Usb was founded: ", past_folder)
        print(subprocess.run(['cp', "-a", copy_folder, past_folder], capture_output=True))
    print ("Copy folder: ", copy_folder)
    print ("Past folder: ", past_folder)
    basename_log_file = os.path.basename(pass_to_log_file)
    past_folder_basename_log_file = os.path.join(past_folder, basename_log_file)
    if not os.path.exists(past_folder_basename_log_file):
        print("Houston we have problems! I can`t find reports on your USB disc.", "\n" "Do it yousef I can`t.", "\n")
        time.sleep (10)
    else:
        log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'chassis', "identify", "0"], capture_output=True)
        print("Tern off led = copy finished.", "\n")
    return past_folder
def open_and_chek_errors_in_exel (pass_to_log_file):
    time.sleep (10)
    all_wokr_book = openpyxl.load_workbook(pass_to_log_file, data_only=True)
    all_sheets = all_wokr_book.sheetnames
    all_wokr_book.active = 0
    sheet = all_wokr_book.active
    print ("Uploaded a file to analis :\n", pass_to_log_file)
    print("Errors =", sheet['G3'].value)
    errors = int(sheet['G3'].value)
    if  errors > 0 :
        subprocess.run(["sudo", 'ipmitool', 'chassis', "identify", "255"])
        print('We hawe some problems. \nLED will be blinling about 4 minutes.', "\n")
    return errors
def tern_off_server():
    print("Serwer will be tern off in 10 secons, press to stop prosess:", "\n" "Ctrl+Shift+Q", "\n")
    subprocess.run(["sudo", 'shutdown', '-h', "now"])
def check_update_scripts (pass_to_log_file, pass_to_past_folder):
    full_path_to_update = os.path.join(pass_to_past_folder, FOLDER_FOR_UPDATE)
    past_folder = os.getcwd()
    if os.path.exists(full_path_to_update):
        print ("Find updates in folder:", full_path_to_update)
        list_files_for_update = os.listdir(full_path_to_update)
        print ("List of files:", list_files_for_update,"\n")
        for i in range(len(list_files_for_update)):
            full_path_to_new_file = os.path.join(full_path_to_update, list_files_for_update[i])
            print(subprocess.run(['cp', "-a", full_path_to_new_file, past_folder], capture_output=True), "\n")
    print("List of updated files:", os.listdir(past_folder))
def find_xlsx():    
    all_XLSX = []
    full_path_all_XLSX = []
    sn_server_full_name = []
    sn_server_clear = []
    conf_server_pn_mb = []
    conf_server = []
    conf_server_clear = []
    conf_server_pn_mb_common = []    
    all_XLSX_2u1n_conf_1 =[]
    all_XLSX_2u1n_conf_2 = []
    all_XLSX_2u2n_conf_1 = []
    name_xlsx_file = None
    current_dir = os.getcwd()
    list_files = os.listdir(current_dir)
    for i in range(len(list_files)):
        file_i = list_files[i]        
        file_name = file_i[:17]
        file_extension = file_i[-5:]
        if file_extension == ".xlsx":
            if file_name == 'sample_CN1N_conf1':
                all_XLSX_2u1n_conf_1.append(list_files[i])
            elif file_name == 'sample_CN1N_conf2':
                all_XLSX_2u1n_conf_2.append(list_files[i])
            elif file_name == 'sample_CN2N_conf1':
                all_XLSX_2u2n_conf_1.append(list_files[i])
            else:
                all_XLSX.append(list_files[i])
    conf_server_pn_mb = subprocess.run(["sudo", 'ipmitool', 'fru', "print", "1"], capture_output=True)
    conf_server_pn_mb_decode = conf_server_pn_mb.stdout.decode()
    conf_server_pn_mb_common.append(conf_server_pn_mb_decode)    
    conf_server_pn_mb_common_str = ''.join(conf_server_pn_mb_common)
    conf_server_pn_mb_separeted = conf_server_pn_mb_common_str.splitlines()
    if len(conf_server_pn_mb_separeted) > 1 :
        conf_server.append(conf_server_pn_mb_separeted[10])
        conf_server_str = ''.join(conf_server)
        conf_server_split = conf_server_str.split(":", 1)
        conf_server_clear.append(conf_server_split[1])
        conf_server_clear_str = ''.join(conf_server_clear)
        pn_server = conf_server_clear_str.replace(' ', '')
        print('PN server:', pn_server)
        if pn_server.find(CONF_1_2U1N) != -1:
            all_XLSX = all_XLSX_2u1n_conf_1
        elif pn_server.find(CONF_2_2U1N) != -1:
            all_XLSX = all_XLSX_2u1n_conf_2
        elif pn_server.find(CONF_1_2U2N) != -1:
            all_XLSX = all_XLSX_2u2n_conf_1
        else:
            pass
    if len(all_XLSX) != 0:          
        for i in range(len(all_XLSX)):
            full_path = os.path.join(current_dir, all_XLSX[i])
            full_path_all_XLSX.append(full_path)
        name_xlsx_file = max(full_path_all_XLSX, key=os.path.getctime)
        time_last_changes = datetime.fromtimestamp(os.path.getctime(name_xlsx_file))
        time_last_changes_readeble = time_last_changes.strftime('%d.%m.%Y %H:%M')
        return name_xlsx_file, time_last_changes_readeble
    else :
        print ("Working folder is: \n", current_dir)
        print ("File with extension .xlsx and the title *sample* not found! \n")
        input ("Press any key to exit")
        exit()
if __name__ == "__main__":
    main()
