#!/bin/bash


EXCEL_FILE="${1}"

# Run libreoffice in bg
libreoffice --nologo --norestore "${EXCEL_FILE}" &

sleep 10 # waitng libreoffice opens file and recalc formulas
# Find window with name caontaining "Smart_Rack"
EXCEL_WINDOW=$(xdotool search --name 'Smart_Rack')
echo "EXCEL_WINDOW: ${EXCEL_WINDOW}"

# Focus on window and send CTRL+S keys
echo "Saving file"
xdotool windowactivate "$EXCEL_WINDOW" && xdotool key --window "$EXCEL_WINDOW" ctrl+s
sleep 3

# Killing libre gracefully (xdotool killing with X errors)
echo "Killing window"
pkill "soffice.bin"

sleep 1
echo "File saved"
