/*************************************************************************
 * Broadcom Inc. Copyright (c) 2020 Broadcom.
 * All Rights Reserved.
 * The term "Broadcom" refers to Broadcom Inc. and/or its subsidiaries.
 *************************************************************************/
// File: elxsli_hba.h

#ifndef H_ELXSLI_HBA
#define H_ELXSLI_HBA

typedef enum {
    BYTE_WIDTH = 1,
    WORD_WIDTH = 2,
    DWORD_WIDTH = 4,

} DATA_WIDTHS;

static inline int
elxsli_readl(void __iomem *addr, u32 *data)
{
    u32 temp;
    temp = ioread32(addr);
    if (temp == 0xffffffff)
        return -EIO;
    *data = temp;
    return 0;
}

/* printk kernel log levels as defined in include/linux/kern_levels.h  */
//#define KERN_EMERG    "0"     /* system is unusable */
//#define KERN_ALERT    "1"     /* action must be taken immediately */
//#define KERN_CRIT     "2"     /* critical conditions */
//#define KERN_ERR      "3"     /* error conditions */
//#define KERN_WARNING  "4"     /* warning conditions (DEFAULT LEVEL) */
//#define KERN_NOTICE   "5"     /* normal but significant condition */
//#define KERN_INFO     "6"     /* informational */
//#define KERN_DEBUG    "7"     /* debug-level messages */
//#define KERN_DEFAULT  "d"     /* the default kernel loglevel */

/* Linux Logging Macros */
//#define ELXSLI_DEBUG 1 /* COMMENT LINE FOR RELEASE */
//#define ELXSLI_DEBUG_MBOX 1  /* COMMENT LINE FOR RELEASE */

#ifdef ELXSLI_DEBUG
#define PRINT_HEX_DUMP_BYTES(ptr, size) \
do { \
        { print_hex_dump(KERN_INFO,  "", \
        DUMP_PREFIX_ADDRESS, 16, 1, ptr, size, 1); } \
} while (0)

#define PRINT_HEX_DUMP_DWORDS(ptr, size) \
do { \
        { print_hex_dump(KERN_INFO,  "", DUMP_PREFIX_ADDRESS, \
        4, 4, ptr, size, 0); } \
} while (0)

#define DEBUG_LINE()        \
    printk(KERN_INFO ELXSLI_DRIVER_NAME": func: %s @ line %d \n", \
    __FUNCTION__,__LINE__)
#define PRINT_DEBUG_ENTRY() \
    printk(KERN_INFO ELXSLI_DRIVER_NAME": %s *** >>> ENTRY ***\n", \
    __FUNCTION__)
#define PRINT_DEBUG_EXIT()  \
    printk(KERN_INFO ELXSLI_DRIVER_NAME": %s *** <<< EXIT ***\n", \
    __FUNCTION__)
#define PRINTK_DBG(fmt, arg...)  \
do { \
    printk(KERN_DEBUG fmt, ##arg); \
} while (0)
#define PRINT_DEBUG_LOG(phba, fmt, arg...) \
do { \
    dev_printk(KERN_INFO, &(phba->pcidev)->dev, \
    ELXSLI_DRIVER_NAME"-%d: %s: " fmt, phba->brd_number, \
    __FUNCTION__, ##arg); \
} while (0)

#ifdef ELXSLI_DEBUG_MBOX
#define PRINT_MBX_DEBUG_LOG(phba, fmt, arg...) \
do { \
    dev_printk(KERN_ERR, &(phba->pcidev)->dev, \
    ELXSLI_DRIVER_NAME"-%d: %s: " fmt, phba->brd_number, \
    __FUNCTION__, ##arg); \
} while (0)
#else
#define PRINT_MBX_DEBUG_LOG(phba, fmt, arg...)
#endif

#else

#define PRINT_HEX_DUMP_BYTES(ptr, size)
#define PRINT_HEX_DUMP_DWORDS(ptr, size)
#define DEBUG_LINE()
#define PRINT_DEBUG_ENTRY()
#define PRINT_DEBUG_EXIT()
#define PRINT_DEBUG_LOG(phba, fmt, arg...)
#define PRINTK_DBG(fmt, arg...)
#define PRINT_MBX_DEBUG_LOG(phba, fmt, arg...)

#endif

#define PRINT_DEV_MSG(pcidev, level, fmt, arg...) \
do { \
    dev_printk(level, &pcidev->dev, ELXSLI_DRIVER_NAME" " fmt, ##arg); \
} while (0)

#define PRINT_LOG_MSG(phba, level, fmt, arg...) \
do { \
    dev_printk(level, &(phba->pcidev)->dev, ELXSLI_DRIVER_NAME"-%d: " fmt, \
    phba->brd_number, ##arg); \
} while (0)


/* PCI Config BAR register offsets */
#define ELXSLI_PCI_VENDOR               0x0000
#define ELXSLI_PCI_DEVICE               0x0002
#define ELXSLI_PCI_CACHE_LINE           0x000c
#define ELXSLI_PCI_SUB_VENDOR           0x002c
#define ELXSLI_PCI_SUB_SYSTEM           0x002e
#define ELXSLI_PCI_SLI_INTF             0x0058
#define ELXSLI_PCI_SOFT_RESET           0x005c

/* Define SLI4 Alignment requirements. */
#define ELXSLI_ALIGN_16_BYTE            16
#define ELXSLI_ALIGN_64_BYTE            64

/* Memory allocation related defines */
#define KMALLOC_PAGE_SIZE               4096
#define ELXSLI_KMALLOC_MAX_ALLOC_SIZE   (KMALLOC_PAGE_SIZE * 16) /* 64K */
#define ELXSLI_MEM_ALLOC_SIZE           4096

typedef struct _elxsli_register_t
{
    u32 dw;

} elxsli_register_t;

typedef union _bmbx_reg_t
{
    struct {
        u32 ready        : 1;
        u32 high_order   : 1;
        u32 address      : 30;
    } bits;

    u32 dw;

} bmbx_reg_t;

/* SLI4 interface register (Lancer G5 sli_family & if_type are swapped) */
typedef union _sli_intf_reg_t
{
    struct
    {
        u32 ft          : 1;
        u32 rsvd        : 3;
        u32 sli_rev     : 4;
        u32 sli_family  : 4;
        u32 if_type     : 4;
        u32 sli_hint1   : 8;
        u32 sli_hint2   : 5;
        u32 valid       : 3;
    } bits;

    u32 dw;

} sli_intf_reg_t;

#define SLI_INTF_VALID                  6
#define SLI_INTF_SLI_HINT2_NONE         0
#define SLI_INTF_SLI_HINT1_NONE         0
#define SLI_INTF_SLI_HINT1_1            1
#define SLI_INTF_SLI_HINT1_2            2
#define SLI_INTF_IF_TYPE_0              0
#define SLI_INTF_IF_TYPE_1              1
#define SLI_INTF_IF_TYPE_2              2
#define SLI_INTF_IF_TYPE_3              3
#define SLI_INTF_IF_TYPE_4              4
#define SLI_INTF_IF_TYPE_5              5
#define SLI_INTF_IF_TYPE_6              6
#define SLI_INTF_FAMILY_BE2             0x0
#define SLI_INTF_FAMILY_BE3             0x1
#define SLI_INTF_FAMILY_LNCR_A0         0xa
#define SLI_INTF_FAMILY_LNCR_B0         0xb
#define SLI_INTF_REV_SLI3               3
#define SLI_INTF_REV_SLI4               4
#define SLI_INTF_FUNC_TYPE_PHYS         0
#define SLI_INTF_FUNC_TYPE_VIRT         1

typedef union _sli_port_smphr_reg_t
{
    struct
    {
        u32 status          : 16;
        u32 host_scratch    : 8;
        u32 rsvd0           : 2;
        u32 scr2            : 1;
        u32 scr1            : 1;
        u32 ipc             : 1;
        u32 nip             : 1;
        u32 sfi             : 1;
        u32 perr            : 1;
    } bits;
    u32 dw;

} sli_port_smphr_reg_t;

#define ELXSLI_POST_STAGE_POWER_ON_RESET                0x0000
#define ELXSLI_POST_STAGE_AWAITING_HOST_RDY             0x0001
#define ELXSLI_POST_STAGE_HOST_RDY                      0x0002
#define ELXSLI_POST_STAGE_BE_RESET                      0x0003
#define ELXSLI_POST_STAGE_SEEPROM_CS_START              0x0100
#define ELXSLI_POST_STAGE_SEEPROM_CS_DONE               0x0101
#define ELXSLI_POST_STAGE_DDR_CONFIG_START              0x0200
#define ELXSLI_POST_STAGE_DDR_CONFIG_DONE               0x0201
#define ELXSLI_POST_STAGE_DDR_CALIBRATE_START           0x0300
#define ELXSLI_POST_STAGE_DDR_CALIBRATE_DONE            0x0301
#define ELXSLI_POST_STAGE_DDR_TEST_START                0x0400
#define ELXSLI_POST_STAGE_DDR_TEST_DONE                 0x0401
#define ELXSLI_POST_STAGE_REDBOOT_INIT_START            0x0600
#define ELXSLI_POST_STAGE_REDBOOT_INIT_DONE             0x0601
#define ELXSLI_POST_STAGE_FW_IMAGE_LOAD_START           0x0700
#define ELXSLI_POST_STAGE_FW_IMAGE_LOAD_DONE            0x0701
#define ELXSLI_POST_STAGE_ARMFW_START                   0x0800
#define ELXSLI_POST_STAGE_DHCP_QUERY_START              0x0900
#define ELXSLI_POST_STAGE_DHCP_QUERY_DONE               0x0901
#define ELXSLI_POST_STAGE_BOOT_TARGET_DISCOVERY_START   0x0A00
#define ELXSLI_POST_STAGE_BOOT_TARGET_DISCOVERY_DONE    0x0A01
#define ELXSLI_POST_STAGE_RC_OPTION_SET                 0x0B00
#define ELXSLI_POST_STAGE_SWITCH_LINK                   0x0B01
#define ELXSLI_POST_STAGE_SEND_ICDS_MESSAGE             0x0B02
#define ELXSLI_POST_STAGE_PERFROM_TFTP                  0x0B03
#define ELXSLI_POST_STAGE_PARSE_XML                     0x0B04
#define ELXSLI_POST_STAGE_DOWNLOAD_IMAGE                0x0B05
#define ELXSLI_POST_STAGE_FLASH_IMAGE                   0x0B06
#define ELXSLI_POST_STAGE_RC_DONE                       0x0B07
#define ELXSLI_POST_STAGE_REBOOT_SYSTEM                 0x0B08
#define ELXSLI_POST_STAGE_MAC_ADDRESS                   0x0C00
#define ELXSLI_POST_STAGE_PORT_READY                    0xC000
#define ELXSLI_POST_STAGE_PORT_UE                       0xF000

#define ELXSLI_POST_ERROR_TIMEOUT_VALUE                 10

typedef union _sli_port_status_reg_t {
    struct {
        u32 rsvd0    : 22;
        u32 idis     : 1;
        u32 rdy      : 1;
        u32 rn       : 1;
        u32 dip      : 1;
        u32 dl       : 1;
        u32 spp      : 1;
        u32 rsvd1    : 1;
        u32 oti      : 1;
        u32 rsvd2    : 1;
        u32 err      : 1;
    } bits;
    u32 dw;

} sli_port_status_reg_t;

#define MAX_IF_TYPE_2_RESETS  1000

typedef union _sli_port_ctrl_reg_t {

    struct {
        u32 rsvd0   : 22;
        u32 idis    : 1;
        u32 rsvd1   : 4;
        u32 ip      : 1;
        u32 rsvd2   : 3;
        u32 fdd     : 1;
    } bits;
    u32 dw;

} sli_port_ctrl_reg_t;


typedef struct _sli_port_error_reg_t {

    u32 error_word;

} sli_port_error_reg_t;

typedef union _sli_physdev_reg_t
{
    struct {
        u32 drst : 1;
        u32 frst : 1;
        u32 dd   : 1;
        u32 lc   : 1;
        u32 frl  : 4;
        u32 rc   : 3;
        u32 cfp  : 1;
        u32 rsvd0: 1;
        u32 gp   : 1;
        u32 gpc  : 1;
        u32 ipld : 1;
        u32 rsvd1: 14;
        u32 inp  : 1;
        u32 err  : 1;
    } bits;
    u32 dw;

} sli_physdev_reg_t;

#define ELXSLI_SLIPORT_IF0_SMPHR                0x00AC
#define ELXSLI_SLIPORT_IF2_SMPHR                0x0400
#define ELXSLI_SLIPORT_STATUS                   0x0404
#define ELXSLI_SLIPORT_CNTRL                    0x0408
#define ELXSLI_SLIPORT_ERR_1                    0x040C
#define ELXSLI_SLIPORT_ERR_2                    0x0410
#define ELXSLI_PHYSDEV_CTL_OFFSET               0x0414

/* The following BAR0 Registers apply to SLI4 if_type 0 UCNAs. */

#define ELXSLI_UERR_STATUS_LO                   0x00A0
#define ELXSLI_UERR_STATUS_HI                   0x00A4
#define ELXSLI_UE_MASK_LO                       0x00A8
#define ELXSLI_UE_MASK_HI                       0x00AC
#define ELXSLI_UE_ONLINE0                       0x00B0
#define ELXSLI_UE_ONLINE1                       0x00B4

#define ELXSLI_NIC_RQ_DOORBELL                  0x0100
#define ELXSLI_NIC_RQ_DOORBELL2                 0x0180
#define ELXSLI_NIC_WQ_DOORBELL                  0x0060
#define ELXSLI_FC_RQ_DOORBELL                   0x0080
#define ELXSLI_FCoE_RQ_DOORBELL                 0x00A0
#define ELXSLI_FCoE_WQ_DOORBELL                 0x0040
#define ELXSLI_FC_WQ_DOORBELL                   0x0040
#define ELXSLI_CQ_DOORBELL                      0x00C0
#define ELXSLI_EQCQ_DOORBELL                    0x0120
#define ELXSLI_MQ_DOORBELL                      0x0140
#define ELXSLI_MQ6_DOORBELL                     0x0160

#define ELXSLI_BMBX                             0x0160
#define ELXSLI_BMBX_BIT1_ADDR_HI                0x0002
#define ELXSLI_BMBX_BIT1_ADDR_LO                0x0000

#define ELXSLI_SLIPORT_IF2_SMPHR                0x0400
#define ELXSLI_SLIPORT_IF0_SMPHR                0x00AC

#define POST_STAGE_POWER_ON_RESET               0x0000
#define POST_STAGE_AWAITING_HOST_RDY            0x0001
#define POST_STAGE_HOST_RDY                     0x0002
#define POST_STAGE_BE_RESET                     0x0003
#define POST_STAGE_SEEPROM_CS_START             0x0100
#define POST_STAGE_SEEPROM_CS_DONE              0x0101
#define POST_STAGE_DDR_CONFIG_START             0x0200
#define POST_STAGE_DDR_CONFIG_DONE              0x0201
#define POST_STAGE_DDR_CALIBRATE_START          0x0300
#define POST_STAGE_DDR_CALIBRATE_DONE           0x0301
#define POST_STAGE_DDR_TEST_START               0x0400
#define POST_STAGE_DDR_TEST_DONE                0x0401
#define POST_STAGE_REDBOOT_INIT_START           0x0600
#define POST_STAGE_REDBOOT_INIT_DONE            0x0601
#define POST_STAGE_FW_IMAGE_LOAD_START          0x0700
#define POST_STAGE_FW_IMAGE_LOAD_DONE           0x0701
#define POST_STAGE_ARMFW_START                  0x0800
#define POST_STAGE_DHCP_QUERY_START             0x0900
#define POST_STAGE_DHCP_QUERY_DONE              0x0901
#define POST_STAGE_BOOT_TARGET_DISCOVERY_START  0x0A00
#define POST_STAGE_BOOT_TARGET_DISCOVERY_DONE   0x0A01
#define POST_STAGE_RC_OPTION_SET                0x0B00
#define POST_STAGE_SWITCH_LINK                  0x0B01
#define POST_STAGE_SEND_ICDS_MESSAGE            0x0B02
#define POST_STAGE_PERFROM_TFTP                 0x0B03
#define POST_STAGE_PARSE_XML                    0x0B04
#define POST_STAGE_DOWNLOAD_IMAGE               0x0B05
#define POST_STAGE_FLASH_IMAGE                  0x0B06
#define POST_STAGE_RC_DONE                      0x0B07
#define POST_STAGE_REBOOT_SYSTEM                0x0B08
#define POST_STAGE_MAC_ADDRESS                  0x0C00
#define POST_STAGE_PORT_READY                   0xC000
#define POST_STAGE_PORT_UE                      0xF000

/* HBA mailbox definitions */
#define HOST_ENDIAN_LOW_WORD0                   0xFF3412FF
#define HOST_ENDIAN_HIGH_WORD1                  0xFF7856FF

/* PCI Configuration Type 0 structure (descriptor) */
#pragma pack(push, 1) /* no padding or alignment for this structure */

typedef struct _pci_cfg_t {

    u16 vendor_id;
    u16 device_id;
    u16 command;
    u16 status;
    u8  revision_id;
    u8  prog_if;
    u8  sub_class;
    u8  base_class;
    u8  cache_size;
    u8  latency_timer;
    u8  header_type;
    u8  bist;
    u32 bar0_base_address;
    u32 bar1_base_address;
    u32 bar2_base_address;
    u32 bar3_base_address;
    u32 bar4_base_address;
    u32 bar5_base_address;
    u32 cardbus_cis_ptr;
    u32 subvendor_id;
    u32 subdevice_id;
    u32 exp_rom_base;
    u8  cap_ptr;
    u8  rsvd[3];
    u32 rsvd1;
    u8  intr_line;
    u8  intr_pin;
    u8  min_grant;
    u8  max_lat;

} pci_cfg_t;

#pragma pack(pop)

#define PCI_CFG_LEN              sizeof(pci_cfg_t)  // 64 bytes
#define PCI_HEADER_LENGTH        64
#define MAX_PCI_CFG_SIZE         256

#define PCI_CFG_SPACE_CMD_REG    0x4

#define PCI_CMD_MEMSPACE_EN      0x02
#define PCI_CMD_BUSMASTER_EN     0x04
#define PCI_CMD_SPEC_CYCLES_EN   0x08
#define PCI_CMD_MWI_EN           0x10
#define PCI_CMD_VGA_SNOOP_EN     0x20
#define PCI_CMD_PARITY_RESPONSE  0x40
#define PCI_CMD_STEPPING_CTRL    0x80
#define PCI_CMD_SERR_EN          0x100

#define PCI_64BIT_BAR0  0
#define PCI_64BIT_BAR2  2
#define PCI_64BIT_BAR4  4

/*
* Define the host's bootstrap mailbox.  This structure contains
* the member attributes needed to create, use, and destroy the
* bootstrap mailbox region.
*
* The macro definitions for the bmbx data structure are defined
* with the register definition.
*/
typedef struct elxsli_bmbx {

    void *virt;
    dma_addr_t phys;
    void *avirt;
    dma_addr_t aphys;
    u32 bmbx_size;
    u32 addr_hi;
    u32 addr_lo;

} elxsli_bmbx_t;

typedef struct elxsli_sli4 {

    void __iomem  *pcicfg_regs_memmap_p;
    void __iomem  *ctrl_regs_memmap_p;
    void __iomem  *diag_regs_memmap_p;
    void __iomem  *drbl_regs_memmap_p;
    void __iomem  *UERRLOregaddr;
    void __iomem  *UERRHIregaddr;
    void __iomem  *UEMASKLOregaddr;
    void __iomem  *UEMASKHIregaddr;
    void __iomem  *UEONLINE0regaddr;
    void __iomem  *UEONLINE1regaddr;
    void __iomem  *STATUSregaddr;
    void __iomem  *CTRLregaddr;
    void __iomem  *ERR1regaddr;
    void __iomem  *ERR2regaddr;
    void __iomem  *RQDBregaddr;
    void __iomem  *NICRQDBregaddr;
    void __iomem  *FCoERQDBregaddr;
    void __iomem  *NICRQDB2regaddr;
    void __iomem  *WQDBregaddr;
    void __iomem  *NICWQDBregaddr;
    void __iomem  *FCoEWQDBregaddr;
    void __iomem  *EQCQDBregaddr;
    void __iomem  *CQDBregaddr;
    void __iomem  *MQDBregaddr;
    void __iomem  *BMBXregaddr;
    void __iomem  *PDEVregaddr;
    void __iomem  *PSMPHRregaddr;

    /* Mailbox activity is single threaded and polled */
    sli_mqe_t     mbox;
    sli_mcqe_t    mbox_cqe;

    elxsli_bmbx_t bmbx;
} elxsli_sli4_t;

typedef struct elxsli_hba {

    elxsli_sli4_t   sli4_hba;
    struct pci_dev  *pcidev;

    unsigned long   pci_bar0_map;
    unsigned long   pci_bar1_map;
    unsigned long   pci_bar2_map;
    unsigned long   pci_bar3_map;
    unsigned long   pci_bar4_map;
    unsigned long   pci_bar5_map;

    u16 device_id;
    u16 vendor_id;
    u16 sub_vendor_id;
    u16 sub_system_id;

    u16 brd_number;    /* HBA index */

    u8  asic_gen;
    u8  asic_revision;
    u8  phys_port;
    u8  port_type;

    u8  pci_bus_number;
    u8  pci_device_number;
    u8  pci_function_number;

    u8  host_bus;
    u8  host_device;
    u8  host_function;
    u8  host_sub_bus;

    sli_intf_reg_t  sli_intf;
    u32 post_status;
    u32 ue_mask_lo;
    u32 ue_mask_hi;
    u32 ue_error_hi;
    u32 ue_error_lo;

    u32        flags;
#define ELXSLI_HBAINFO_SLI3             0x01    /* SLI3 support */
#define ELXSLI_HBAINFO_SLI4             0x02    /* SLI4 support */
#define ELXSLI_HBAINFO_FCOE             0x04    /* FCoE support */
#define ELXSLI_HBAINFO_NIC              0x08    /* NIC  support */
#define ELXSLI_HBAINFO_BIG_ENDIAN       0x10    /* Big Endian host */
#define ELXSLI_HBAINFO_LITTLE_ENDIAN    0x20    /* Little Endian host */
#define ELXSLI_HBAINFO_BAR_ONLY         0x40    /* BAR access only */
#define ELXSLI_FCOE_SUPPORTED           0x00000100

    u32  status_flags;
#define ELXSLI_ENDIAN_INIT              0x1     /* endian init is active */

    char model[32];
    char model_desc[64];
    char manufacturer[32];
    char fw_ver_string[32];

    u32  tag;
    struct list_head node;    /* hba link list node */

    struct mutex    elxsli_lock;

    pci_cfg_t       pci_cfg;

} elxsli_hba_t;


#endif

