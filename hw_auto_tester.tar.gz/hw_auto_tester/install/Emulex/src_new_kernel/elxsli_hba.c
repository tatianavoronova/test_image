/*************************************************************************
 * Broadcom Inc. Copyright (c) 2020 Broadcom.
 * All Rights Reserved.
 * The term "Broadcom" refers to Broadcom Inc. and/or its subsidiaries.
 *************************************************************************/
// File: elxsli_hba.c

#include <linux/module.h>
#include <linux/blkdev.h>
#include <linux/pci.h>
#include <linux/interrupt.h>
#include <linux/delay.h>
#include <linux/version.h>
#include "elxsli_version.h"
#include "elxsli_adapters.h"
#include "elxsli_ioctl.h"
#include "elxsli_mbox.h"
#include "elxsli_hba.h"

extern int elxsli_baronly;
extern int elxsli_is_lancer_hba(elxsli_hba_t *phba);
extern int elxsli_is_lancer_dev(struct pci_dev *pdev);
extern int elxsli_is_lanG5_hba(elxsli_hba_t *phba);
extern int elxsli_is_lanG5_dev(struct pci_dev *pdev);
extern int elxsli_is_lanG6_hba(elxsli_hba_t *phba);
extern int elxsli_is_lanG6_dev(struct pci_dev *pdev);
extern int elxsli_is_prism_hba(elxsli_hba_t *phba);
extern int elxsli_is_prism_dev(struct pci_dev *pdev);
extern int elxsli_is_armless(u16 device_id);
extern int elxsli_is_fc(u16 device_id);
extern int check_for_firmware_ready(elxsli_hba_t *phba);
extern int elxsli_pci_cfg_save_regs(elxsli_hba_t *phba);
extern int check_offline_status(elxsli_hba_t *phba);

#ifndef PTR_ALIGN
#define PTR_ALIGN(p, a) ((typeof(p))ALIGN((unsigned long)(p), (a)))
#endif

/**
 * Function: elxsli_mbox_tmo_val
 * Description: Retrieve a mailbox command timeout value based on command
 * @param [in] -: phba: pointer to elxsli hba data structure.
 * @param [in] -: cmd: mailbox command code.
 * @return   Timeout value to be used for the given mailbox command
 */
int elxsli_mbox_tmo_val(elxsli_hba_t *phba, int cmd)
{
    switch (cmd) {
      case MBX_WRITE_NV:
      case MBX_DUMP_MEMORY:
      case MBX_UPDATE_CFG:
      case MBX_DOWN_LOAD:
      case MBX_DEL_LD_ENTRY:
      case MBX_LOAD_AREA:
      case MBX_WRITE_WWN:
      case MBX_LOAD_EXP_ROM:
      case MBX_SLI_CONFIG:
          return (ELXSLI_MBOX_TMO_FLASH_CMD);
    }
    return (ELXSLI_MBOX_TMO_CMD);
}

/**
 * Function: elxsli_sli_pcimem_bcopy - SLI memory copy function
 * Description: Copy data between driver memory and the SLI memory.
 * This function also changes the endianness of each word if
 * native endianness is different from SLI endianness.
 * @param [in] -: srcp: Source memory pointer.
 * @param [in] -: destp: Destination memory pointer.
 * @param [in] -: cnt: Number of words required to be copied.
 */
void elxsli_sli_pcimem_bcopy(void *srcp, void *destp, u32 cnt)
{
    u32 *src = srcp;
    u32 *dest = destp;
    u32 ldata;
    int i;

    for (i = 0; i < (int)cnt; i += sizeof(u32)) {
        ldata = *src;
        ldata = le32_to_cpu(ldata);
        *dest = ldata;
        src++;
        dest++;
    }
}

/**
 * Function: elxsli_issue_mbox
 * Description: Issue an SLI mailbox command to the SLI-PORT interface.
 * @param [in] -: phba: Pointer to HBA context object.
 * @return  0 - successful, other values - error
 */
int elxsli_issue_mbox(struct elxsli_hba *phba)
{
    int rc = MBX_SUCCESS;
    fc_mqe_t *fc_mqe;
    unsigned long timeout;
    bmbx_reg_t bmbx_reg;
    u8 mbx_cmd;

    if (phba->flags & ELXSLI_HBAINFO_BAR_ONLY) {
        PRINT_LOG_MSG(phba, KERN_ERR,
                      "elxsli_issue_mbox: FW NOT READY ERROR\n");
        return (MBXERR_ERROR);
    }

    fc_mqe = (fc_mqe_t *)&phba->sli4_hba.mbox;
    mbx_cmd = fc_mqe->hdr.command;
    timeout = msecs_to_jiffies(
              elxsli_mbox_tmo_val(phba, mbx_cmd) * 1000) + jiffies;

    /* wait for the doorbell register ready bit */
    do {
        bmbx_reg.dw = ioread32(phba->sli4_hba.BMBXregaddr);
        if (bmbx_reg.dw == 0xFFFFFFFF) {
            msleep(200);
            bmbx_reg.dw = ioread32(phba->sli4_hba.BMBXregaddr);
            if (bmbx_reg.dw == 0xFFFFFFFF) {
                rc = MBXERR_ERROR + 1;
                PRINT_LOG_MSG(phba, KERN_ERR,
                              "elxsli_issue_mbox read x%x "
                              "for MBX Word 0- Assume NO FW\n",
                              bmbx_reg.dw);
                return (rc);
            }
        }

        if (!bmbx_reg.bits.ready) {
            msleep(2);
        }

        if (time_after(jiffies, timeout)) {
            rc = MBXERR_ERROR + 2;
            PRINT_LOG_MSG(phba, KERN_ERR,
                          "elxsli_issue_mbox cmd x%x timeout: not ready\n",
                          mbx_cmd);
            return (rc);
        }
    } while (!bmbx_reg.bits.ready);

    memset(phba->sli4_hba.bmbx.virt, 0, phba->sli4_hba.bmbx.bmbx_size);

    elxsli_sli_pcimem_bcopy(fc_mqe, phba->sli4_hba.bmbx.avirt, FC_MQE_LEN);
    pci_dma_sync_single_for_device(phba->pcidev,
                                   phba->sli4_hba.bmbx.aphys,
                                   sizeof(sli_mqe_t), PCI_DMA_TODEVICE);

    iowrite32(phba->sli4_hba.bmbx.addr_hi, phba->sli4_hba.BMBXregaddr);

    timeout = msecs_to_jiffies(
              elxsli_mbox_tmo_val(phba, mbx_cmd) * 1000) + jiffies;
    /* wait for the high address to be ack'ed */
    do {
        bmbx_reg.dw = ioread32(phba->sli4_hba.BMBXregaddr);
        if (!bmbx_reg.bits.ready)  {
            msleep(2);
        }

        if (time_after(jiffies, timeout)) {
            rc = MBXERR_ERROR + 3;
            PRINT_LOG_MSG(phba, KERN_ERR,
                          "elxsli_issue_mbox cmd x%x timeout: POSTING HI ADDRESS\n",
                          mbx_cmd);
            return (rc);
        }
    } while (!bmbx_reg.bits.ready);

    iowrite32(phba->sli4_hba.bmbx.addr_lo, phba->sli4_hba.BMBXregaddr);
    timeout = msecs_to_jiffies(
              elxsli_mbox_tmo_val(phba, mbx_cmd) * 1000) + jiffies;
    /* wait for the low address to be ack'ed */
    do {
        bmbx_reg.dw = ioread32(phba->sli4_hba.BMBXregaddr);
        if (!bmbx_reg.bits.ready)   {
            msleep(2);
        }

        if (time_after(jiffies, timeout)) {
            rc = MBXERR_ERROR + 4;
            PRINT_LOG_MSG(phba, KERN_ERR,
                          "elxsli_issue_mbox cmd x%x timeout: POSTING LOW ADDRESS\n",
                          mbx_cmd);
            return (rc);
        }
    } while (!bmbx_reg.bits.ready);

    /* copy the mailbox response data from DMA memory */
    elxsli_sli_pcimem_bcopy(phba->sli4_hba.bmbx.avirt,
                            &phba->sli4_hba.mbox, FC_MQE_LEN);

    if ((fc_mqe->words[0] == HOST_ENDIAN_LOW_WORD0) &&
        (fc_mqe->words[1] == HOST_ENDIAN_HIGH_WORD1)) {
        return (rc); /* just exit if FW init command */
    }
    return (rc);
}

/**
 * Function: elxsli_post_status_check
 * Description: Check for any POST or chip error status.
 * @param [in] -: phba: pointer to elxsli hba data structure.
 * @return  0 - successful, other values - error
 */
int elxsli_post_status_check(elxsli_hba_t *phba)
{
    sli_port_status_reg_t sli_port_status;
    sli_port_smphr_reg_t portsmphr_reg;
#if 0
    sli_port_ctrl_reg_t sli_ctrl_reg;
    sli_physdev_reg_t physdev_reg;
    int timeout;
    bool port_rdy = false;
#endif
    int port_error = 0, i = 0;
    sli_port_status.dw = 0;

    if (!phba->sli4_hba.PSMPHRregaddr) {
        PRINT_LOG_MSG(phba, KERN_ERR,
                      "elxsli_post_status_check - "
                      "Bad semaphore register address\n");
        return (-ENODEV);
    }

    if (elxsli_is_armless(phba->device_id)) {
        /* skip POST check */
        phba->flags |= ELXSLI_HBAINFO_BAR_ONLY;
        /* PCI BAR only access, NO ioctl support. */
        return (1);
    }

    /* Check POST status */
    if (phba->pci_function_number == 0) { /* check PF 0 only */
        for (i = 0; i < ELXSLI_POST_ERROR_TIMEOUT_VALUE; i++) {

            portsmphr_reg.dw = ioread32(phba->sli4_hba.PSMPHRregaddr);
            PRINT_LOG_MSG(phba, KERN_ERR,
                          "elxsli_post_status_check - POST Status = 0x%04X\n",
                          portsmphr_reg.bits.status);
            phba->post_status = portsmphr_reg.dw;
            if (portsmphr_reg.bits.perr) {
                /* Port has a fatal POST error */
                PRINT_LOG_MSG(phba, KERN_ERR,
                              "elxsli_post_status_check - Fatal POST error\n");
                /* PCI BAR only access, NO ioctl support. */
                phba->flags |= ELXSLI_HBAINFO_BAR_ONLY;
                port_error = -ENODEV;
                break;
            }

            if (ELXSLI_POST_STAGE_PORT_READY == portsmphr_reg.bits.status) {
                port_error = 0;
                break;
            }

            msleep(500);
        }

        /* If there was a port error during POST, then don't proceed with */
        /* other register reads as the data may not be valid. */
        if (ELXSLI_POST_STAGE_PORT_READY != portsmphr_reg.bits.status) {
            /* Port has a fatal POST error */
            PRINT_LOG_MSG(phba, KERN_ERR,
                          "elxsli_post_status_check - Fatal POST error\n");
            /* PCI BAR only access, NO ioctl support. */
            phba->flags |= ELXSLI_HBAINFO_BAR_ONLY;
            port_error = -ENODEV;
        }

        if (port_error) {
            PRINT_LOG_MSG(phba, KERN_ERR,
                          "Failed POST - port_smphr=0x%x, perr=0x%x, "
                          "sfi=0x%x, nip=0x%x, ipc=0x%x, scr1=0x%x, "
                          "scr2=x%x, hscratch=x%x, pstatus=x%x\n",
                          portsmphr_reg.dw, portsmphr_reg.bits.perr,
                          portsmphr_reg.bits.sfi, portsmphr_reg.bits.nip,
                          portsmphr_reg.bits.ipc, portsmphr_reg.bits.scr1,
                          portsmphr_reg.bits.scr2, portsmphr_reg.bits.host_scratch,
                          portsmphr_reg.bits.status);

            /* PCI BAR only access, NO ioctl support. */
            phba->flags |= ELXSLI_HBAINFO_BAR_ONLY;
        }

        /* Get UE error status */
        switch (phba->sli_intf.bits.if_type) {
          case SLI_INTF_IF_TYPE_0:
          case SLI_INTF_IF_TYPE_4:
              pci_read_config_dword(phba->pcidev, ELXSLI_UE_MASK_LO,
                                    (u32 *)&phba->ue_mask_lo);
              pci_read_config_dword(phba->pcidev, ELXSLI_UE_MASK_HI,
                                    (u32 *)&phba->ue_mask_hi);

              /* Read the UE status */
              pci_read_config_dword(phba->pcidev,
                                    ELXSLI_UERR_STATUS_LO, &phba->ue_error_lo);
              pci_read_config_dword(phba->pcidev,
                                    ELXSLI_UERR_STATUS_HI, &phba->ue_error_hi);

              /* Check for valid UE status bits */
              if ((~phba->ue_mask_lo & phba->ue_error_lo) ||
                  (~phba->ue_mask_hi & phba->ue_error_hi)) {
                  PRINT_LOG_MSG(phba, KERN_ERR,
                                "UE Detected: uerr_lo_reg=0x%x, uerr_hi_reg=0x%x, "
                                "ue_mask_lo_reg=0x%x, ue_mask_hi_reg=0x%x\n",
                                phba->ue_error_lo, phba->ue_error_hi,
                                phba->ue_mask_lo, phba->ue_mask_hi);
                  port_error = -ENODEV;
              }
              break;

          case SLI_INTF_IF_TYPE_2:
              if ((elxsli_readl(phba->sli4_hba.STATUSregaddr, &sli_port_status.dw)) &&
                  (sli_port_status.bits.err) && (!sli_port_status.bits.rn)) {

                  phba->ue_error_hi = ioread32(phba->sli4_hba.ERR1regaddr);
                  phba->ue_error_lo = ioread32(phba->sli4_hba.ERR2regaddr);

                  PRINT_LOG_MSG(phba, KERN_ERR,
                                "SLI PORT Error Detected: sli_port_status=0x%x, "
                                "sli_port_error_1=0x%x, sli_port_error_2=0x%x\n",
                                sli_port_status.dw,
                                phba->ue_error_hi,
                                phba->ue_error_lo);
                  port_error = -ENODEV;
              }
              break;

          case SLI_INTF_IF_TYPE_1:
          default:
              break;
        }

        if (!port_error) {
            PRINT_LOG_MSG(phba, KERN_INFO, "Port is Ready\n");
        }
    }
    return (port_error);
}


/**
 * Function: elxsli_setup_endian_order
 * Description: Write FW_INIT command to an SLI4 if_type 0 port.
 * @param [in] -: phba: pointer to elxsli hba data structure.
 * @return 0 - successful, -ENOMEM - No availble memory,
 *  -EIO - IO error failure.
 */
static int elxsli_setup_endian_order(struct elxsli_hba *phba)
{
    int rc = 0;
    u32 endian_mb_data[2] = {HOST_ENDIAN_LOW_WORD0, HOST_ENDIAN_HIGH_WORD1};

    if (phba->status_flags & ELXSLI_ENDIAN_INIT) {
        return (0);
    }

    /* issue FW_INITIALIZE command */
    memset(&phba->sli4_hba.mbox, 0, SLI_MQE_LEN);
    memset(&phba->sli4_hba.mbox_cqe, 0, SLI_MCQE_LEN);
    memcpy(&phba->sli4_hba.mbox, &endian_mb_data, sizeof(endian_mb_data));

    rc = elxsli_issue_mbox(phba);
    if (rc != MBX_SUCCESS) {
        phba->flags |= ELXSLI_HBAINFO_BAR_ONLY;
        PRINT_LOG_MSG(phba, KERN_ERR, "Endian Init mbox failed x%x\n", rc);
        rc = -EIO;
    }

    phba->status_flags |= ELXSLI_ENDIAN_INIT;
    return (rc);
}

/**
 * Function: elxsli_functional_reset
 * Description: issue Function Reset IOCTL command to port.
 * @param [in] -: phba: Pointer to HBA context object.
 * @return  0 - successful, other values - error
 */
int elxsli_functional_reset(elxsli_hba_t *phba)
{
    fc_mqe_t *fc_mqe;
    sli_mqe_t *mqe;
    sli_header_t *sli_header;
    u16 cfg_value;
    int rc = 0;

    fc_mqe = (fc_mqe_t *)&phba->sli4_hba.mbox;
    memset(fc_mqe, 0, FC_MQE_LEN);

    if (phba->flags & ELXSLI_FCOE_SUPPORTED) {
        fc_mqe->hdr.command = MBX_SLI_CONFIG;
        mqe = (sli_mqe_t *)&(fc_mqe->hdr.payload);
    } else {
        mqe = (sli_mqe_t *)fc_mqe;
    }

    sli_header = (sli_header_t *)&(mqe->payload.sli_header);

    mqe->mqe_hdr.embedded = 1;
    mqe->mqe_hdr.payload_length = SLI_HEADER_LEN;

    sli_header->request.opcode = SLI_OPCODE_FUNCTION_RESET;
    sli_header->request.subsystem = COMMON_SUBSYSTEM;
    sli_header->request.request_length = 0;

    /* Turn off parity checking and serr during the physical reset */
    pci_read_config_word(phba->pcidev, PCI_COMMAND, &cfg_value);
    pci_write_config_word(phba->pcidev, PCI_COMMAND,
                          (cfg_value & ~(PCI_COMMAND_PARITY |
                                         PCI_COMMAND_SERR)));

    rc = elxsli_issue_mbox(phba);
    if (rc != MBX_SUCCESS) {
        PRINT_LOG_MSG(phba, KERN_ERR,
                      "Functional RESET mbox failed rc = 0x%x\n", rc);
        phba->flags |= ELXSLI_HBAINFO_BAR_ONLY;
        return (rc);
    }

    /* Restore PCI cmd register */
    pci_write_config_word(phba->pcidev, PCI_COMMAND, cfg_value);
    msleep(100);
    return (rc);
}

/**
 * Function: elxsli_chipreset
 * Description: Perform a soft-reset command on ASIC.
 * (valid for non-Lancer ASIC only)
 * @param [in] -: phba: Pointer to HBA context object.
 * @return  0 - successful, other values - error
 */
int elxsli_chipreset(elxsli_hba_t *phba)
{
    void __iomem *regaddr;
    u32 value;
    u32 rc = 0;

    if (elxsli_is_lancer_hba(phba)) {
        return (0);
    }

    regaddr = phba->sli4_hba.pcicfg_regs_memmap_p + ELXSLI_PCI_SOFT_RESET;
    value = ioread32(regaddr);
    iowrite32(0xffffffff, phba->sli4_hba.UEMASKLOregaddr);
    iowrite32(0xffffffff, phba->sli4_hba.UEMASKHIregaddr);
    iowrite32(0x0, phba->sli4_hba.UEONLINE0regaddr);
    iowrite32(0x0, phba->sli4_hba.UEONLINE1regaddr);
    value |= 0x80;
    iowrite32(value, regaddr);
    rc = 0;
    /* Wait for reset to complete */
    while ((value & 0x80) != 0) {
        msleep(10);
        value = ioread32(regaddr);
        rc++;
        if (rc >= 3000) {  /* 30 seconds */
            PRINT_LOG_MSG(phba, KERN_ERR,
                          "PCI register not cleared after chip reset\n");
            return (rc);
        }
    }
    msleep(100);
    PRINT_DEBUG_LOG(phba, "Chip reset complete: x%x\n", value);
    return (rc);
}

/**
 * Function: elxsli_get_firmware_config
 * Description: Retrieve the firmware revision and port information,
 * if online.
 * @param [in] -: phba: Pointer to HBA context object.
 * @return 0 - successful, other values - error
 */
int elxsli_get_firmware_config(elxsli_hba_t *phba)
{
    u32 rc, ext_buffer_size;
    mbx_common_query_fw_config_t *fw_cfg;
    fc_mqe_t *fc_mqe;
    sli_mqe_t *mqe;
    sli_header_t *sli_header;
    void *virt;
    dma_addr_t phys;

    ext_buffer_size = SLI_GET_FW_CONFIG_PAYLOAD_SIZE;
    virt = dma_alloc_coherent(&phba->pcidev->dev, ext_buffer_size,
                              &phys, GFP_KERNEL);
    if (!virt) {
        PRINT_LOG_MSG(phba, KERN_ERR,
                      "elxsli_get_firmware_config: Cannot alloc memory\n");
        return (ENOMEM);
    }

    memset(virt, 0, ext_buffer_size);
    fc_mqe = (fc_mqe_t *)&phba->sli4_hba.mbox;
    memset(fc_mqe, 0, sizeof(fc_mqe_t));

    if (phba->flags & ELXSLI_FCOE_SUPPORTED) {
        fc_mqe->hdr.command = MBX_SLI_CONFIG;
        mqe = (sli_mqe_t *)&fc_mqe->hdr.payload;
    } else {
        mqe = (sli_mqe_t *)fc_mqe;
    }

    mqe->mqe_hdr.embedded = 0;
    mqe->mqe_hdr.sge_count = 1;
    mqe->mqe_hdr.payload_length = ext_buffer_size;
    mqe->payload.sge[0].pa_lo = putPaddrLow(phys);
    mqe->payload.sge[0].pa_hi = putPaddrHigh(phys);
    mqe->payload.sge[0].length = ext_buffer_size;

    sli_header = (sli_header_t *)virt;
    sli_header->request.opcode = SLI_OPCODE_GET_FW_CONFIG;
    sli_header->request.subsystem = COMMON_SUBSYSTEM;
    sli_header->request.request_length = (SLI_GET_FW_CONFIG_PAYLOAD_SIZE - SLI_HEADER_LEN);

    elxsli_sli_pcimem_bcopy(sli_header, sli_header, SLI_HEADER_LEN);
    rc = elxsli_issue_mbox(phba);
    if (rc != MBX_SUCCESS) {
        PRINT_LOG_MSG(phba, KERN_ERR, "elxsli_get_firmware_config failed x%x\n", rc);
        dma_free_coherent(&phba->pcidev->dev, ext_buffer_size, virt, phys);
        phba->flags |= ELXSLI_HBAINFO_BAR_ONLY;
        return (rc);
    }

    fw_cfg = (mbx_common_query_fw_config_t *)(virt + sizeof(sli_header_t));
    phba->asic_gen = fw_cfg->params.response.asic_gen_num;
    phba->asic_revision = fw_cfg->params.response.asic_revision;
    phba->phys_port = fw_cfg->params.response.phys_port;

    PRINT_LOG_MSG(phba, KERN_INFO, "ASIC Rev: %x\n", phba->asic_revision);
    PRINT_LOG_MSG(phba, KERN_INFO, "Phys Port: %d\n", phba->phys_port);

    dma_free_coherent(&phba->pcidev->dev, ext_buffer_size, virt, phys);
    return (rc);
}

/**
 * Function: elxsli_get_attributes
 * Description: Retrieve the controller attributes information, if online.
 * @param [in] -: phba: Pointer to HBA context object.
 * @return 0 - successful, other values - error
 */
int elxsli_get_attributes(elxsli_hba_t *phba)
{
    u32 rc, ext_buffer_size;
    mbx_common_get_attributes_t *attrib;
    fc_mqe_t *fc_mqe;
    sli_mqe_t *mqe;
    sli_header_t *sli_header;
    void *virt;
    dma_addr_t phys;

    ext_buffer_size = SLI_GET_ATRTIB_PAYLOAD_SIZE;
    virt = dma_alloc_coherent(&phba->pcidev->dev, ext_buffer_size,
                              &phys, GFP_KERNEL);
    if (!virt) {
        PRINT_LOG_MSG(phba, KERN_ERR,
                      "elxsli_get_attributes: Cannot alloc memory\n");
        return (ENOMEM);
    }

    memset(virt, 0, ext_buffer_size);
    fc_mqe = (fc_mqe_t *)&phba->sli4_hba.mbox;
    memset(fc_mqe, 0, sizeof(fc_mqe_t));

    if (phba->flags & ELXSLI_FCOE_SUPPORTED) {
        fc_mqe->hdr.command = MBX_SLI_CONFIG;
        mqe = (sli_mqe_t *)&fc_mqe->hdr.payload;
    } else {
        mqe = (sli_mqe_t *)fc_mqe;
    }

    mqe->mqe_hdr.embedded = 0;
    mqe->mqe_hdr.sge_count = 1;
    mqe->mqe_hdr.payload_length = ext_buffer_size;
    mqe->payload.sge[0].pa_lo = putPaddrLow(phys);
    mqe->payload.sge[0].pa_hi = putPaddrHigh(phys);
    mqe->payload.sge[0].length = ext_buffer_size;

    sli_header = (sli_header_t *)virt;
    sli_header->request.opcode = SLI_OPCODE_GET_ATTRIBUTES;
    sli_header->request.subsystem = COMMON_SUBSYSTEM;
    sli_header->request.request_length =\
        (SLI_GET_FW_CONFIG_PAYLOAD_SIZE - SLI_HEADER_LEN);

    elxsli_sli_pcimem_bcopy(sli_header, sli_header, SLI_HEADER_LEN);
    rc = elxsli_issue_mbox(phba);
    if (rc != MBX_SUCCESS) {
        PRINT_LOG_MSG(phba, KERN_ERR,
                      "elxsli_get_attributes failed x%x\n", rc);
        dma_free_coherent(&phba->pcidev->dev, ext_buffer_size, virt, phys);
        phba->flags |= ELXSLI_HBAINFO_BAR_ONLY;
        return (rc);
    }

    attrib = (mbx_common_get_attributes_t *)(virt + sizeof(sli_header_t));

    phba->asic_gen = attrib->hba_attribs.asic_generation;
    phba->asic_revision = attrib->hba_attribs.asic_revision;

    if (elxsli_is_prism_hba(phba)) {
        if (phba->asic_revision == 0x1) // fix for ASIC issue
            phba->asic_revision = 0;
    }

    memcpy(&phba->manufacturer, &attrib->hba_attribs.manufacturer_name, 32);
    memcpy(&phba->model, &attrib->hba_attribs.controller_model_number, 32);
    memcpy(&phba->model_desc,
           &attrib->hba_attribs.controller_description,  64);
    memcpy(&phba->fw_ver_string,
           &attrib->hba_attribs.firmware_version_string, 32);

    phba->phys_port = attrib->hba_attribs.physical_port;
    phba->port_type = attrib->hba_attribs.port_type;
    phba->post_status = attrib->hba_attribs.post_status;

    PRINT_LOG_MSG(phba, KERN_INFO, "Port Type: %d\n", phba->port_type);
    PRINT_LOG_MSG(phba, KERN_INFO, "POST Status: 0x%0X\n",
                  phba->post_status);
    PRINT_LOG_MSG(phba, KERN_INFO, "%s\n", phba->manufacturer);
    PRINT_LOG_MSG(phba, KERN_INFO, "%s\n", phba->model);
    PRINT_LOG_MSG(phba, KERN_INFO, "%s\n", phba->model_desc);
    PRINT_LOG_MSG(phba, KERN_INFO, "%s\n", phba->fw_ver_string);

    dma_free_coherent(&phba->pcidev->dev, ext_buffer_size, virt, phys);
    return (rc);
}

/**
 * Function: elxsli_create_bootstrap_mbox - Create the bootstrap mailbox
 * Description: Set up DMA memory and address pointers for
 * Bootstrap Mailbox interface.
 * @param [in] - phba: pointer to elxsli hba data structure.
 * @return 0 - successful, -ENOMEM - could not allocated memory.
 */
static int elxsli_create_bootstrap_mbox(elxsli_hba_t *phba)
{
    u32 bmbx_size;
    u32 pa_addr;
    u64 phys_addr;

    /* The bootstrap mailbox region is comprised of 2 parts plus an
       alignment restriction of 16 bytes. */
    bmbx_size = SLI_MQE_LEN + SLI_MCQE_LEN + (ELXSLI_ALIGN_16_BYTE - 1);
    phba->sli4_hba.bmbx.virt = dma_alloc_coherent(&phba->pcidev->dev,
                                                  bmbx_size,
                                                  &phba->sli4_hba.bmbx.phys,
                                                  GFP_KERNEL);
    if (!phba->sli4_hba.bmbx.virt) {
        PRINT_LOG_MSG(phba, KERN_ERR, "Cannot allocate memory for BMBX\n");
        return (-ENOMEM);
    }

    memset(phba->sli4_hba.bmbx.virt, 0, bmbx_size);
    phba->sli4_hba.bmbx.bmbx_size = bmbx_size;
    phba->sli4_hba.bmbx.avirt = PTR_ALIGN(phba->sli4_hba.bmbx.virt,
                                          ELXSLI_ALIGN_16_BYTE);
    phba->sli4_hba.bmbx.aphys = ALIGN(phba->sli4_hba.bmbx.phys,
                                      ELXSLI_ALIGN_16_BYTE);
    phys_addr = (u64)phba->sli4_hba.bmbx.aphys;
    pa_addr = (u32)((phys_addr >> 34) & 0x3fffffff);
    phba->sli4_hba.bmbx.addr_hi = (u32)((pa_addr << 2) |
                                        ELXSLI_BMBX_BIT1_ADDR_HI);
    pa_addr = (u32)((phba->sli4_hba.bmbx.aphys >> 4) & 0x3fffffff);
    phba->sli4_hba.bmbx.addr_lo = (u32)((pa_addr << 2) |
                                        ELXSLI_BMBX_BIT1_ADDR_LO);
    return (0);
}

/**
 * Function: elxsli_destroy_bootstrap_mbox - Destroy all bootstrap mailbox resources
 * Description: Deallocate the DMA memory used by the Bootstrap Mailbox interface.
 * @phba: pointer to elxsli hba data structure.
 */
static void elxsli_destroy_bootstrap_mbox(elxsli_hba_t *phba)
{
    dma_free_coherent(&phba->pcidev->dev, phba->sli4_hba.bmbx.bmbx_size,
                      phba->sli4_hba.bmbx.virt, phba->sli4_hba.bmbx.phys);
}

/**
 * Function: elxsli_init_hba - Initialize HBA
 * Description: Initialize all HBA ports.
 * @param [in] -: phba: pointer to elxsli hba data structure.
 * @return  0 - successful, other values - error
 */
int elxsli_init_hba(elxsli_hba_t *phba)
{
    int rc;

    mutex_init(&phba->elxsli_lock);

    if (elxsli_is_armless(phba->device_id)) {
        PRINT_LOG_MSG(phba, KERN_WARNING,
                      "elxsli_init - ASIC is in DEFAULT or ARMLESS mode");
        return (0);
    }

    /* For BAR access only, there is no need to initialize the HBA */
    if (phba->flags & ELXSLI_HBAINFO_BAR_ONLY) {
        PRINT_LOG_MSG(phba, KERN_WARNING,
                      "elxsli_init_hba - FIRMWARE IS NOT READY");
        return (0);
    }

    rc = elxsli_post_status_check(phba);
    if (rc) {
        PRINT_LOG_MSG(phba, KERN_WARNING,
                      "post_status_check failed - Firmware Not Ready\n");
        return (rc);
    }

    rc = elxsli_create_bootstrap_mbox(phba);
    if (rc) {
        PRINT_LOG_MSG(phba, KERN_WARNING, "boot_strap_mbox failed\n");
        return (rc);
    }

    if (phba->pci_function_number != 0) {
        rc = check_offline_status(phba);
        if (rc) {
            PRINT_LOG_MSG(phba, KERN_ERR, "PF0 is offline...skipping\n");
            return (1);
        }
    }

    switch (phba->sli_intf.bits.if_type) {
      case SLI_INTF_IF_TYPE_0:
      case SLI_INTF_IF_TYPE_4: // nic
          rc = elxsli_setup_endian_order(phba);
          if (rc) {
              PRINT_LOG_MSG(phba, KERN_WARNING, "setup_endian_order failed\n");
              return (rc);
          }

          rc = elxsli_functional_reset(phba);
          if (rc) {
              PRINT_LOG_MSG(phba, KERN_WARNING, "functional_reset failed\n");
              return (rc);
          }

          break;

      case SLI_INTF_IF_TYPE_2:  // lancer G5/6
      case SLI_INTF_IF_TYPE_6:  // Prism
      default:
          break;
    }

    rc = elxsli_get_attributes(phba);
    if (rc) {
        PRINT_LOG_MSG(phba, KERN_WARNING, "get_cntlr_attrib failed\n");
    } else {
        rc = elxsli_get_firmware_config(phba);
        if (rc) {
            PRINT_LOG_MSG(phba, KERN_WARNING,
                          "get_firmware_config failed\n");
        }
    }

    return (0); /* return success */
}

/**
 * Function: elxsli_uninit_hba
 * Description: Prepare HBA for driver unload.
 * @param [in] -: phba: pointer to elxsli hba data structure.
 */
void elxsli_uninit_hba(elxsli_hba_t *phba)
{
    if (phba->flags & ELXSLI_HBAINFO_BAR_ONLY) {
        return;
    }
    elxsli_destroy_bootstrap_mbox(phba);
}



