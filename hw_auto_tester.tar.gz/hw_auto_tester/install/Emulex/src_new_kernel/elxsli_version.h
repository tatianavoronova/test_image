
/*************************************************************************
 *  Broadcom Inc. Copyright (c) 2020 Broadcom.
 *  All Rights Reserved.
 *  The term "Broadcom" refers to Broadcom Inc. and/or its subsidiaries.
 *************************************************************************/
// File: elxsli_version.h

#ifndef H_ELXSLI_VERSION
#define H_ELXSLI_VERSION

#define ELXSLI_DEVICE_PATH "/dev/elxdrv"
#define ELXSLI_DRIVER_NAME "elxdrv"
#define ELXSLI_DRIVER_MAJOR_VER 1
#define ELXSLI_DRIVER_MINOR_VER 0
#define ELXSLI_DRIVER_BUILD_VER 1

#define STR_HELPER(x) #x
#define STR(x) STR_HELPER(x)

#define ELXSLI_DRIVER_VERSION  "1.00.01"
#define ELXSLI_COPYRIGHT "Copyright(c) 2020 Broadcom Inc. All rights reserved."

#endif

