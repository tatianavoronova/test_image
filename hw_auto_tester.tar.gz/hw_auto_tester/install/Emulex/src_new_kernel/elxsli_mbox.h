/*************************************************************************
 * Broadcom Inc. Copyright (c) 2020 Broadcom.
 * All Rights Reserved.
 * The term "Broadcom" refers to Broadcom Inc. and/or its subsidiaries.
 *************************************************************************/
// File: elxsli_mbox.h

#ifndef H_ELXSLI_MBOX
#define H_ELXSLI_MBOX

/* Mbox MQE status */
#define MBX_SUCCESS                     0
#define MBXERR_NUM_RINGS                1
#define MBXERR_NUM_IOCBS                2
#define MBXERR_IOCBS_EXCEEDED           3
#define MBXERR_BAD_RING_NUMBER          4
#define MBXERR_MASK_ENTRIES_RANGE       5
#define MBXERR_MASKS_EXCEEDED           6
#define MBXERR_BAD_PROFILE              7
#define MBXERR_BAD_DEF_CLASS            8
#define MBXERR_BAD_MAX_RESPONDER        9
#define MBXERR_BAD_MAX_ORIGINATOR       10
#define MBXERR_RPI_REGISTERED           11
#define MBXERR_RPI_FULL                 12
#define MBXERR_NO_RESOURCES             13
#define MBXERR_BAD_RCV_LENGTH           14
#define MBXERR_DMA_ERROR                15
#define MBXERR_ERROR                    16
#define MBXERR_LINK_DOWN                0x33
#define MBX_NOT_FINISHED                255
#define MBX_TIMEOUT                     0xFFFFFE
#define MBX_BUSY                        0xFFFFFF
#define MBX_ERROR_RANGE                 0x4000

/* SLI definitions */
#define FC_MQE_LEN                      256
#define SLI_MQE_LEN                     256
#define SLI_MCQE_LEN                    16
#define SLI_HEADER_LEN                  16

#define COMMON_SUBSYSTEM                0x01
#define FCOE_SUBSYSTEM                  0x0C

#define SLI_OPCODE_FUNCTION_RESET       0x3D
#define SLI_OPCODE_GET_FW_CONFIG        0x3A
#define SLI_OPCODE_GET_ATTRIBUTES       0x20

/* FC Mailbox Commands */
#define MBX_READ_NV                     0x02
#define MBX_WRITE_NV                    0x03
#define MBX_DUMP_MEMORY                 0x17
#define MBX_UPDATE_CFG                  0x1B
#define MBX_DOWN_LOAD                   0x1C
#define MBX_DEL_LD_ENTRY                0x1D
#define MBX_LOAD_AREA                   0x81
#define MBX_WRITE_WWN                   0x98
#define MBX_LOAD_EXP_ROM                0x9C
#define MBX_SLI_CONFIG                  0x9B

#define ELXSLI_MBOX_TMO_CMD             30
#define ELXSLI_MBOX_TMO_FLASH_CMD       300

/* Used for posting addresses in mbox commands */
#define putPaddrLow(addr)       ((u32) (0xffffffff & (u64)(addr)))
#define putPaddrHigh(addr)      ((u32) (0xffffffff & (((u64)(addr))>>32)))

/* Mailbox structures */
typedef enum _bde_types
{
    BDE_64_T = 0x0,
    BDE_IMM_T = 0x1,
    BLP_T = 0x40,

} bde_types;

typedef struct _bde_t
{
    u32 length : 24;
    u32 bde_type : 8;
    u32 buffer_address_low;
    u32 buffer_address_high;

} bde_t, *pbde_t;

typedef struct _mqe_sge_t
{
    u32 pa_lo;
    u32 pa_hi;
    u32 length;

} mqe_sge_t;

/* SLI mailbox request header (16 bytes) */
typedef struct _sli_request_header_t
{
    u32 opcode : 8;
    u32 subsystem : 8;
    u32 port_number : 8;
    u32 vf_number : 8;
    u32 timeout;
    u32 request_length;
    u32 version : 8;
    u32 rsvd : 8;
    u32 pf_number : 10;
    u32 vh_number : 6;

} sli_request_header_t;

/* SLI mailbox response header (16 bytes) */
typedef struct _sli_response_header_t
{
    u32 opcode : 8;
    u32 subsystem : 8;
    u32 rsvd0 : 16;
    u32 status : 8;
    u32 additional_status : 8;
    u32 rsvd1 : 16;
    u32 response_length;
    u32 actual_response_length;

} sli_response_header_t;


/* SLI mailbox header (16 bytes) */
typedef union _sli_header_t
{
    sli_request_header_t request;
    sli_response_header_t response;

} sli_header_t, *psli_header_t;

/* Mailbox Queue Entry Header (20 bytes) */
typedef struct _mqe_header_t
{
    u32 embedded    : 1;
    u32 rsvd0       : 2;
    u32 sge_count   : 5;
    u32 rsvd1       : 16;
    u32 special     : 8;
    u32 payload_length;
    u32 tag_lo;
    u32 tag_hi;
    u32 rsvd2;

} mqe_header_t, *pmqe_header_t;

/* MQE Payload (SGE/embedded SLI command) */
typedef union _mqe_payload_t
{
    mqe_sge_t     sge[19];
    u32      embedded[59];
    sli_header_t  sli_header;

} mqe_payload_t, *pmqe_payload;

/* SLI MQE format (256 bytes) */
typedef struct _sli_mqe_t
{
    mqe_header_t  mqe_hdr;
    mqe_payload_t payload;

} sli_mqe_t, *psli_mqe_t;

/* FC MQE format (256 bytes) */
typedef union _fc_mqe_t
{
    struct {
        uint8_t  rsvd0;
        uint8_t  command;
        u16 status;
        u32 payload[63];
    } hdr;

    u32 words[64];

} fc_mqe_t;

/* MQE CQE structure */
typedef struct _sli_mcqe_t {

    u16 status;
    u16 ext_status;
    u32 mcqe_lo;
    u32 mcqe_hi;
    u32 rsvd0 : 27;
    u32 consumed : 1;
    u32 completed : 1;
    u32 rsvd1 : 1;
    u32 async : 1;
    u32 valid : 1;

} sli_mcqe_t, *psli_mcqe_t;


typedef struct mac_address_struct {

    u16 size_of_mac_address;
    u8 mac_address[6];

} mac_address_t;

typedef struct mbx_common_get_iface_mac_list {
    union {
        struct {
            u8 macType;
            u8 permanent;
            u16 ifaceID;
            u32 mac_id;
            u32 rsvd0[67];
        } request;

        struct {
            mac_address_t fd_mac_address;
            mac_address_t macid_mac_address;
            u8 num_tpo_mac;
            u8 num_ppo_mac;
            u8 max_sz_mac_list;
            u8 rsvd0;
            mac_address_t po_mac_address[64];
        } response;
    } params;

} mbx_common_get_iface_mac_list_t;

typedef struct mbx_common_mgmt_attributes
{
    char flashrom_version_string[32];
    char manufacturer_name[32];
    u32 supported_modes;
    u8 seeprom_version_lo;
    u8 seeprom_version_hi;
    u8 rsvd0[2];
    u32 ioctl_data_struct_version;
    u32 ep_fw_data_struct_version;
    u8 ncsi_version_string[12];
    u32 default_extended_timeout;
    char controller_model_number[32];
    char controller_description[64];
    char controller_serial_number[32];
    char ip_version_string[32];
    char firmware_version_string[32];
    char bios_version_string[32];
    char redboot_version_string[32];
    char driver_version_string[32];
    char fw_on_flash_version_string[32];
    u32 functionalities_supported;
    u16 max_cdblength;
    u8 asic_revision;
    u8 generational_guid[16];
    u8 hba_port_count;
    u16 default_link_down_timeout;
    u8 iscsi_ver_min_max;
    u8 multifunction_device;
    u32 cache_valid           : 8;
    u32 hba_status            : 8;
    u32 max_domains_supported : 8;
    u32 physical_port         : 7;
    u32 port_type             : 1;
    u32 post_status;
    u32 hba_mtu[8];
    u8 iSCSI_features;
    u8 asic_generation;
    u8 rsvd1[2];
    u32 rsvd2[3];
    u16 pci_vendor_id;
    u16 pci_device_id;
    u16 pci_sub_vendor_id;
    u16 pci_sub_system_id;
    u8 pci_bus_number;
    u8 pci_device_number;
    u8 pci_function_number;
    u8 interface_type;
    u64 unique_identifier;
    u8 netfilters;
    u8 rsvd3[3];
    u32 rsvd4[4];

} mbx_common_mgmt_attributes_t, *pmbx_common_mgmt_attributes;

typedef struct mbx_common_get_attributes
{
    mbx_common_mgmt_attributes_t hba_attribs;

} mbx_common_get_attributes_t, *p_mbx_common_get_attributes_t;

#define SLI_GET_ATRTIB_PAYLOAD_SIZE  sizeof(mbx_common_get_attributes_t)

typedef struct _fw_config_params_t
{
    u32 config_number;
    u32 asic_revision : 8;
    u32 asic_gen_num  : 8;
    u32 rsvd0         : 16;
    u32 phys_port;
    u32 function_mode;
    u32 ulp_mode[2];
    u32 etx_base[2];
    u32 etx_count[2];
    u32 sq_base[2];
    u32 sq_count[2];
    u32 rq_base[2];
    u32 rq_count[2];
    u32 dq_base[2];
    u32 dq_count[2];
    u32 lro_base[2];
    u32 lro_count[2];
    u32 icd_base[2];
    u32 icd_count[2];
    u32 function_caps;

} fw_config_params_t;

typedef struct _mbx_common_query_fw_config_t
{
    union {
        struct {
            u32 rsvd0;
        } request;
        fw_config_params_t   response;
    } params;

} mbx_common_query_fw_config_t;

#define SLI_GET_FW_CONFIG_PAYLOAD_SIZE  sizeof(mbx_common_query_fw_config_t)

#endif



