/*************************************************************************
 * Broadcom Inc. Copyright (c) 2020 Broadcom.
 * All Rights Reserved.
 * The term "Broadcom" refers to Broadcom Inc. and/or its subsidiaries.
 *************************************************************************/
// File: elxsli_ioctl.h

#ifndef _H_ELXSLI_IOCTL
#define _H_ELXSLI_IOCTL

/* ELXSLI IOCTL COMMAND CODES */
typedef enum _ELXSLI_IOCTL_CODES_ {

    ELXSLI_GET_REV = 1,
    ELXSLI_GET_HA_CNT,
    ELXSLI_HBAINFO,
    ELXSLI_FUNCTION_RESET,
    ELXSLI_RESET_CHIP,
    ELXSLI_ISSUE_MB,
    ELXSLI_ISSUE_FC_MB,
    ELXSLI_RWREG,
    ELXSLI_READ_PCI_CFG_SPACE,
    ELXSLI_WRITE_PCI_CFG_SPACE,
    ELXSLI_READ_PCI_CFG_BYTE,
    ELXSLI_READ_PCI_CFG_WORD,
    ELXSLI_READ_PCI_CFG_DWORD,
    ELXSLI_WRITE_PCI_CFG_BYTE,
    ELXSLI_WRITE_PCI_CFG_WORD,
    ELXSLI_WRITE_PCI_CFG_DWORD,
    ELXSLI_ALLOC_DMA_BUF,
    ELXSLI_FREE_DMA_BUF,
    ELXSLI_FREE_ALL_DMA_BUF,
    ELXSLI_COPY_TO_USER,
    ELXSLI_COPY_FROM_USER,
    ELXSLI_PCI_BUS_RESET,
    ELXSLI_PCI_LINK_DISABLE_RESET,

} ELXSLI_IOCTL_CODES;

#define ELXSLI_RWREG_READ    0x1
#define ELXSLI_RWREG_WRITE   0x2

#define PCI_HDR_SIZE         64
#define PCI_CFG_SIZE         256

/* Data structure definitions: */
typedef struct elxsliCmdInput {

    short    elxsli_index;
    short    elxsli_flag;
    void     *elxsli_arg1;
    void     *elxsli_arg2;
    void     *elxsli_arg3;
    char     *elxsli_dataout;
    u32 elxsli_cmd;
    u32 elxsli_outsz;

} ELXSLICMDINPUT_t;

#ifdef CONFIG_COMPAT
/* 32 bit version */
typedef struct elxsliCmdInput32 {

    short    elxsli_index;
    short    elxsli_flag;
    u32 elxsli_arg1;
    u32 elxsli_arg2;
    u32 elxsli_arg3;
    u32 elxsli_dataout;
    u32 elxsli_cmd;
    u32 elxsli_outsz;

} ELXSLICMDINPUT32_t;
#endif

/* the elxsliRevInfo structure */
typedef struct ELXSLIREVINFO {

    u32 a_Major;
    u32 a_Minor;
    u32 a_Build;

} elxsliREVINFO_t;

/* Versions */
#define ELXSLI_HBAINFO_VER  5  /* Version 5 structure */

/* the elxsliHBAINFO structure */
typedef struct elxsliHBAINFO {

    u8     hbainfo_ver;
    u8     drv_name[8];
    u8     drv_version[32];

    u16    vendor_id;
    u16    device_id;
    u16    subvendor_id;
    u16    subsystem_id;

    u8     bus_number;
    u8     device_number;
    u32    function;

    struct _host_bridge {
        u8 bus;
        u8 device;
        u8 function;
        u8 sub_bus;
    } host_bridge;

    u16    brd_number;

#define MODEL_STRING_LEN        32
#define MODEL_DESC_STRING_LEN   64
#define MANUFACTURER_STRING_LEN 32

    u8     model[MODEL_STRING_LEN + 1];
    u8     manufacturer[MANUFACTURER_STRING_LEN + 1];
    u8     model_desc[MODEL_DESC_STRING_LEN + 1];

    u8     asic_gen;
    u8     asic_revision;
    u8     phys_port;
    u8     port_type;

    u32    flags;
#define ELXSLI_HBAINFO_SLI3          0x01
#define ELXSLI_HBAINFO_SLI4          0x02
#define ELXSLI_HBAINFO_FCOE          0x04
#define ELXSLI_HBAINFO_NIC           0x08
#define ELXSLI_HBAINFO_BIG_ENDIAN    0x10
#define ELXSLI_HBAINFO_LITTLE_ENDIAN 0x20
#define ELXSLI_HBAINFO_BAR_ONLY      0x40

    u32    sli_intf;
    u32    post_status;
    u32    ue_mask_lo;
    u32    ue_mask_hi;
    u32    ue_error_hi;
    u32    ue_error_lo;

    u8     pci_cfg[PCI_HDR_SIZE];

} elxsliHBAINFO_t;

#define HBAINFO_SIZE sizeof(elxsliHBAINFO_t)

//note: little endian only
typedef struct {
    union {
        struct {
            uint64_t
                             :12,
            mm_type_specific :44,
            mm_type          :8;
        } t;
        uint64_t l;
    } u;

} elxsli_mmoffset_t;

typedef struct {
    void *virt;
    void *phys;
    u32 size;
    u32 offset;
    u32 offset_len;
    u32 tag;
} dma_desc_t;

typedef struct {
    struct list_head node;
    dma_desc_t  desc;
} dma_buf_t;

#define ELXSLI_CMD_IOCTL_MAGIC  0xFC
/* Used for ioctl command */
#define ELXSLI_CMD_IOCTL _IOWR(ELXSLI_CMD_IOCTL_MAGIC, 0x1, ELXSLICMDINPUT_t)

#endif /* _H_ELXSLI_IOCTL */
