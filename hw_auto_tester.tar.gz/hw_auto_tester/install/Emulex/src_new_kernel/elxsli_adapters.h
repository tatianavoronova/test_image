
/*************************************************************************
 * Broadcom Inc. Copyright (c) 2020 Broadcom.
 * All Rights Reserved.
 * The term "Broadcom" refers to Broadcom Inc. and/or its subsidiaries.
 *************************************************************************/
// File: elxsli_adapters.h

#ifndef _ELXSLI_ADAPTERS_H
#define _ELXSLI_ADAPTERS_H

#if !defined(LINUX_VERSION_CODE)
#include <linux/version.h>
#endif

#define PCI_VENDOR_ID_BLD_ENG          0x19A2
#define PCI_VENDOR_ID_EMULEX           0x10DF
#define PCI_VENDOR_ID_OEM_ATTO         0x117C
#define PCI_VENDOR_ID_OEM_TAINAN       0x124F
#define PCI_DEVICE_ID_BE3_NIC          0x710
#define PCI_DEVICE_ID_BE3_ISCSI        0x712
#define PCI_DEVICE_ID_BE3_FCOE         0x714
#define PCI_DEVICE_ID_SH_NIC           0x0720
#define PCI_DEVICE_ID_SH_ISCSI         0x0722
#define PCI_DEVICE_ID_SH_ISCSI_TARGET  0x0723
#define PCI_DEVICE_ID_SH_FCOE          0x0724
#define PCI_DEVICE_ID_LANCER_DEFAULT             0xE2FF
#define PCI_DEVICE_ID_FC_LANCER_PF               0xE200
#define PCI_DEVICE_ID_FC_LANCER_VF               0xE208
#define PCI_DEVICE_ID_NIC_LANCER_PF              0xE220
#define PCI_DEVICE_ID_NIC_LANCER_VF              0xE228
#define PCI_DEVICE_ID_FCOE_LANCER_PF             0xE260
#define PCI_DEVICE_ID_FCOE_LANCER_VF             0xE268
#define PCI_DEVICE_ID_LANCER_UNIVERSAL_PF        0xE2FE
#define PCI_DEVICE_ID_LANCER_G5_P_ATTO_ID        0x0064
#define PCI_DEVICE_ID_LANCER_G5_B_ATTO_ID        0x007E
#define PCI_DEVICE_ID_LANCER_G5_T2_ATTO_ID       0x4064
#define PCI_DEVICE_ID_LANCER_G5_NIC_TAINAN_ID    0xE220
#define PCI_DEVICE_ID_LANCER_G5_FCOE_TAINAN_ID   0xE260
#define PCI_DEVICE_ID_LANCER_G5_8GFC_TAINAN_ID   0xE240
#define PCI_DEVICE_ID_LANCER_G5_16GFC_TAINAN_ID  0xE280
#define PCI_DEVICE_ID_LANCER_G6_DEFAULT          0xE30F
#define PCI_DEVICE_ID_LANCER_G6                  0xE300
#define PCI_DEVICE_ID_LANCER_G6_ATTO             0x0094
#define PCI_DEVICE_ID_FC_PRISM_G7_DEFAULT        0xF40F
#define PCI_DEVICE_ID_FC_PRISM_G7                0xF400
#define PCI_DEVICE_ID_PRISM_G7_ATTO              0x00BB

typedef struct _device_types
{
    uint16_t vendor_id;
    uint16_t device_id;
    char *model;
    char *description;

} DEVICE_TYPES;


#endif  /* _ELXSLI_ADAPTERS_H */


