/*************************************************************************
 * Broadcom Inc. Copyright (c) 2020 Broadcom.
 * All Rights Reserved.
 * The term "Broadcom" refers to Broadcom Inc. and/or its subsidiaries.
 *************************************************************************/
// File: elxsli_cdev.c

#include <linux/module.h>
#include <linux/blkdev.h>
#include <linux/pci.h>
#include <linux/device.h>
#include <linux/interrupt.h>
#include <linux/delay.h>
#include <linux/dma-mapping.h>
#include <linux/version.h>
#include <linux/list.h>
#include <linux/idr.h>
//#include <linux/set_memory.h>
#include "elxsli_adapters.h"
#include "elxsli_version.h"
#include "elxsli_ioctl.h"
#include "elxsli_mbox.h"
#include "elxsli_hba.h"

MODULE_DESCRIPTION("Emulex SLI Interface IOCTL support driver v" \
                   ELXSLI_DRIVER_NAME);
MODULE_AUTHOR("Broadcom Inc.");
MODULE_LICENSE("GPL");

#define ELXSLI_MODULE_DESC "Emulex SLI Interface Driver v" \
ELXSLI_DRIVER_VERSION

int elxsli_baronly = 0;
module_param(elxsli_baronly, int, 0);
MODULE_PARM_DESC(elxsli_baronly, "Only allow BAR register access");

/* externs */
extern int elxsli_init_hba(elxsli_hba_t *);
extern int elxsli_uninit_hba(elxsli_hba_t *);
extern int elxsli_functional_reset(elxsli_hba_t *);
extern int elxsli_chipreset(elxsli_hba_t *);
extern int elxsli_issue_mbox(struct elxsli_hba *);
extern void elxsli_sli_pcimem_bcopy(void *, void *, u32);

/* protos */
int elxsli_is_lancer_hba(elxsli_hba_t *phba);
int elxsli_is_lancer_dev(struct pci_dev *pdev);
int elxsli_is_lancer_G5_hba(elxsli_hba_t *phba);
int elxsli_is_lancer_G5_dev(struct pci_dev *pdev);
int elxsli_is_lancer_G6_hba(elxsli_hba_t *phba);
int elxsli_is_lancer_G6_dev(struct pci_dev *pdev);
int elxsli_is_prism_hba(elxsli_hba_t *phba);
int elxsli_is_prism_dev(struct pci_dev *pdev);
int elxsli_is_fc_hba(elxsli_hba_t *phba);
int elxsli_is_fc(u16 device_id);
int elxsli_is_prism_fc(u16 device_id);
int elxsli_is_lancer_G6_fc(u16 device_id);

static int elxsli_free_all_dma_buffers(elxsli_hba_t *phba);

#ifndef DMA_BIT_MASK
#define DMA_BIT_MASK(n) (((n) == 64) ? ~0ULL : ((1ULL<<(n))-1))
#endif

/* globals */
int elxsli_major = 0;
unsigned long elxsli_loadtime;

int gElxSliHbaCount = 0;

/* Adapter info list head pointer */
u32  elxsli_hba_next_instance = 0;
LIST_HEAD(elxsli_hba_list);

/* DMA buffer list head */
u32 dmabuf_next_instance = 0;
LIST_HEAD(dmabuf_list);    /* dma buffer link list head */

/* Supported vendor ids */
struct _oem_vendor_id_table {

    u16 vendor_id;

} oem_vendor_id_table[] = {

    { PCI_VENDOR_ID_EMULEX },
    { PCI_VENDOR_ID_OEM_ATTO },
    { PCI_VENDOR_ID_OEM_TAINAN },
};

#define VENDOR_ID_TBL_LEN ARRAY_SIZE(oem_vendor_id_table)

DEVICE_TYPES lancer_pci_device_id_table[] =
{
    { PCI_VENDOR_ID_EMULEX, PCI_DEVICE_ID_LANCER_DEFAULT,
        "LPe16000", "Emulex LPe16000 Default" },
    { PCI_VENDOR_ID_EMULEX, PCI_DEVICE_ID_LANCER_UNIVERSAL_PF,
        "LPe16000", "Emulex LPe16000 PF" },
    { PCI_VENDOR_ID_EMULEX, PCI_DEVICE_ID_FC_LANCER_PF,
        "LPe16000", "Emulex LPe16000 FC" },
    { PCI_VENDOR_ID_EMULEX, PCI_DEVICE_ID_FC_LANCER_VF,
        "LPe16000", "Emulex LPe16000 FC VF" },
    { PCI_VENDOR_ID_EMULEX, PCI_DEVICE_ID_NIC_LANCER_PF,
        "LPe16000", "Emulex LPe16000 NIC" },
    { PCI_VENDOR_ID_EMULEX, PCI_DEVICE_ID_NIC_LANCER_VF,
        "LPe16000", "Emulex LPe16000 NIC VF" },
    { PCI_VENDOR_ID_EMULEX, PCI_DEVICE_ID_FCOE_LANCER_PF,
        "LPe16000", "Emulex LPe16000 FCoE" },
    { PCI_VENDOR_ID_EMULEX, PCI_DEVICE_ID_FCOE_LANCER_VF,
        "LPe16000", "Emulex LPe16000 FCoE VF" },
    { PCI_VENDOR_ID_EMULEX, PCI_DEVICE_ID_LANCER_G6_DEFAULT,
        "LPe32000", "Emulex LPe32000 Default" },
    { PCI_VENDOR_ID_EMULEX, PCI_DEVICE_ID_LANCER_G6,
        "LPe32000", "Emulex LPe32000 FC" },
    { PCI_VENDOR_ID_EMULEX, PCI_DEVICE_ID_FC_PRISM_G7,
        "LPe36000", "Emulex LPe36000 FC" },
    { PCI_VENDOR_ID_EMULEX, PCI_DEVICE_ID_FC_PRISM_G7_DEFAULT,
        "LPe36000", "Emulex LPe36000 Default" },
    { PCI_VENDOR_ID_OEM_ATTO, PCI_DEVICE_ID_LANCER_G5_P_ATTO_ID,
        "LPe16000", "ATTO LPe16000 FC" },
    { PCI_VENDOR_ID_OEM_ATTO, PCI_DEVICE_ID_LANCER_G5_B_ATTO_ID,
        "LPe16000", "ATTO LPe16000 FC" },
    { PCI_VENDOR_ID_OEM_ATTO, PCI_DEVICE_ID_LANCER_G5_T2_ATTO_ID,
        "LPe16000", "ATTO LPe16000 FC" },
    { PCI_VENDOR_ID_OEM_ATTO, PCI_DEVICE_ID_LANCER_G6_ATTO,
        "LPe32000", "ATTO LPe32000 FC" },
    { PCI_VENDOR_ID_OEM_ATTO, PCI_DEVICE_ID_PRISM_G7_ATTO,
        "LPe36000", "ATTO LPe36000 Default" },
    { PCI_VENDOR_ID_OEM_TAINAN, PCI_DEVICE_ID_LANCER_G5_NIC_TAINAN_ID,
        "LPe16000", "TAINAN LPe16000 FC" },
    { PCI_VENDOR_ID_OEM_TAINAN, PCI_DEVICE_ID_LANCER_G5_FCOE_TAINAN_ID,
        "LPe16000", "TAINAN LPe16000 FC" },
    { PCI_VENDOR_ID_OEM_TAINAN, PCI_DEVICE_ID_LANCER_G5_8GFC_TAINAN_ID,
        "LPe16000", "TAINAN LPe16000 FC" },
    { PCI_VENDOR_ID_OEM_TAINAN, PCI_DEVICE_ID_LANCER_G5_16GFC_TAINAN_ID,
        "LPe16000", "TAINAN LPe16000 FC" },

};

#define LANCER_DEVICE_TBL_LEN  ARRAY_SIZE(lancer_pci_device_id_table)

DEVICE_TYPES lanG5_pci_device_id_table[] =
{
    { PCI_VENDOR_ID_EMULEX, PCI_DEVICE_ID_LANCER_DEFAULT,
        "LPe16000", "Emulex LPe16000 Default" },
    { PCI_VENDOR_ID_EMULEX, PCI_DEVICE_ID_LANCER_UNIVERSAL_PF,
        "LPe16000", "Emulex LPe16000 PF" },
    { PCI_VENDOR_ID_EMULEX, PCI_DEVICE_ID_FC_LANCER_PF,
        "LPe16000", "Emulex LPe16000 FC" },
    { PCI_VENDOR_ID_EMULEX, PCI_DEVICE_ID_FC_LANCER_VF,
        "LPe16000", "Emulex LPe16000 FC VF" },
    { PCI_VENDOR_ID_EMULEX, PCI_DEVICE_ID_NIC_LANCER_PF,
        "LPe16000", "Emulex LPe16000 NIC" },
    { PCI_VENDOR_ID_EMULEX, PCI_DEVICE_ID_NIC_LANCER_VF,
        "LPe16000", "Emulex LPe16000 NIC VF" },
    { PCI_VENDOR_ID_EMULEX, PCI_DEVICE_ID_FCOE_LANCER_PF,
        "LPe16000", "Emulex LPe16000 FCoE" },
    { PCI_VENDOR_ID_EMULEX, PCI_DEVICE_ID_FCOE_LANCER_VF,
        "LPe16000", "Emulex LPe16000 FCoE VF" },
    { PCI_VENDOR_ID_OEM_ATTO, PCI_DEVICE_ID_LANCER_G5_P_ATTO_ID,
        "LPe16000", "ATTO LPe16000 FC" },
    { PCI_VENDOR_ID_OEM_ATTO, PCI_DEVICE_ID_LANCER_G5_B_ATTO_ID,
        "LPe16000", "ATTO LPe16000 FC" },
    { PCI_VENDOR_ID_OEM_ATTO, PCI_DEVICE_ID_LANCER_G5_T2_ATTO_ID,
        "LPe16000", "ATTO LPe16000 FC" },
    { PCI_VENDOR_ID_OEM_TAINAN, PCI_DEVICE_ID_LANCER_G5_NIC_TAINAN_ID,
        "LPe16000", "TAINAN LPe16000 FC" },
    { PCI_VENDOR_ID_OEM_TAINAN, PCI_DEVICE_ID_LANCER_G5_FCOE_TAINAN_ID,
        "LPe16000", "TAINAN LPe16000 FC" },
    { PCI_VENDOR_ID_OEM_TAINAN, PCI_DEVICE_ID_LANCER_G5_8GFC_TAINAN_ID,
        "LPe16000", "TAINAN LPe16000 FC" },
    { PCI_VENDOR_ID_OEM_TAINAN, PCI_DEVICE_ID_LANCER_G5_16GFC_TAINAN_ID,
        "LPe16000", "TAINAN LPe16000 FC" },
};

#define LANG5_DEVICE_TBL_LEN  ARRAY_SIZE(lanG5_pci_device_id_table)

DEVICE_TYPES lanG6_pci_device_id_table[] =
{
    { PCI_VENDOR_ID_EMULEX, PCI_DEVICE_ID_LANCER_G6_DEFAULT,
        "LPe32000", "Emulex LPe32000 Default" },
    { PCI_VENDOR_ID_EMULEX, PCI_DEVICE_ID_LANCER_G6,
        "LPe32000", "Emulex LPe32000 FC" },
    { PCI_VENDOR_ID_OEM_ATTO, PCI_DEVICE_ID_LANCER_G6_ATTO,
        "LPe32000", "ATTO LPe32000 FC" },
};

#define LANG6_DEVICE_TBL_LEN  ARRAY_SIZE(lanG6_pci_device_id_table)

DEVICE_TYPES prism_pci_device_id_table[] =
{
    { PCI_VENDOR_ID_EMULEX, PCI_DEVICE_ID_FC_PRISM_G7,
        "LPe36000", "Emulex LPe36000 FC" },
    { PCI_VENDOR_ID_EMULEX, PCI_DEVICE_ID_FC_PRISM_G7_DEFAULT,
        "LPe36000", "Emulex LPe36000 Default" },
    { PCI_VENDOR_ID_OEM_ATTO, PCI_DEVICE_ID_PRISM_G7_ATTO,
        "LPe36000", "ATTO LPe36000 Default" },
};

#define PRISM_DEVICE_TBL_LEN  ARRAY_SIZE(prism_pci_device_id_table)

/**
 * @brief elxsli_hba_free_all - free all hba structures
 * @return 0 - successful
 */
static int elxsli_hba_free_all(void)
{
    elxsli_hba_t *phba;
    elxsli_hba_t *next;

    PRINTK_DBG("%s\n", __func__);

    /* Traverse all links and clean up memory  */
    list_for_each_entry_safe(phba, next, &elxsli_hba_list, node) {
        list_del(&phba->node);
        PRINTK_DBG("hba %d link deallocated\n", phba->tag);
        kfree(phba);
    }
    return (0);
}

/**
 * @brief elxsli_hba_find - Find a hba structure pointer given its tag
 * @param tag identifier
 * @return pointer to DMA buffer structure otherwise NULL
 */
static elxsli_hba_t* elxsli_hba_find(u32 tag)
{
    elxsli_hba_t *phba = NULL;

    //PRINTK_DBG("%s\n", __func__);
    list_for_each_entry(phba, &elxsli_hba_list, node) {
        if (phba->tag == tag) {
            return phba;
        }
    }
    return NULL;
}

/**
 * Function Name: elxsli_hba_add - add a new hba link to the adapter list
 * @return elxsli_hba_t*
 */
static elxsli_hba_t* elxsli_hba_add(void)
{
    elxsli_hba_t *phba = NULL;

    PRINTK_DBG("%s\n", __func__);
    /* Allocate memory for HBA structure */
    phba = kzalloc(sizeof(struct elxsli_hba), GFP_KERNEL);
    if (phba) {
        phba->tag = elxsli_hba_next_instance;
        list_add(&phba->node, &elxsli_hba_list);
        INIT_LIST_HEAD(&dmabuf_list);
        dmabuf_next_instance = 0;
        PRINTK_DBG("phba=%p, dmabuf_list.prev=%p, dmabuf_list.next=%p\n",
                   phba, dmabuf_list.prev, dmabuf_list.next);
        PRINTK_DBG("%s - hba %d link allocated\n", __func__, phba->tag);
        gElxSliHbaCount++;
        elxsli_hba_next_instance++;
    }
    return phba;
}

/**
 * Function Name: elxsli_hba_delete - remove a link from adapter list
 * using a tag
 * @phba: pointer to elxsli hba data structure.
 * @return elxsli_hba_t*
 */
static int elxsli_hba_delete(elxsli_hba_t *phba)
{
    PRINTK_DBG("%s\n", __func__);
    list_del_init(&phba->node);
    kfree(phba);
    elxsli_hba_next_instance--;
    if (gElxSliHbaCount) {
        gElxSliHbaCount--;
    }
    return 0;
}

/**
 * Function: check_offline_status
 * Description: Checks the status of PF0 BAR_ONLY flag.
 * @param [in] - phba - pointer to an hba structure for the device.
 * @return int returns 1 if error, else 0 if no error
 */
int check_offline_status(elxsli_hba_t *phba)
{
    elxsli_hba_t * pos,*q;

    list_for_each_entry_safe(pos, q, &elxsli_hba_list, node) {
        if (pos->pci_function_number == 0) {
            if ((pos->pci_bus_number == phba->pci_bus_number) &&
                (pos->pci_device_number == phba->pci_device_number)) {
                if (pos->flags & ELXSLI_HBAINFO_BAR_ONLY) {
                    return (1);
                } else {
                    return (0);
                }
            }
        }
    }
    return (0);
}

/**
 * Function: elxsli_is_lancer_dev
 * Description: Check if this device is a Lancer ASIC
 * @param [in] - u16 device_id - PCI device id
 * @return int returns 1 if true, else 0
 */
int elxsli_is_lancer_dev(struct pci_dev *pdev)
{
    int i;

    for (i = 0; i < LANCER_DEVICE_TBL_LEN; i++) {
        if ((pdev->vendor == lancer_pci_device_id_table[i].vendor_id) &&
            (pdev->device == lancer_pci_device_id_table[i].device_id)) {
            return (1);
        }
    }
    return (0);
}

/**
 * Function: elxsli_is_lancer_hba
 * Description: Check this is a Lancer hba
 * @param [in] - phba - pointer to an hba structure for the device.
 * @return int returns 1 if true, else 0
 */
int elxsli_is_lancer_hba(elxsli_hba_t *phba)
{
    struct pci_dev *pdev;

    if (!phba->pcidev) {
        return (0);
    } else {
        pdev = phba->pcidev;
    }
    return (elxsli_is_lancer_dev(pdev));
}

/**
 * Function: elxsli_is_lancer_G5_dev
 * Description: Check if this device is a Lancer G5 ASIC
 * @param [in] - u16 device_id - PCI device id
 * @return int returns 1 if true, else 0
 */
int elxsli_is_lancer_G5_dev(struct pci_dev *pdev)
{
    int i;

    for (i = 0; i < LANG5_DEVICE_TBL_LEN; i++) {
        if ((pdev->vendor == lanG5_pci_device_id_table[i].vendor_id) &&
            (pdev->device == lanG5_pci_device_id_table[i].device_id)) {
            return (1);
        }
    }
    return (0);
}

/**
 * Function: elxsli_is_lancer_G5_hba
 * Description: Check this is a Lancer G5 hba
 * @param [in] - phba - pointer to an hba structure for the device.
 * @return int returns 1 if true, else 0
 */
int elxsli_is_lancer_G5_hba(elxsli_hba_t *phba)
{
    struct pci_dev *pdev;

    if (!phba->pcidev) {
        return (0);
    } else {
        pdev = phba->pcidev;
    }
    return (elxsli_is_lancer_G5_dev(pdev));
}

/**
 * Function: elxsli_is_lancer_G6_dev
 * Description: Check if this device is a Lancer G6 ASIC
 * @param [in] - u16 device_id - PCI device id
 * @return int returns 1 if true, else 0
 */
int elxsli_is_lancer_G6_dev(struct pci_dev *pdev)
{
    int i;

    for (i = 0; i < LANG6_DEVICE_TBL_LEN; i++) {
        if ((pdev->vendor == lanG6_pci_device_id_table[i].vendor_id) &&
            (pdev->device == lanG6_pci_device_id_table[i].device_id)) {
            return (1);
        }
    }
    return (0);
}

/**
 * Function: elxsli_is_lancer_G6_hba
 * Description: Check this is a Lancer G6 hba
 * @param [in] - phba - pointer to an hba structure for the device.
 * @return int returns 1 if true, else 0
 */
int elxsli_is_lang6_hba(elxsli_hba_t *phba)
{
    struct pci_dev *pdev;

    if (!phba->pcidev) {
        return (0);
    } else {
        pdev = phba->pcidev;
    }
    return (elxsli_is_lancer_G6_dev(pdev));
}

/**
 * Function: elxsli_is_prism_dev
 * Description: Check if this device is a Prism ASIC
 * @param [in] - u16 device_id - PCI device id
 * @return int returns 1 if true, else 0
 */
int elxsli_is_prism_dev(struct pci_dev *pdev)
{
    int i;

    for (i = 0; i < PRISM_DEVICE_TBL_LEN; i++) {
        if ((pdev->vendor == prism_pci_device_id_table[i].vendor_id) &&
            (pdev->device == prism_pci_device_id_table[i].device_id)) {
            return (1);
        }
    }
    return (0);
}

/**
 * Function: elxsli_is_prism_hba
 * Description: Check if this is a Prism hba
 * @param [in] - phba - pointer to an hba structure for the device.
 * @return int returns 1 if true, else 0
 */
int elxsli_is_prism_hba(elxsli_hba_t *phba)
{
    struct pci_dev *pdev;

    if (!phba->pcidev) {
        return (0);
    } else {
        pdev = phba->pcidev;
    }
    return (elxsli_is_prism_dev(pdev));
}

/**
 * Function: elxsli_is_fc_hba
 * Description: Check this is a Fibre Channel hba
 * @param [in] - phba - pointer to an hba structure for the device.
 * @return int returns 1 if true, else 0
 */
int elxsli_is_fc_hba(elxsli_hba_t *phba)
{
    struct pci_dev *pdev;

    if (!phba->pcidev) {
        return (0);
    } else {
        pdev = phba->pcidev;
    }
    return (elxsli_is_lancer_dev(pdev));
}

/**
 * Function: elxsli_is_fc
 * Description: Check if this device is a Fibre Channel ASIC
 * @param [in] - u16 device_id - PCI device id
 * @return int returns 1 if true, else 0
 */
int elxsli_is_fc(u16 device_id)
{
    switch (device_id) {
      case PCI_DEVICE_ID_FC_LANCER_PF:
      case PCI_DEVICE_ID_FC_LANCER_VF:
      case PCI_DEVICE_ID_FCOE_LANCER_PF:
      case PCI_DEVICE_ID_FCOE_LANCER_VF:
      case PCI_DEVICE_ID_LANCER_G6:
      case PCI_DEVICE_ID_LANCER_G6_ATTO:
      case PCI_DEVICE_ID_FC_PRISM_G7:
      case PCI_DEVICE_ID_PRISM_G7_ATTO:
          return (1);
          break;
      default:
          return (0);
          break;
    }
}

/**
 * Function: elxsli_is_prism_fc
 * Description: Check if this device is a Prism FC ASIC
 * @param [in] - u16 device_id - PCI device id
 * @return int returns 1 if true, else 0
 */
int elxsli_is_prism_fc(u16 device_id)
{
    switch (device_id) {
      case PCI_DEVICE_ID_FC_PRISM_G7_DEFAULT:
      case PCI_DEVICE_ID_FC_PRISM_G7:
      case PCI_DEVICE_ID_PRISM_G7_ATTO:
          return (1);
          break;
      default:
          return (0);
          break;
    }
}

/**
 * Function: elxsli_is_lancer_G6_fc
 * Description: Check if this device is a Lancer G6 FC ASIC
 * @param [in] - u16 device_id - PCI device id
 * @return int returns 1 if true, else 0
 */
int elxsli_is_lancer_G6_fc(u16 device_id)
{
    switch (device_id) {
      case PCI_DEVICE_ID_LANCER_G6_DEFAULT:
      case PCI_DEVICE_ID_LANCER_G6:
      case PCI_DEVICE_ID_LANCER_G6_ATTO:
          return (1);
          break;
      default:
          return (0);
          break;
    }
}

/**
 * Function: elxsli_is_armless
 * Description: Check this ASIC is in ARMless (default) mode.
 * @param [in] - u16 device_id - PCI device id
 * @return int returns 1 if true, else 0
 */
int elxsli_is_armless(u16 device_id)
{
    switch (device_id) {
      case PCI_DEVICE_ID_LANCER_G6_DEFAULT:
      case PCI_DEVICE_ID_LANCER_DEFAULT:
      case PCI_DEVICE_ID_FC_PRISM_G7_DEFAULT:
          return (1);
          break;
      default:
          return (0);
          break;
    }
}

/**
 * Function: elxsli_is_lancer_nic
 * Description: Check this device is a Lancer NIC
 * @param [in] - u16 device_id - PCI device id
 * @return int returns 1 if true, else 0
 */
int elxsli_is_lancer_nic(u16 device_id)
{
    switch (device_id) {
      case PCI_DEVICE_ID_NIC_LANCER_PF:
          return (1);
          break;
      default:
          return (0);
          break;
    }
}

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 21)
#if defined(RHEL_MINOR) && RHEL_MINOR < 4
/**
 * Function: pci_select_bars
 * @param [in] - struct pci_dev* - dev
 * @param [in] - unsigned long - flags
 * @return int - number of bar registers
 */
int pci_select_bars(struct pci_dev *dev, unsigned long flags)
{
    int i, bars = 0;

    for (i = 0; i < PCI_NUM_RESOURCES; i++) {
        if (pci_resource_flags(dev, i) & flags) {
            bars |= (1 << i);
        }
    }
    return (bars);
}

/**
 * Function: pci_request_selected_regions
 * @param [in] - struct pci_dev* - pdev
 * @param [in] - int - bars
 * @param [in] - char* - res_name
 * @return 0 - successful, other values - error
 */
int pci_request_selected_regions(struct pci_dev *pdev,
                                 int bars, char *res_name)
{
    int i;

    for (i = 0; i < 6; i++) {
        if (bars & (1 << i)) {
            if (pci_request_region(pdev, i, res_name)) {
                while (--i >= 0)
                    if (bars & (1 << i)) {
                        pci_release_region(pdev, i);
                    }
                return (-EBUSY);
            }
        }
    }
    return (0);
}

/**
 * Function: pci_release_selected_regions
 * @param [in] - struct pci_dev* - pdev
 * @param [in] - int bars
 */
void pci_release_selected_regions(struct pci_dev *pdev, int bars)
{
    int i;

    for (i = 0; i < 6; i++) {
        if (bars & (1 << i)) {
            pci_release_region(pdev, i);
        }
    }
}
#endif
#endif

/**
 * Function: elxsli_enable_pci_dev_fc - Enable a generic PCI device (FC ASIC).
 * This routine is invoked to enable the PCI device that is common to all
 * PCI devices.
 * @phba: pointer to elxsli hba data structure.
 * @return 0 - successful, other values - error
 */
static int elxsli_enable_pci_dev_fc(elxsli_hba_t *phba)
{
    struct pci_dev *pdev;
    int rc;

    /* Obtain PCI device reference */
    if (!phba->pcidev) {
        return (-ENODEV);
    } else {
        pdev = phba->pcidev;
    }

    /* Enable PCI device */
    if (pci_enable_device(pdev)) {
        PRINT_LOG_MSG(phba, KERN_WARNING, "pci_enable_device: ERROR\n");
        return (-ENODEV);
    }
    /* Request PCI resource for the device */
    if (pci_request_regions(pdev, ELXSLI_DRIVER_NAME)) {
        pci_disable_device(pdev);
        return (-ENODEV);
    }

    /* Set up device as PCI master and save state for EEH */
    pci_set_master(pdev);
    rc = pci_set_mwi(pdev);
    if (rc) {
        return (-ENODEV);
    }

    pci_intx(pdev, 0);  /* disable ints */
    pci_save_state(pdev);
    return (0);
}

/**
 * Function: elxsli_disable_pci_dev - Disable a generic PCI device.
 * This routine is invoked to disable the PCI device that is common to all
 * PCI devices.
 * @phba: pointer to elxsli hba data structure.
 */
static void elxsli_disable_pci_dev(elxsli_hba_t *phba)
{
    struct pci_dev *pdev;
    int bars;

    /* Obtain PCI device reference */
    if (!phba->pcidev) {
        return;
    } else {
        pdev = phba->pcidev;
    }
    /* Select PCI BARs */
    bars = pci_select_bars(pdev, IORESOURCE_MEM);

    /* Release PCI resource and disable PCI device */
    pci_release_selected_regions(pdev, bars);
    pci_disable_device(pdev);

    /* Null out PCI private reference to driver */
    pci_set_drvdata(pdev, NULL);

    return;
}

/**
 * Function: elxsli_pci_mem_setup_fc_asic - Setup SLI4 HBA PCI memory space
 * (Lancer).
 * This routine is invoked to set up the PCI device memory space for device
 * with SLI-4 interface spec.
 * @phba: pointer to elxsli hba data structure.
 * @return 0 - successful, other values - error
 */
static int elxsli_pci_mem_setup_fc_asic(elxsli_hba_t *phba)
{
    struct pci_dev *pdev = phba->pcidev;
    unsigned long barmap_len;
    int error = -ENODEV;

    if (dma_set_mask(pdev, DMA_BIT_MASK(64)) != 0 ||
        dma_set_coherent_mask(pdev, DMA_BIT_MASK(64)) != 0) {
        if (dma_set_mask(pdev, DMA_BIT_MASK(32)) != 0 ||
            dma_set_coherent_mask(pdev, DMA_BIT_MASK(32)) != 0) {
            PRINT_LOG_MSG(phba, KERN_ERR, "set_dma_mask size failed\n");
            return (error);
        }
    }

    phba->sli4_hba.pcicfg_regs_memmap_p = 0;
    phba->sli4_hba.drbl_regs_memmap_p = 0;
    phba->sli4_hba.diag_regs_memmap_p = 0;

    if (elxsli_is_armless(pdev->device)) {
        phba->pci_bar0_map = pci_resource_start(pdev, PCI_64BIT_BAR0);
        if (!phba->pci_bar0_map) {
            PRINT_LOG_MSG(phba, KERN_ERR,
                          "No BAR0 for function with device ID %x\n",
                          phba->device_id);
            return (error);
        }

        barmap_len = pci_resource_len(pdev, PCI_64BIT_BAR0);
        phba->sli4_hba.pcicfg_regs_memmap_p = ioremap(phba->pci_bar0_map,
                                                      barmap_len);
        if (!phba->sli4_hba.pcicfg_regs_memmap_p) {
            PRINT_LOG_MSG(phba, KERN_ERR, "ioremap failed for BAR0\n");
            return (error);
        }

        PRINT_DEBUG_LOG(phba, "BAR0: start: %lx len: %lx map: %p\n",
                        phba->pci_bar0_map, barmap_len,
                        (void *)phba->sli4_hba.pcicfg_regs_memmap_p);
        return (0);

    } else {
        phba->pci_bar0_map = pci_resource_start(pdev, PCI_64BIT_BAR0);
        if (!phba->pci_bar0_map) {
            PRINT_LOG_MSG(phba, KERN_ERR,
                          "No BAR0 for function with device ID %x\n",
                          phba->device_id);
            return (error);
        }

        barmap_len = pci_resource_len(pdev, PCI_64BIT_BAR0);
        phba->sli4_hba.pcicfg_regs_memmap_p = ioremap(phba->pci_bar0_map,
                                                      barmap_len);
        if (!phba->sli4_hba.pcicfg_regs_memmap_p) {
            PRINT_LOG_MSG(phba, KERN_ERR, "ioremap failed for BAR0\n");
            return (error);
        }

        PRINT_DEBUG_LOG(phba, "BAR0: start: %lx len: %lx map: %p\n",
                        phba->pci_bar0_map, barmap_len,
                        (void *)phba->sli4_hba.pcicfg_regs_memmap_p);

        phba->pci_bar2_map = pci_resource_start(pdev, PCI_64BIT_BAR2);
        if (!phba->pci_bar2_map) {
            PRINT_LOG_MSG(phba, KERN_INFO,
                          "No BAR2 on Function %d\n",
                          phba->pci_function_number);
        } else {
            barmap_len = pci_resource_len(pdev, PCI_64BIT_BAR2);
            phba->sli4_hba.drbl_regs_memmap_p = ioremap(phba->pci_bar2_map,
                                                        barmap_len);
            PRINT_DEBUG_LOG(phba, "BAR2: start: %lx len: %lx map: %p\n",
                            phba->pci_bar2_map, barmap_len,
                            (void *)phba->sli4_hba.drbl_regs_memmap_p);

            if (!phba->sli4_hba.drbl_regs_memmap_p) {
                PRINT_LOG_MSG(phba, KERN_ERR, "ioremap failed for BAR2\n");
            }
        }

        phba->pci_bar4_map = pci_resource_start(pdev, PCI_64BIT_BAR4);
        if (!phba->pci_bar4_map) {
            PRINT_LOG_MSG(phba, KERN_INFO,
                          "No BAR4 on Function %d\n",
                          phba->pci_function_number);
        } else {
            barmap_len = pci_resource_len(pdev, PCI_64BIT_BAR4);
            phba->sli4_hba.diag_regs_memmap_p = ioremap(phba->pci_bar4_map,
                                                        barmap_len);
            PRINT_DEBUG_LOG(phba, "BAR4: start: %lx len: %lx map: %p\n",
                            phba->pci_bar4_map, barmap_len,
                            (void *)phba->sli4_hba.diag_regs_memmap_p);

            if (!phba->sli4_hba.diag_regs_memmap_p) {
                PRINT_LOG_MSG(phba, KERN_ERR, "ioremap failed for BAR4\n");
            }
        }

        if (phba->sli4_hba.pcicfg_regs_memmap_p) {
            if (elxsli_is_lancer_nic(phba->device_id)) {
                phba->sli4_hba.NICRQDBregaddr = \
                    phba->sli4_hba.pcicfg_regs_memmap_p + \
                    ELXSLI_NIC_RQ_DOORBELL;
                phba->sli4_hba.RQDBregaddr = \
                    phba->sli4_hba.NICRQDBregaddr;
                phba->sli4_hba.NICRQDB2regaddr = \
                    phba->sli4_hba.pcicfg_regs_memmap_p + \
                    ELXSLI_NIC_RQ_DOORBELL2;
                phba->sli4_hba.NICWQDBregaddr = \
                    phba->sli4_hba.pcicfg_regs_memmap_p + \
                    ELXSLI_NIC_WQ_DOORBELL;
                phba->sli4_hba.WQDBregaddr = \
                    phba->sli4_hba.NICWQDBregaddr;
            } else {
                if (elxsli_is_prism_fc(phba->device_id)) {
                    phba->sli4_hba.FCoERQDBregaddr = \
                        phba->sli4_hba.drbl_regs_memmap_p + \
                        ELXSLI_FC_RQ_DOORBELL;
                    phba->sli4_hba.RQDBregaddr = \
                        phba->sli4_hba.FCoERQDBregaddr;
                    phba->sli4_hba.FCoEWQDBregaddr = \
                        phba->sli4_hba.drbl_regs_memmap_p + \
                        ELXSLI_FCoE_WQ_DOORBELL;
                    phba->sli4_hba.WQDBregaddr = \
                        phba->sli4_hba.FCoEWQDBregaddr;
                    phba->sli4_hba.CQDBregaddr = \
                        phba->sli4_hba.drbl_regs_memmap_p + \
                        ELXSLI_CQ_DOORBELL;
                    phba->sli4_hba.MQDBregaddr = \
                        phba->sli4_hba.drbl_regs_memmap_p + \
                        ELXSLI_MQ6_DOORBELL;

                } else {
                    phba->sli4_hba.FCoERQDBregaddr = \
                        phba->sli4_hba.pcicfg_regs_memmap_p + \
                        ELXSLI_FCoE_RQ_DOORBELL;
                    phba->sli4_hba.RQDBregaddr = \
                        phba->sli4_hba.FCoERQDBregaddr;
                    phba->sli4_hba.FCoEWQDBregaddr = \
                        phba->sli4_hba.pcicfg_regs_memmap_p + \
                        ELXSLI_FCoE_WQ_DOORBELL;
                    phba->sli4_hba.WQDBregaddr = \
                        phba->sli4_hba.FCoEWQDBregaddr;
                    phba->sli4_hba.EQCQDBregaddr = \
                        phba->sli4_hba.pcicfg_regs_memmap_p + \
                        ELXSLI_EQCQ_DOORBELL;
                    phba->sli4_hba.CQDBregaddr = \
                        phba->sli4_hba.EQCQDBregaddr;
                    phba->sli4_hba.MQDBregaddr = \
                        phba->sli4_hba.pcicfg_regs_memmap_p + \
                        ELXSLI_MQ_DOORBELL;
                }
            }

            phba->sli4_hba.BMBXregaddr = \
                phba->sli4_hba.pcicfg_regs_memmap_p + \
                ELXSLI_BMBX;
            phba->sli4_hba.PSMPHRregaddr = \
                phba->sli4_hba.pcicfg_regs_memmap_p + \
                ELXSLI_SLIPORT_IF2_SMPHR;
            phba->sli4_hba.STATUSregaddr = \
                phba->sli4_hba.pcicfg_regs_memmap_p + \
                ELXSLI_SLIPORT_STATUS;
            phba->sli4_hba.CTRLregaddr = \
                phba->sli4_hba.pcicfg_regs_memmap_p + \
                ELXSLI_SLIPORT_CNTRL;
            phba->sli4_hba.ERR1regaddr = \
                phba->sli4_hba.pcicfg_regs_memmap_p + \
                ELXSLI_SLIPORT_ERR_1;
            phba->sli4_hba.ERR2regaddr = \
                phba->sli4_hba.pcicfg_regs_memmap_p + \
                ELXSLI_SLIPORT_ERR_2;
            phba->sli4_hba.PDEVregaddr = \
                phba->sli4_hba.pcicfg_regs_memmap_p + \
                ELXSLI_PHYSDEV_CTL_OFFSET;
            phba->sli4_hba.UERRLOregaddr = \
                phba->sli4_hba.pcicfg_regs_memmap_p + \
                ELXSLI_UERR_STATUS_LO;
            phba->sli4_hba.UERRHIregaddr = \
                phba->sli4_hba.pcicfg_regs_memmap_p + \
                ELXSLI_UERR_STATUS_HI;

            return (0);
        }
    }

    iounmap(phba->sli4_hba.pcicfg_regs_memmap_p);
    phba->sli4_hba.pcicfg_regs_memmap_p = 0;
    return (error);
}

/**
 * Function: elxsli_pci_mem_unset - Unset SLI4 HBA PCI memory space.
 * This routine is invoked to unset the PCI device memory space for device
 * with SLI-4 interface spec.
 * @phba: pointer to lpfc hba data structure.
 */
static void elxsli_pci_mem_unset(struct elxsli_hba *phba)
{
    struct pci_dev *pdev;

    /* Obtain PCI device reference */
    if (!phba->pcidev) {
        return;
    } else {
        pdev = phba->pcidev;
    }

    /* Unmap I/O memory space */
    if (!elxsli_is_lancer_hba(phba)) {
        if (phba->sli4_hba.drbl_regs_memmap_p) {
            iounmap(phba->sli4_hba.drbl_regs_memmap_p);
            phba->sli4_hba.drbl_regs_memmap_p = 0;
        }
        if (phba->sli4_hba.ctrl_regs_memmap_p) {
            iounmap(phba->sli4_hba.ctrl_regs_memmap_p);
            phba->sli4_hba.ctrl_regs_memmap_p = 0;
        }
    } else {
        if (phba->sli4_hba.diag_regs_memmap_p) {
            iounmap(phba->sli4_hba.diag_regs_memmap_p);
            phba->sli4_hba.diag_regs_memmap_p = 0;
        }

        if (phba->sli4_hba.drbl_regs_memmap_p) {
            iounmap(phba->sli4_hba.drbl_regs_memmap_p);
            phba->sli4_hba.drbl_regs_memmap_p = 0;
        }
    }

    if (phba->sli4_hba.pcicfg_regs_memmap_p) {
        iounmap(phba->sli4_hba.pcicfg_regs_memmap_p);
        phba->sli4_hba.pcicfg_regs_memmap_p = 0;
    }
    return;
}

/**
 * Function: elxsli_pci_probe_fc - Enable a Emulex FC PCI device (Lancer).
 * This routine is invoked to enable the PCI device that is common
 * to all PCI devices.
 * @phba: pointer to elxsli hba data structure.
 * @return 0 - successful, other values - error
 */
static int elxsli_pci_probe_fc(elxsli_hba_t *phba)
{
    struct pci_dev *pdev = phba->pcidev;

    switch (phba->sli_intf.bits.if_type) {
      case SLI_INTF_IF_TYPE_6: // Prism
      case SLI_INTF_IF_TYPE_2: /* Lancer */
      case SLI_INTF_IF_TYPE_3: /* Lancer NIC / RDMA */
          break;
      case SLI_INTF_IF_TYPE_0: /* Lancer Base Default */
          PRINT_DEV_MSG(pdev, KERN_ERR,
                        "IF_TYPE x%x %s - DEFAULT MODE\n",
                        phba->sli_intf.bits.if_type,
                        &phba->model_desc[0]);
          break;
      case SLI_INTF_IF_TYPE_1:
      default:
          PRINT_DEV_MSG(pdev, KERN_ERR,
                        "IF_TYPE x%x is not supported: Skipping %s\n",
                        phba->sli_intf.bits.if_type,
                        &phba->model_desc[0]);
          return (-EINVAL);
    }

    if ((phba->sli_intf.bits.valid != SLI_INTF_VALID) &&
        (!(elxsli_is_armless(pdev->device)))) {
        PRINT_DEV_MSG(pdev, KERN_ERR,
                      "SLI Validity Bits are invalid: Skipping\n");
        return (-EINVAL);
    }

    if (phba->sli_intf.bits.ft == SLI_INTF_FUNC_TYPE_VIRT) {
        PRINT_DEV_MSG(pdev, KERN_WARNING,
                      "Virtual Functions are not supported: Skipping %s\n",
                      &phba->model_desc[0]);
        return (-EINVAL);
    }

    if (elxsli_enable_pci_dev_fc(phba)) {
        PRINT_DEV_MSG(pdev, KERN_ERR,
                      "Cannot enable PCI device: Skipping %s\n",
                      &phba->model_desc[0]);
        return (-EINVAL);
    }

    /* Map various BAR registers */
    if (elxsli_pci_mem_setup_fc_asic(phba)) {
        PRINT_DEV_MSG(pdev, KERN_ERR,
                      "Cannot map BARs on PCI device: Skipping %s\n",
                      &phba->model_desc[0]);
        elxsli_disable_pci_dev(phba);
        return (-EINVAL);
    }

    return (0);
}

/**
 * Function: elxsli_pci_match_lancer - Match PCI device to a elxsli
 * adapter (Lancer and Prism)
 * This routine is invoked to see if the discovered PCI device is
 * a supported Emulex adapter.
 * @pdev: pointer to PCI device data structure.
 * @return 0 - successful, other values - error
 */
static elxsli_hba_t* elxsli_pci_match_lancer(struct pci_dev *pdev)
{
    elxsli_hba_t *phba;
    u16 id;
    int i, found = 0;

    for (i = 0; i < VENDOR_ID_TBL_LEN; i++) {
        if (oem_vendor_id_table[i].vendor_id == pdev->vendor) {
            PRINT_DEV_MSG(pdev, KERN_WARNING,
                          "Found PCI VEN/DEV ID %04X:%04X match\n",
                          pdev->vendor, pdev->device);
            found = 1;
            break;
        }
    }

    if (!found) {
        return NULL;
    }

    phba = elxsli_hba_add();
    if (phba == NULL) {
        printk(KERN_ERR "No memory available for HBA structures\n");
        return NULL;
    }

    /* Set reference to PCI device in HBA structure */
    phba->pcidev = pdev;
    phba->brd_number = phba->tag;
    phba->vendor_id = pdev->vendor;
    phba->device_id = pdev->device;
    phba->pci_bus_number = pdev->bus->number;
    phba->pci_device_number = (u8)PCI_SLOT(pdev->devfn);
    phba->pci_function_number = (u8)PCI_FUNC(pdev->devfn);
    phba->host_bus = pdev->bus->self->bus->number;
    phba->host_device = (u8)PCI_SLOT(pdev->bus->self->devfn);
    phba->host_function = (u8)PCI_FUNC(pdev->bus->self->devfn);
    phba->host_sub_bus = pdev->bus->number;

    if (pci_read_config_dword(pdev, ELXSLI_PCI_SLI_INTF,
                              &phba->sli_intf.dw)) {
        PRINT_DEV_MSG(pdev, KERN_WARNING,
                      "Cannot read PCI config space: sli_intf: Skipping\n");
        return (0);
    }

    if (pci_read_config_word(pdev, ELXSLI_PCI_SUB_VENDOR, &id)) {
        PRINT_DEV_MSG(pdev, KERN_WARNING,
                      "Cannot read PCI config space: subvendor ID: "
                      "Skipping\n");
        return (0);
    }

    phba->sub_vendor_id = id;

    if (pci_read_config_word(pdev, ELXSLI_PCI_SUB_SYSTEM, &id)) {
        PRINT_DEV_MSG(pdev, KERN_WARNING,
                      "Cannot read PCI config space: subsystem ID: "
                      "Skipping\n");
        return (0);
    }

    phba->sub_system_id = id;

    /* check for a valid Device ID match */
    for (i = 0; i < LANCER_DEVICE_TBL_LEN; i++) {
        if ((lancer_pci_device_id_table[i].vendor_id == phba->vendor_id) &&
            (lancer_pci_device_id_table[i].device_id == phba->device_id)) {
            if (elxsli_is_fc(phba->device_id)) {
                phba->flags |= ELXSLI_FCOE_SUPPORTED;
            }

            memset(&phba->model, 0, 32);
            memcpy(&phba->model, lancer_pci_device_id_table[i].model,
                   strlen(lancer_pci_device_id_table[i].model));
            PRINT_LOG_MSG(phba, KERN_ALERT, "Discovered device: %s\n",
                          phba->model);
            memset(&phba->model_desc, 0, 64);
            memcpy(&phba->model_desc,
                   lancer_pci_device_id_table[i].description,
                   strlen(lancer_pci_device_id_table[i].description));
            PRINT_LOG_MSG(phba, KERN_ALERT, "Model: %s\n",
                          phba->model_desc);
            return (phba);
        }
    }
    return (0);
}

/**
 * Function: elxsli_pci_cfg_save_regs
 * Save a copy of the PCI config space for this HBA function
 * @phba: pointer to elxsli hba data structure.
 * @return 0 - successful, other values - error
 */
int elxsli_pci_cfg_save_regs(elxsli_hba_t *phba)
{
    struct pci_dev *pdev = phba->pcidev;
    u8 *pci_data;
    int i;

    if (!pdev) {
        return (1);
    }

    pci_data = (u8 *)&phba->pci_cfg; /* use hba structure */
    for (i = 0; i < PCI_CFG_LEN; i++) {
        pci_read_config_byte(pdev, i, pci_data++);
    }
    return (0);
}

/**
 * Function: elxsli_init - Initialize the driver hardware
 * This routine will loop thru all PCI devices and discover the ones
 * that match PCI_VENDOR_IS_EMULEX vendor id.
 */
static void elxsli_init(void)
{
    struct pci_dev *pdev = NULL;
    elxsli_hba_t *phba;
    int rc = 0;

    INIT_LIST_HEAD(&elxsli_hba_list);

    gElxSliHbaCount = 0;
    elxsli_hba_next_instance = 0;

    while ((pdev = pci_get_device(PCI_ANY_ID, PCI_ANY_ID, pdev)) != NULL) {
        phba = elxsli_pci_match_lancer(pdev);
        if (phba) {
            /* Double check with SLI intf that SLI revision is valid
               for driver support */
            if ((phba->sli_intf.bits.valid == SLI_INTF_VALID) &&
                (phba->sli_intf.bits.sli_rev == SLI_INTF_REV_SLI4)) {
                phba->flags |= ELXSLI_HBAINFO_SLI4;
                rc = elxsli_pci_probe_fc(phba);
            } else {  /* do we have a LANCER/PRISM default device? */
                if (elxsli_is_armless(pdev->device)) {
                    phba->flags |= ELXSLI_HBAINFO_BAR_ONLY;
                    PRINT_LOG_MSG(phba, KERN_WARNING,
                                  "Found ARMless device: %x\n",
                                  pdev->device);
                    rc = elxsli_pci_probe_fc(phba);
                } else {
                    phba->flags |= ELXSLI_HBAINFO_SLI3;
                    PRINT_LOG_MSG(phba, KERN_WARNING,
                                  "Unsupported SLI revision: Skipping\n");
                    rc = -ENODEV;
                }
            }

            if (rc) {
                PRINT_LOG_MSG(phba, KERN_WARNING,
                              "elxsli_init returned error: %x\n", rc);
                phba->vendor_id = 0;
                elxsli_hba_delete(phba);
                continue;
            }

            PRINT_LOG_MSG(phba, KERN_INFO,
                          "elxsli_init: %04X:%04X : "
                          "Bus:%02X Device:%02X Function:%02X\n",
                          phba->vendor_id, phba->device_id,
                          phba->pci_bus_number,
                          phba->pci_device_number,
                          phba->pci_function_number);

            if (!(elxsli_is_armless(pdev->device))) {
                PRINT_LOG_MSG(phba, KERN_INFO,
                              "elxsli_init: SLI Interface=0x%0x, Rev=0x%0x, "
                              "Family=0x%0x, Hint1=0x%0x, Hint2=0x%0x, FT=0x%0x",
                              phba->sli_intf.bits.if_type,
                              phba->sli_intf.bits.sli_rev,
                              phba->sli_intf.bits.sli_family,
                              phba->sli_intf.bits.sli_hint1,
                              phba->sli_intf.bits.sli_hint2,
                              phba->sli_intf.bits.ft);
            }

            elxsli_pci_cfg_save_regs(phba);
            phba->asic_revision = phba->pci_cfg.revision_id;
            PRINT_LOG_MSG(phba, KERN_INFO,
                          "elxsli_init: Initializing - %s\n",
                          phba->model_desc);

            rc = elxsli_init_hba(phba);
            if (rc) {
                PRINT_LOG_MSG(phba, KERN_WARNING,
                              "elxsli_init - returned status: %x\n",
                              rc);
            }
        }
    }
}

/**
 * Function: elxsli_uninit - Cleanup before driver is unloaded
 * This routine will loop thru all discovered HBAs and cleanup resources.
 */
static void elxsli_uninit(void)
{
    elxsli_hba_t * phba,*next;

    list_for_each_entry_safe(phba, next, &elxsli_hba_list, node) {
        elxsli_free_all_dma_buffers(phba);
        elxsli_uninit_hba(phba);
        elxsli_pci_mem_unset(phba);
        elxsli_disable_pci_dev(phba);
        PRINT_LOG_MSG(phba, KERN_INFO, "hba %d unload completed\n",
                      phba->tag);
    }

    elxsli_hba_free_all();
}


/**
 * Function: elxsli_ioctl_hbainfo - Get HBA information
 * This routine is invoked to fill in elxHBAINFO_t to be
 * returned to the user
 * @phba: pointer to elxsli hba data structure.
 * @cip: pointer to user information structure
 * @dataout: pointer to data to be copied back to the user
 * @return 0 - successful, other values - error
 */
static int elxsli_ioctl_hbainfo(elxsli_hba_t *phba,
                                ELXSLICMDINPUT_t *cip, void *dataout)
{
    int rc = 0;
    u32 value = 0;
    elxsliHBAINFO_t *pHbaInfo = (elxsliHBAINFO_t *)dataout;

    memset(pHbaInfo, 0, sizeof(elxsliHBAINFO_t));

    pHbaInfo->hbainfo_ver = ELXSLI_HBAINFO_VER;
    pHbaInfo->vendor_id = phba->vendor_id;
    pHbaInfo->device_id = phba->device_id;
    pHbaInfo->subvendor_id = phba->sub_vendor_id;
    pHbaInfo->subsystem_id = phba->sub_system_id;
    pHbaInfo->bus_number = phba->pci_bus_number;
    pHbaInfo->device_number = phba->pci_device_number;
    pHbaInfo->function = phba->pci_function_number;
    pHbaInfo->sli_intf = phba->sli_intf.dw;
    pHbaInfo->host_bridge.bus = phba->host_bus;
    pHbaInfo->host_bridge.device = phba->host_device;
    pHbaInfo->host_bridge.function = phba->host_function;
    pHbaInfo->host_bridge.sub_bus = phba->host_sub_bus;
    pHbaInfo->post_status = phba->post_status;
    pHbaInfo->ue_mask_lo = phba->ue_mask_lo;
    pHbaInfo->ue_mask_hi = phba->ue_mask_lo;
    pHbaInfo->ue_error_lo = phba->ue_error_lo;
    pHbaInfo->ue_error_hi = phba->ue_error_hi;
    pHbaInfo->asic_gen = phba->asic_gen;
    pHbaInfo->asic_revision = phba->asic_revision;
    pHbaInfo->phys_port = phba->phys_port;
    pHbaInfo->flags = phba->flags;

    memcpy(&pHbaInfo->drv_name[0], ELXSLI_DRIVER_NAME,
           sizeof(ELXSLI_DRIVER_NAME));
    sprintf(&pHbaInfo->drv_version[0], "%s", ELXSLI_DRIVER_VERSION);

    memcpy(&pHbaInfo->model[0], &phba->model[0], 32);
    memcpy(&pHbaInfo->model_desc[0], &phba->model_desc[0], 64);
    memcpy(&pHbaInfo->manufacturer[0], &phba->manufacturer[0], 32);
    memcpy(&pHbaInfo->pci_cfg, &phba->pci_cfg, sizeof(pci_cfg_t));

    PRINT_DEBUG_LOG(phba, "%04X:%04X : Bus:%02X Device:%02X Function:%02X\n",
                    pHbaInfo->vendor_id,
                    pHbaInfo->device_id,
                    pHbaInfo->bus_number,
                    pHbaInfo->device_number,
                    pHbaInfo->function);

    value = 0x1234;
    if (value == le32_to_cpu(value)) {
        PRINT_DEBUG_LOG(phba, "LITTLE ENDIAN MODE\n");
        pHbaInfo->flags |= ELXSLI_HBAINFO_LITTLE_ENDIAN;
    } else {
        PRINT_DEBUG_LOG(phba, "BIG ENDIAN MODE (NOT SUPPORTED)\n");
        pHbaInfo->flags |= ELXSLI_HBAINFO_BIG_ENDIAN;
    }

    cip->elxsli_outsz = sizeof(elxsliHBAINFO_t);
    return (rc);
}

/**
 * Function: elxsli_ioctl_reset - Reset the HBA function with a mbox command
 * This routine is invoked to issue a reset mbox command
 * @phba: pointer to elxsli hba data structure.
 * @cip: pointer to user information structure
 * @return 0 - successful, other values - error
 */
static int elxsli_ioctl_reset(elxsli_hba_t *phba, ELXSLICMDINPUT_t *cip)
{
    int rc = 0;

    if (phba->flags & ELXSLI_HBAINFO_BAR_ONLY) {
        return (-EBADE);
    }

    rc = elxsli_functional_reset(phba);
    return (rc);
}

/**
 * Function: elxsli_ioctl_reset_chip - Reset the chip, adapter bus slot
 * @phba: pointer to elxsli hba data structure.
 * @cip: pointer to user information structure
 * This routine is invoked to issue a reset chip to the adapter.
 * @return 0 - successful, other values - error
 */
static int elxsli_ioctl_reset_chip(elxsli_hba_t *phba, ELXSLICMDINPUT_t *cip)
{
    int rc = 0;

    rc = elxsli_chipreset(phba);
    return (rc);
}

/**
 * Function: elxsli_ioctl_read_pci_cfg_byte - read PCI config space byte
 * This routine is invoked to read the function PCI config space.
 * @phba: pointer to elxsli hba data structure.
 * @cip: pointer to user information structure
 * @dataout: pointer to data to be copied back to the user
 * @return 0 - successful, other values - error
 */
static int elxsli_ioctl_read_pci_cfg_byte(elxsli_hba_t *phba,
                                          ELXSLICMDINPUT_t *cip, u8 *dataout)
{
    int rc = 0, offset = 0;
    struct pci_dev *pdev;

    pdev = phba->pcidev;
    offset = (int)(unsigned long long)cip->elxsli_arg2;

    if (!dataout) {
        PRINT_LOG_MSG(phba, KERN_WARNING,
                      "elxsli_read_pci_cfg_byte - invalid data pointer\n");
        return (-EINVAL);  /* invalid param */
    }

    if (pci_read_config_byte(pdev, offset, dataout)) {
        rc = -EINVAL;
    }
    return (rc);
}

/**
 * Function: elxsli_ioctl_read_pci_cfg_word - read PCI config space word
 * This routine is invoked to read the function PCI config space.
 * @phba: pointer to elxsli hba data structure.
 * @cip: pointer to user information structure
 * @dataout: pointer to data to be copied back to the user
 * @return 0 - successful, other values - error
 */
static int elxsli_ioctl_read_pci_cfg_word(elxsli_hba_t *phba,
                                          ELXSLICMDINPUT_t *cip, u16 *dataout)
{
    int rc = 0, offset;
    struct pci_dev *pdev;

    pdev = phba->pcidev;
    offset = (int)(unsigned long long)cip->elxsli_arg2;

    if (!dataout) {
        PRINT_LOG_MSG(phba, KERN_WARNING,
                      "elxsli_read_pci_cfg_word - invalid data pointer\n");
        return (-EINVAL);  /* invalid param */
    }

    if (pci_read_config_word(pdev, offset, dataout)) {
        rc = -EINVAL;
    }
    return (rc);
}

/**
 * Function: elxsli_ioctl_read_pci_cfg_dword - read PCI config space byte
 * This routine is invoked to read the function PCI config space.
 * @phba: pointer to elxsli hba data structure.
 * @cip: pointer to user information structure
 * @dataout: pointer to data to be copied back to the user
 * @return 0 - successful, other values - error
 */
static int elxsli_ioctl_read_pci_cfg_dword(elxsli_hba_t *phba,
                                           ELXSLICMDINPUT_t *cip,
                                           u32 *dataout)
{
    int rc = 0, offset;
    struct pci_dev *pdev;

    pdev = phba->pcidev;
    offset = (int)(unsigned long long)cip->elxsli_arg2;

    if (!dataout) {
        PRINT_LOG_MSG(phba, KERN_WARNING,
                      "elxsli_read_pci_cfg_dword - invalid data pointer\n");
        return (-EINVAL);  /* invalid param */
    }

    rc = pci_read_config_dword(pdev, offset, dataout);
    if (rc) {
        rc = -EINVAL;
    }
    return (rc);
}

/**
 * Function: elxsli_ioctl_read_pci_cfg_space - read PCI config space
 * This routine is invoked to read the function PCI config space.
 * @phba: pointer to elxsli hba data structure.
 * @cip: pointer to user information structure
 * @dataout: pointer to data to be copied back to the user
 * @return 0 - successful, other values - error
 */
static int elxsli_ioctl_read_pci_cfg_space(elxsli_hba_t *phba,
                                           ELXSLICMDINPUT_t *cip,
                                           u8 *dataout)
{
    int rc = 0, j, offset, length;
    struct pci_dev *pdev;

    pdev = phba->pcidev;
    length = (int)cip->elxsli_outsz;
    offset = (int)(unsigned long long)cip->elxsli_arg2;

    if (!length) {
        PRINT_LOG_MSG(phba, KERN_WARNING,
                      "elxsli_read_pci_cfg_space - invalid length\n");
        return (0); /* nothing to do */
    }

    if (!dataout) {
        PRINT_LOG_MSG(phba, KERN_WARNING,
                      "elxsli_read_pci_cfg_space - invalid data pointer\n");
        return (-EINVAL);  /* invalid param */
    }

    /* the length must not be larger than 256 bytes */
    if (length > MAX_PCI_CFG_SIZE)
        return (-EINVAL);  /* invalid param */

    for (j = 0; j < length; j++) {
        if (pci_read_config_byte(pdev, offset + j, (u8 *)&dataout[j])) {
            rc = -EINVAL;
            break;
        }
    }
    return (rc);
}

/**
 * Function: elxsli_ioctl_write_pci_cfg_byte - write PCI config space
 * This routine is invoked to write a 8-bit word to the function PCI config space
 * space.
 * @phba: pointer to elxsli hba data structure.
 * @cip: pointer to user information structure
 * @return 0 - successful, other values - error
 */
static int elxsli_ioctl_write_pci_cfg_byte(elxsli_hba_t *phba,
                                           ELXSLICMDINPUT_t *cip)
{
    int rc = 0, offset;
    struct pci_dev *pdev;
    u8 *pdata;

    pdev = phba->pcidev;
    offset = (int)(unsigned long long)cip->elxsli_arg2;
    pdata = (u8 *)cip->elxsli_dataout;
    PRINT_DEBUG_LOG(phba, "elxsli_ioctl_write_pci_cfg_byte - "
                          "offset: %x, data: %02x\n",
                    offset, *pdata);
    if (pci_write_config_byte(pdev, offset, *pdata)) {
        rc = -EINVAL;
    }
    return (rc);
}

/**
 * Function: elxsli_ioctl_write_pci_cfg_word - write PCI config space
 * This routine is invoked to write a 16-bit word to the function PCI
 * config space
 * space.
 * @phba: pointer to elxsli hba data structure.
 * @cip: pointer to user information structure
 * @return 0 - successful, other values - error
 */
static int elxsli_ioctl_write_pci_cfg_word(elxsli_hba_t *phba,
                                           ELXSLICMDINPUT_t *cip)
{
    int rc = 0, offset;
    struct pci_dev *pdev;
    u16 *pdata;

    pdev = phba->pcidev;
    offset = (int)(unsigned long long)cip->elxsli_arg2;
    pdata = (u16 *)cip->elxsli_dataout;
    PRINT_DEBUG_LOG(phba, "elxsli_ioctl_write_pci_cfg_word - "
                          "offset: %x, data: %04x\n",
                    offset, *pdata);
    if (pci_write_config_word(pdev, offset, *pdata)) {
        rc = -EINVAL;
    }
    return (rc);
}

/**
 * Function: elxsli_ioctl_write_pci_cfg_word - write PCI config space
 * This routine is invoked to write a 32-bit word to the function PCI
 * config space.
 * @phba: pointer to elxsli hba data structure.
 * @cip: pointer to user information structure
 * @return 0 - successful, other values - error
 */
static int elxsli_ioctl_write_pci_cfg_dword(elxsli_hba_t *phba,
                                            ELXSLICMDINPUT_t *cip)
{
    int rc = 0, offset;
    struct pci_dev *pdev;
    u32 *pdata;

    pdev = phba->pcidev;
    offset = (int)(unsigned long long)cip->elxsli_arg2;
    pdata = (u32 *)cip->elxsli_dataout;
    PRINT_DEBUG_LOG(phba, "elxsli_ioctl_write_pci_cfg_dword - "
                          "offset: %x, data: %08x\n",
                    offset, *pdata);

    if (pci_write_config_dword(pdev, offset, *pdata)) {
        rc = -EINVAL;
    }
    return (rc);
}

/**
 * Function: elxsli_ioctl_write_pci_cfg_space - write PCI config space
 * This routine is invoked to write up to 256 bytes to the function PCI
 * config space.
 * @phba: pointer to elxsli hba data structure.
 * @cip: pointer to user information structure
 * @return 0 - successful, other values - error
 */
static int elxsli_ioctl_write_pci_cfg_space(elxsli_hba_t *phba,
                                            ELXSLICMDINPUT_t *cip)
{
    int rc = 0, j, length, offset;
    struct pci_dev *pdev;
    u8 *pdata;

    pdev = phba->pcidev;
    length = (int)(unsigned long long)cip->elxsli_arg1;

    if (!length) {
        PRINT_LOG_MSG(phba, KERN_WARNING,
                      "elxsli_write_pci_cfg_space - invalid param size\n");
        return (0);
    }

    /* the length must not be larger than 256 bytes */
    if (length > MAX_PCI_CFG_SIZE) {
        PRINT_LOG_MSG(phba, KERN_WARNING,
                      "elxsli_write_pci_cfg_space - invalid param size\n");
        return (-EINVAL);  /* invalid param */
    }

    offset = (int)(unsigned long long)cip->elxsli_arg2;
    pdata = (u8 *)cip->elxsli_dataout;

    for (j = 0; j < length; j++) {
        if (pci_write_config_byte(pdev, offset + j, *pdata++)) {
            rc = -EINVAL;
            break;
        }
    }
    return (rc);
}

/**
 * @brief Find a DMA buffer given its tag
 * Scan the devices dma buffer list for a matching tag
 * @param tag pointer to dma buffer tag
 * @return pointer to DMA buffer structure otherwise NULL
 */
static dma_buf_t* elxsli_dmabuf_find(u32 tag)
{
    dma_buf_t * dma,*next;

    PRINTK_DBG("%s\n", __func__);

    list_for_each_entry_safe(dma, next, &dmabuf_list, node) {
        if (dma->desc.tag == tag) {
            PRINTK_DBG("found tag %d dma ptr = %p\n", tag, dma);
            return dma;
        }
    }
    printk(KERN_INFO "elxsli_dmabuf_find : "
                     "tag %d dma buffer not found\n", tag);
    return NULL;
}

/**
 * Function: elxsli_ioctl_alloc_dma_buffer - allocate a dma buffer for user
 * @phba: pointer to elxsli hba data structure.
 * @cip: pointer to user information structure
 * @dataout: pointer to data to be copied back to the user
 * @return 0 - successful, other values - error
 */
static int elxsli_ioctl_alloc_dma_buffer(elxsli_hba_t *phba,
                                         ELXSLICMDINPUT_t *cip, u8 *dataout)
{
    int rc;
    dma_addr_t phys;
    dma_buf_t *dma;

//  PRINTK_DBG("%s\n", __func__);

    if (cip->elxsli_arg1 == NULL) {
        return (-EIO); /* null pointer arg */
    }

    dma = kzalloc(sizeof(dma_buf_t), GFP_KERNEL | GFP_DMA);
    if (!dma) {
        PRINT_LOG_MSG(phba, KERN_ERR, "elxsli_ioctl_alloc_dma_buffer - "
                                      "no buffer memory available\n");
        return (-ENOMEM);
    }

//  PRINTK_DBG("elxsli_ioctl_alloc_dma_buffer : dma ptr = %p, tag = %d\n", dma, dma->desc.tag);

    /* get user args */
    if ((rc = copy_from_user((u8 *)&dma->desc, (u8 *)cip->elxsli_arg1,
                             sizeof(dma_desc_t)))) {
        PRINT_LOG_MSG(phba, KERN_WARNING, "elxsli_ioctl_alloc_dma_buffer - "
                                          "descriptor copy error\n");
        kfree(dma);
        return (-EIO);
    }

//  PRINT_DEBUG_LOG(phba, "DMA descriptor:\n");
//  PRINT_HEX_DUMP_DWORDS(&dma->desc, sizeof(dma_desc_t));

    if (dma->desc.size == 0) {
        PRINT_LOG_MSG(phba, KERN_WARNING, "elxsli_ioctl_alloc_dma_buffer - "
                                          "size is null\n");
        kfree(dma);
        return (-EINVAL);
    }

    dma->desc.virt = dma_alloc_coherent(&phba->pcidev->dev, dma->desc.size,
                                        &phys, GFP_KERNEL);
    if (dma->desc.virt == NULL) {
        kfree(dma);
        PRINT_LOG_MSG(phba, KERN_WARNING, "elxsli_ioctl_alloc_dma_buffer: "
                                          "dma_alloc_coherent failed\n");
        return (-ENOMEM);
    }

    dma->desc.tag = dmabuf_next_instance++;
    dma->desc.phys = (void *)phys;
    list_add(&dma->node, &dmabuf_list);

    PRINTK_DBG("elxsli_ioctl_alloc_dma_buffer: phba=%p, phys: %p, virt: %p, "
               "size: %d, tag: %d\n",
               phba, dma->desc.phys, dma->desc.virt, dma->desc.size,
               dma->desc.tag);

    memcpy(dataout, (u8 *)&dma->desc, sizeof(dma_desc_t));
    cip->elxsli_outsz = sizeof(dma_desc_t);
    return (0);
}

/**
 * Function: elxsli_ioctl_free_dma_buffer - free an allocated dma buffer
 * @phba: pointer to elxsli hba data structure.
 * @cip: pointer to user information structure
 * @dataout: pointer to data to be copied back to the user
 * @return 0 - successful, other values - error
 */
static int elxsli_ioctl_free_dma_buffer(elxsli_hba_t *phba,
                                        ELXSLICMDINPUT_t *cip)
{
    int rc;
    dma_desc_t req;
    dma_buf_t *dma = NULL;

    if (cip->elxsli_arg1 == NULL) {
        return (-EIO);
    }

    memset(&req, 0, sizeof(dma_desc_t));

    if ((rc = copy_from_user((u8 *)&req, (u8 *)cip->elxsli_arg1,
                             sizeof(dma_desc_t)))) {
        PRINT_LOG_MSG(phba, KERN_WARNING, "elxsli_ioctl_free_dma_buffer - "
                                          "descriptor copy error\n");
        return (-EIO);
    }

    /* find the dma node */
    dma = elxsli_dmabuf_find(req.tag);
    if (dma == NULL) {
        PRINT_LOG_MSG(phba, KERN_WARNING, "elxsli_ioctl_free_dma_buffer - "
                                          "buffer not found \n");
        return (-EINVAL);
    }

    PRINTK_DBG("elxsli_ioctl_free_dma_buffer - free dma ptr = %p, "
               "tag = %d\n",
               dma, dma->desc.tag);

    list_del(&dma->node);
    dma_free_coherent(&phba->pcidev->dev, dma->desc.size,
                      dma->desc.virt, (uintptr_t)dma->desc.phys);
    return (0);
}

/**
 * Function: elxsli_free_all_dma_buffers
 * @phba: pointer to elxsli hba data structure.
 * @return 0 - successful, other values - error
 */
static int elxsli_free_all_dma_buffers(elxsli_hba_t *phba)
{
    dma_buf_t * dma,*next;

    PRINTK_DBG("%s dmabuf_list.prev=%p, dmabuf_list.next=%p\n",
               __func__, dmabuf_list.prev, dmabuf_list.next);

    if (list_empty(&dmabuf_list)) {
        PRINTK_DBG("dma_list head is empty\n");
        return (0);
    }

    /* clean up all dma buffers for this hba */
    list_for_each_entry_safe(dma, next, &dmabuf_list, node) {
        list_del(&dma->node);
        dma_free_coherent(&phba->pcidev->dev, dma->desc.size,
                          dma->desc.virt, (uintptr_t)dma->desc.phys);
    }
    return (0);
}

/**
 * Function: elxsli_ioctl_copy_to_user
 * @phba: pointer to elxsli hba data structure.
 * @cip: pointer to user information structure
 * @dataout: pointer to data to be copied back to the user
 * @return 0 - successful, other values - error
 */
static int elxsli_ioctl_copy_to_user(elxsli_hba_t *phba,
                                     ELXSLICMDINPUT_t *cip, u8 *dataout)
{
    int rc = 0;
    unsigned long len = 0, n = 0;
    u8 *host_ptr = NULL, *dma_buf = NULL;
    dma_desc_t dma_desc;

    if (cip->elxsli_arg1 == NULL) {
        PRINT_LOG_MSG(phba, KERN_INFO, "elxsli_copy_to_user: arg1 "
                                       "invalid (%p), rc=%x (-EINVAL)\n",
                      cip->elxsli_arg1, (-EINVAL));
        return (-EINVAL);
    }

    if (cip->elxsli_arg2 == NULL) {
        PRINT_LOG_MSG(phba, KERN_INFO, "elxsli_copy_to_user: arg2 "
                                       "invalid (%p), rc=%x (-EINVAL)\n",
                      cip->elxsli_arg2,  (-EINVAL));
        return (-EINVAL); /* null pointer arg */
    }

    if ((rc = copy_from_user((u8 *)&dma_desc, (u8 *)cip->elxsli_arg1,
                             sizeof(dma_desc_t)))) {
        PRINT_LOG_MSG(phba, KERN_INFO, "elxsli_copy_to_user: DMA_DESC "
                                       "READ ERROR ,rc=%x\n", (-EIO));
        return (-EIO);
    }

    host_ptr = (u8 *)cip->elxsli_arg2;
    cip->elxsli_dataout = host_ptr;
    dma_buf = (u8 *)dma_desc.virt;

    if ((dma_desc.offset == 0) && (dma_desc.offset_len == 0)) {
        len = (unsigned long)dma_desc.size;
    } else {
        dma_buf += dma_desc.offset;
        len = (unsigned long)dma_desc.offset_len;
        if (dma_buf + len > (u8 *)dma_desc.virt + dma_desc.size) {
            rc = (-EINVAL);
            PRINTK_DBG("elxsli_copy_to_user: dma_buf:%p, offset:0x%x, "
                       "offset_len:0x%x, rc:%x (-EINVAL)\n",
                       dma_buf, dma_desc.offset, dma_desc.offset_len, rc);
            PRINTK_DBG("elxsli_copy_to_user: OFFSET_ERROR, dma_desc.vert=%p,"
                       " dma_desc.phys=%p, dma_desc.size=0x%x\n",
                       dma_desc.virt, dma_desc.phys, dma_desc.size);
        }
    }

    if (!rc) {
        if (len <= ELXSLI_KMALLOC_MAX_ALLOC_SIZE) {
            memcpy(dataout, dma_buf, len);
            cip->elxsli_outsz = len;
        } else {
            cip->elxsli_outsz = 0;
            n = copy_to_user(host_ptr, dma_buf, len);
            if (n) {
                rc = (-EIO);
                PRINT_LOG_MSG(phba, KERN_INFO,
                              "elxsli_copy_to_user: COPY_ERROR, "
                              "bytes not copied=%lu, rc=%x\n", n, rc);
            }
        }
    }

    if (rc) {
        PRINT_LOG_MSG(phba, KERN_INFO, "elxsli_copy_to_user: "
                                       "RETURN STATUS rc=%x\n", rc);
    }
    return (rc);
}

/**
 * Function: elxsli_ioctl_copy_from_user
 * @phba: pointer to elxsli hba data structure.
 * @cip: pointer to user information structure
 * @return 0 - successful, other values - error
 */
static int elxsli_ioctl_copy_from_user(elxsli_hba_t *phba,
                                       ELXSLICMDINPUT_t *cip)
{
    int rc = 0;
    unsigned long len = 0, n = 0;
    u8 *host_ptr = NULL, *dma_buf = NULL;
    dma_desc_t dma_desc;

    if (cip->elxsli_arg1 == NULL) {
        rc = (-EINVAL); /* null pointer arg */
        PRINT_LOG_MSG(phba, KERN_INFO, "elxsli_copy_from_user arg1 "
                                       "invalid (%p), rc=%x (-EINVAL)\n",
                      cip->elxsli_arg1, rc);
        return (rc);
    }

    if (cip->elxsli_arg2 == NULL) {
        rc = (-EINVAL); /* null pointer arg */
        PRINT_LOG_MSG(phba, KERN_INFO, "elxsli_copy_from_user arg2 "
                                       "invalid (%p), rc=%x (-EINVAL)\n",
                      cip->elxsli_arg2, rc);
        return (rc);
    }

    if (copy_from_user((u8 *)&dma_desc, (u8 *)cip->elxsli_arg1,
                       sizeof(dma_desc_t))) {
        rc = (-EIO);
        PRINT_LOG_MSG(phba, KERN_INFO, "elxsli_copy_from_user: DMA_DESC "
                                       "READ ERROR, rc=%x (-EIO)\n", rc);
        return (rc);
    }

    host_ptr = (u8 *)cip->elxsli_arg2;
    dma_buf = (u8 *)dma_desc.virt;

    if ((dma_desc.offset == 0) && (dma_desc.offset_len == 0)) {
        len = (unsigned long)dma_desc.size;
    } else {
        dma_buf += dma_desc.offset;
        len = (unsigned long)dma_desc.offset_len;
        if (dma_buf + len > (u8 *)dma_desc.virt + dma_desc.size) {
            rc = (-EINVAL);
            PRINT_LOG_MSG(phba, KERN_INFO, "elxsli_copy_from_user: "
                                           "dma_buf:%p, offset:0x%x, "
                                           "offset_len:0x%x, "
                                           "rc:%x (-EINVAL)\n",
                          dma_buf, dma_desc.offset, dma_desc.offset_len, rc);
            PRINT_LOG_MSG(phba, KERN_INFO, "elxsli_copy_from_user: "
                                           "OFFSET_ERROR, dma_desc.vert=%p, "
                                           "dma_desc.phys=%p, "
                                           "dma_desc.size=0x%x\n",
                          dma_desc.virt, dma_desc.phys, dma_desc.size);
        }
    }

    if (!rc) {
        n = copy_from_user(dma_buf, host_ptr, len);
        if (n) {
            rc = (-EIO);
            PRINT_LOG_MSG(phba,
                          KERN_INFO, "elxsli_copy_from_user: COPY_ERROR, "
                                     "%lu bytes not copied, rc=%x (-EIO)\n",
                          n, rc);
        }
    }

    if (rc) {
        PRINT_LOG_MSG(phba, KERN_INFO, "elxsli_copy_from_user: "
                                       "RETURN STATUS rc=%x\n", rc);
    }
    return (rc);
}

/**
 * Function: elxsli_ioctl_rwreg
 * Description: This routine is invoked to read / write the
 * appropriate BAR register space.
 * @phba: pointer to elxsli hba data structure.
 * @cip: pointer to user information structure
 * @dataout: pointer to data to be copied back to the user
 * @return 0 - successful, other values - error
 */
static int elxsli_ioctl_rwreg(elxsli_hba_t *phba,
                              ELXSLICMDINPUT_t *cip, u32 *dataout)
{
    int rc = 0;
    u32 bar;
    u32 offset;
    u32 rwflag;
    u32 value;
    void __iomem *regaddr;

    /* offset MUST be a multiple of 4 */
    offset = (u32)((unsigned long)cip->elxsli_arg2);
    if ((offset & 0x3) != 0) {
        return (-EINVAL);
    }

    bar = (u32)((unsigned long)cip->elxsli_arg1);

    if ((elxsli_is_lancer_hba(phba)) && (bar == 1)) {
        PRINT_LOG_MSG(phba, KERN_WARNING,
                      "elxsli_ioctl_rwreg: Invalid BAR register\n");
        return (-EINVAL);
    }

    switch (bar) {
      case 0: /* BAR0 (64-bit) */
          regaddr = phba->sli4_hba.pcicfg_regs_memmap_p + offset;
          break;
      case 1: /* BAR1 (64-bit) */
          regaddr = phba->sli4_hba.ctrl_regs_memmap_p + offset;
          break;
      case 2: /* BAR2 (64-bit) */
          regaddr = phba->sli4_hba.drbl_regs_memmap_p + offset;
          break;
      default:
          return (-ERANGE);
    }

    rwflag = cip->elxsli_flag;
    switch (rwflag) {
      case ELXSLI_RWREG_READ:
          value = ioread32(regaddr);
          cip->elxsli_outsz = sizeof(u32);
          *dataout = value;
          break;
      case ELXSLI_RWREG_WRITE:
          value = (u32)((unsigned long)cip->elxsli_arg3);
          iowrite32(value, regaddr);
          *dataout = 0; /* always 0 */
          break;
      default:
          return (-ERANGE);
    }
    return (rc);
}

/**
 * Function: elxsli_ioctl_rwreg_fc
 * Description: Read/Write to the appropriate BAR register
 * space.
 * @phba: pointer to elxsli hba data structure.
 * @cip: pointer to user information structure
 * @dataout: pointer to data to be copied back to the user
 * @return 0 - successful, other values - error
 */
static int elxsli_ioctl_rwreg_fc(elxsli_hba_t *phba,
                                 ELXSLICMDINPUT_t *cip, u32 *dataout)
{
    int rc = 0;
    u32 bar;
    u32 offset;
    u32 rwflag;
    u32 value;
    void __iomem *regaddr = 0;

    /* offset MUST be a multiple of 4 */
    offset = (u32)((unsigned long)cip->elxsli_arg2);
    if ((offset & 0x3) != 0) {
        return (-EINVAL);
    }

    bar = (u32)((unsigned long)cip->elxsli_arg1);
    switch (bar) {
      case 0:    /* BAR0 (64-bit) */
          regaddr = phba->sli4_hba.pcicfg_regs_memmap_p + offset;
          break;
      case 1:    /* BAR1 (64-bit) */
          if (elxsli_is_prism_hba(phba)) {
              regaddr = phba->sli4_hba.drbl_regs_memmap_p + offset;
              break;
          } else {
              PRINT_LOG_MSG(phba, KERN_WARNING,
                            "elxsli_ioctl_rwreg_fc: INVALID BAR "
                            "register index: %d\n",
                            bar);
              return (-ERANGE);
          }
      case 2:    /* BAR2 (64-bit) */
          regaddr = phba->sli4_hba.diag_regs_memmap_p + offset;
          break;
      default:
          PRINT_LOG_MSG(phba, KERN_WARNING,
                        "elxsli_ioctl_rwreg_fc: INVALID BAR register "
                        "index: %d\n",
                        bar);
          return (-ERANGE);
    }

    rwflag = cip->elxsli_flag;
    switch (rwflag) {
      case ELXSLI_RWREG_READ:
          value = ioread32(regaddr);
          cip->elxsli_outsz = sizeof(u32);
          *dataout = value;
          break;
      case ELXSLI_RWREG_WRITE:
          value = (u32)((unsigned long)cip->elxsli_arg3);
          iowrite32(value, regaddr);
          break;
      default:
          return (-ERANGE);
    }
    return (rc);
}

/**
 * Function: elxsli_ioctl_issue_mb - Issue a mbox command in the BMBX
 * This routine is invoked to issue a mbox command in the BMBX
 * @phba: pointer to elxsli hba data structure.
 * @cip: pointer to user information structure
 * @dataout: pointer to data to be copied back to the user
 * @return 0 - successful, other values - error
 */
static int elxsli_ioctl_issue_mb(elxsli_hba_t *phba,
                                 ELXSLICMDINPUT_t *cip, u32 *dataout)
{
    fc_mqe_t *fc_mqe;
    sli_mqe_t *mqe;
    sli_header_t *sli_header;
    void *virt = NULL;
    dma_addr_t phys;
    u32 extsize, mbsize;
    int rc = 0;

    if (phba->flags & ELXSLI_HBAINFO_BAR_ONLY) {
        PRINT_LOG_MSG(phba, KERN_WARNING,
                      "elxsli_ioctl_issue_mb - FW NOT READY ERROR");
        return (-EBADE);
    }

    mqe = (sli_mqe_t *)&phba->sli4_hba.mbox;
    memset(mqe, 0, SLI_MQE_LEN);

    if (phba->flags & ELXSLI_FCOE_SUPPORTED) {
        fc_mqe = (fc_mqe_t *)&phba->sli4_hba.mbox;
        fc_mqe->hdr.command = MBX_SLI_CONFIG;
        mqe = (sli_mqe_t *)&fc_mqe->hdr.payload;
        sli_header = (sli_header_t *)&(mqe->payload.sli_header);
    } else {
        sli_header = (sli_header_t *)&(mqe->payload.sli_header);
    }

    mbsize = (u32)((unsigned long)cip->elxsli_arg2);
    extsize = (u32)((unsigned long)cip->elxsli_arg3);

    if (extsize) {
        virt = dma_alloc_coherent(
               &phba->pcidev->dev, mbsize + extsize, &phys, GFP_KERNEL);
        if (!virt) {
            PRINT_LOG_MSG(
                phba, KERN_WARNING,
                "elxsli_ioctl_issue_mb: Cannot allocate memory\n");
            return (-ENOMEM);
        }

        memset(virt, 0, mbsize + extsize);
        if ((rc = copy_from_user((u8 *)virt, (u8 *)cip->elxsli_arg1,
                    mbsize + extsize))) {

            PRINT_LOG_MSG(phba, KERN_WARNING,
                          "elxsli: extended buffer copy error\n");
            dma_free_coherent(
                &phba->pcidev->dev, mbsize + extsize, virt, phys);
            return (-EIO);
        }

        sli_header = (sli_header_t *)virt;
        mqe->mqe_hdr.embedded = 0;
        mqe->mqe_hdr.sge_count = 1;
        mqe->mqe_hdr.payload_length = (mbsize + extsize);
        mqe->payload.sge[0].pa_lo = putPaddrLow(phys);
        mqe->payload.sge[0].pa_hi = putPaddrHigh(phys);
        mqe->payload.sge[0].length = mbsize + extsize;

        elxsli_sli_pcimem_bcopy(sli_header, sli_header,
                                mbsize + extsize);
    } else {
        mqe->mqe_hdr.embedded = 1;
        mqe->mqe_hdr.payload_length = mbsize;
        if ((rc = copy_from_user((u8 *)sli_header,
                                 (u8 *)cip->elxsli_arg1,
                                 mbsize))) {
            return (-EIO);
        }
        elxsli_sli_pcimem_bcopy(sli_header, sli_header, mbsize + extsize);
    }

    rc = elxsli_issue_mbox(phba);
    if (extsize) {
        memcpy((u8 *)dataout, sli_header, mbsize + extsize);
        dma_free_coherent(&phba->pcidev->dev, mbsize + extsize, virt, phys);
    } else {
        memcpy((u8 *)dataout, sli_header, mbsize);
    }
    return (rc);
}

/**
 * Function: elxsli_ioctl_issue_fc_mb - Issue a FC mbox command in the BMBX
 * This routine is invoked to issue a FC mbox command in the BMBX
 * @phba: pointer to elxsli hba data structure.
 * @cip: pointer to user information structure
 * @dataout: pointer to data to be copied back to the user
 * @return 0 - successful, other values - error
 */
static int elxsli_ioctl_issue_fc_mb(elxsli_hba_t *phba,
                                    ELXSLICMDINPUT_t *cip, u32 *dataout)
{
    fc_mqe_t *fc_mqe;
    u32 mbsize;
    int rc = 0;

    if (!(phba->flags & ELXSLI_FCOE_SUPPORTED)) {
        PRINT_LOG_MSG(phba, KERN_WARNING,
                      "elxsli_ioctl_issue_fc_mb - FC/FCOE is not supported");
        return (-EINVAL);
    }

    if (phba->flags & ELXSLI_HBAINFO_BAR_ONLY) {
        PRINT_LOG_MSG(phba, KERN_WARNING,
                      "elxsli_ioctl_issue_fc_mb - FW NOT READY ERROR");
        return (-EBADE);
    }

    fc_mqe = (fc_mqe_t *)&phba->sli4_hba.mbox;
    memset(fc_mqe, 0, FC_MQE_LEN);
    mbsize = (u32)((unsigned long)cip->elxsli_arg2);
    if ((rc = copy_from_user((u8 *)fc_mqe, (u8 *)cip->elxsli_arg1,
                             mbsize))) {
        return (-EIO);
    }

    rc = elxsli_issue_mbox(phba);
    memcpy(dataout, fc_mqe, mbsize);
    return (rc);
}

/**
 * Function: elxsli_do_ioctl - Process a user initiated IOCTL
 * This routine is invoked to process a user initiated IOCTL.
 * @cip: pointer to user information structure
 * @return 0 - successful, other values - error
 */
static int elxsli_do_ioctl(ELXSLICMDINPUT_t *cip)
{
    elxsli_hba_t *phba = NULL;
    void *dataout = NULL;
    u32 total_mem = 0;
    int rc = 0;

    if (cip->elxsli_index > gElxSliHbaCount) {
        printk(KERN_ERR "HBA index is invalid : 0x%04X\n", cip->elxsli_index);
        return (-ERANGE);
    }

    phba = elxsli_hba_find(cip->elxsli_index);
    if (phba == NULL) {
        return (-ENXIO); /* device not found */
    }

    if (phba->vendor_id == 0) {
        PRINT_LOG_MSG(phba, KERN_WARNING, "ERROR: HA Vendor ID is invalid\n");
        return (-ERANGE);
    }

    /* Allocate memory for ioctl data */
    total_mem = ELXSLI_KMALLOC_MAX_ALLOC_SIZE; /*  Max. 64K bytes */
    dataout = kzalloc(total_mem, GFP_KERNEL);
    if (dataout == NULL) {
        PRINT_LOG_MSG(phba, KERN_WARNING, "Cannot kmalloc requested ioctl data buffer size\n");
        return (-ENOMEM);
    }

    mutex_lock(&phba->elxsli_lock);
    switch (cip->elxsli_cmd) {
      case ELXSLI_HBAINFO:
          if (cip->elxsli_flag != ELXSLI_HBAINFO_VER) {
              rc = -EINVAL;
          } else {
              rc = elxsli_ioctl_hbainfo(phba, cip, dataout);
          }
          break;

      case ELXSLI_FUNCTION_RESET:
          rc = elxsli_ioctl_reset(phba, cip);
          *((u32 *)dataout) = (u32)rc;
          cip->elxsli_outsz = sizeof(u32);
          break;

      case ELXSLI_RESET_CHIP:
          rc = elxsli_ioctl_reset_chip(phba, cip);
          *((u32 *)dataout) = (u32)rc;
          cip->elxsli_outsz = sizeof(u32);
          break;

      case ELXSLI_ISSUE_MB:
          rc = elxsli_ioctl_issue_mb(phba, cip, (u32 *)dataout);
          if (rc) {
              PRINT_LOG_MSG(phba, KERN_INFO,
                            "elxsli_ioctl_issue_mb returned: 0x%x\n",
                            rc);
          }
          break;

      case ELXSLI_ISSUE_FC_MB:
          rc = elxsli_ioctl_issue_fc_mb(phba, cip, (u32 *)dataout);
          if (rc) {
              PRINT_LOG_MSG(phba, KERN_INFO,
                            "elxsli_ioctl_issue_fc_mb returned: 0x%x\n",
                            rc);
          }
          break;

      case ELXSLI_RWREG:
          if (elxsli_is_fc_hba(phba)) {
              rc = elxsli_ioctl_rwreg_fc(phba, cip, (u32 *)dataout);
          } else {
              rc = elxsli_ioctl_rwreg(phba, cip, (u32 *)dataout);
          }
          break;

      case ELXSLI_GET_REV:
          ((elxsliREVINFO_t *)dataout)->a_Major  = ELXSLI_DRIVER_MAJOR_VER;
          ((elxsliREVINFO_t *)dataout)->a_Minor  = ELXSLI_DRIVER_MINOR_VER;
          ((elxsliREVINFO_t *)dataout)->a_Build  = ELXSLI_DRIVER_BUILD_VER;
          cip->elxsli_outsz = sizeof(elxsliREVINFO_t);
          rc = 0;
          break;

      case ELXSLI_GET_HA_CNT:
          *((u32 *)dataout) = (u32)gElxSliHbaCount;
          PRINTK_DBG("ELX HA count = %d\n", gElxSliHbaCount);
          cip->elxsli_outsz = sizeof(u32);
          rc = 0;
          break;

      case ELXSLI_READ_PCI_CFG_SPACE:
          rc = elxsli_ioctl_read_pci_cfg_space(phba, cip, (u8 *)dataout);
          break;

      case ELXSLI_WRITE_PCI_CFG_SPACE:
          rc = elxsli_ioctl_write_pci_cfg_space(phba, cip);
          break;

      case ELXSLI_READ_PCI_CFG_BYTE:
          rc = elxsli_ioctl_read_pci_cfg_byte(phba, cip, (u8 *)dataout);
          break;

      case ELXSLI_READ_PCI_CFG_WORD:
          rc = elxsli_ioctl_read_pci_cfg_word(phba, cip, (u16 *)dataout);
          break;

      case ELXSLI_READ_PCI_CFG_DWORD:
          rc = elxsli_ioctl_read_pci_cfg_dword(phba, cip, (u32 *)dataout);
          break;

      case ELXSLI_WRITE_PCI_CFG_BYTE:
          rc = elxsli_ioctl_write_pci_cfg_byte(phba, cip);
          break;

      case ELXSLI_WRITE_PCI_CFG_WORD:
          rc = elxsli_ioctl_write_pci_cfg_word(phba, cip);
          break;

      case ELXSLI_WRITE_PCI_CFG_DWORD:
          rc = elxsli_ioctl_write_pci_cfg_dword(phba, cip);
          break;

      case ELXSLI_ALLOC_DMA_BUF:
          rc = elxsli_ioctl_alloc_dma_buffer(phba, cip, (u8 *)dataout);
          break;

      case ELXSLI_FREE_DMA_BUF:
          rc = elxsli_ioctl_free_dma_buffer(phba, cip);
          break;

      case ELXSLI_FREE_ALL_DMA_BUF:
          rc = elxsli_free_all_dma_buffers(phba);
          break;

      case ELXSLI_COPY_TO_USER:
          rc = elxsli_ioctl_copy_to_user(phba, cip, (u8 *)dataout);
          break;

      case ELXSLI_COPY_FROM_USER:
          rc = elxsli_ioctl_copy_from_user(phba, cip);
          break;

      default:
          rc = -EINVAL;
          break;
    }

    if (!rc) {
        /* copy the response data back to user space if required */
        if (cip->elxsli_outsz) {
            if (copy_to_user((u8 *)cip->elxsli_dataout,
                             (u8 *)dataout, (int)cip->elxsli_outsz))
                rc = -EIO;
        }
    } else {
        PRINT_LOG_MSG(phba, KERN_INFO, "ioctl returned rc = %x\n", rc);
    }

    mutex_unlock(&phba->elxsli_lock);
    kfree(dataout);
    return (rc);
}

/**
 * Function: elxsli_ioctl
 * Description: This routine is invoked when the user initiates an IOCTL
 * @param [in] - struct file* - file
 * @param [in] - unsigned int - cmd
 * @param [in] - unsigned long - arg
 * @return 0 - successful, other values - error
 */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,0,0)
static long elxsli_ioctl(struct file *file, unsigned int cmd,
                         unsigned long arg)
#else
static int elxsli_ioctl(struct inode *inode, struct file *file,
                        unsigned int cmd, unsigned long arg)
#endif
{
    ELXSLICMDINPUT_t *ci;
    int rc;

    if (!arg) {
        printk(KERN_WARNING "ELXSLI_IOCTL - no arg error\n");
        return (-EINVAL);
    }

    ci = (ELXSLICMDINPUT_t *)kzalloc(sizeof(ELXSLICMDINPUT_t), GFP_KERNEL);
    if (!ci) {
        return (-ENOMEM);
    }

    if ((rc = copy_from_user((u8 *)ci, (u8 *)arg, sizeof(ELXSLICMDINPUT_t)))) {
        printk(KERN_WARNING "ELXSLI_IOCTL copy_from_user error\n");
        kfree(ci);
        return (-EIO);
    }

    rc = elxsli_do_ioctl(ci);
    kfree(ci);
    return (rc);
}

#ifdef CONFIG_COMPAT
/**
 * Function: elxsli_compat_ioctl - driver IOCTL entrypoint
 * This routine is invoked when the user initiates an IOCTL
 * and we have a 32 vs 64 bit mismatch in mode between user and kernel.
 * @return 0 - successful, other values - error
 */
static long elxsli_compat_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    ELXSLICMDINPUT32_t arg32;
    ELXSLICMDINPUT_t arg64;
    int rc;

    if (!arg) {
        return (-EINVAL);
    }

    if ((rc = copy_from_user(&arg32, (void *)arg,
                             sizeof(ELXSLICMDINPUT32_t)))) {
        return (-EIO);
    }

    arg64.elxsli_index = arg32.elxsli_index;
    arg64.elxsli_flag = arg32.elxsli_flag;
    arg64.elxsli_arg1 = (void *)(unsigned long)arg32.elxsli_arg1;
    arg64.elxsli_arg2 = (void *)(unsigned long)arg32.elxsli_arg2;
    arg64.elxsli_arg3 = (void *)(unsigned long)arg32.elxsli_arg3;
    arg64.elxsli_dataout = (void *)(unsigned long)arg32.elxsli_dataout;
    arg64.elxsli_cmd = arg32.elxsli_cmd;
    arg64.elxsli_outsz = arg32.elxsli_outsz;

    rc = elxsli_do_ioctl(&arg64);

    arg32.elxsli_index = arg64.elxsli_index;
    arg32.elxsli_flag = arg64.elxsli_flag;
    arg32.elxsli_arg1 = (u32)(unsigned long)arg64.elxsli_arg1;
    arg32.elxsli_arg2 = (u32)(unsigned long)arg64.elxsli_arg2;
    arg32.elxsli_arg3 = (u32)(unsigned long)arg64.elxsli_arg3;
    arg32.elxsli_dataout = (u32)(unsigned long)arg64.elxsli_dataout;
    arg32.elxsli_cmd = arg64.elxsli_cmd;
    arg32.elxsli_outsz = arg64.elxsli_outsz;

    if (copy_to_user((void *)arg, &arg32,
                     sizeof(ELXSLICMDINPUT32_t))) {
        return (-EIO);
    }

    return (rc);
}
#endif

int elxsli_release(struct inode *node, struct file *fp)
{
    //elxsli_uninit();
    return (0);
}

static struct file_operations elxsli_fops =
{
    .owner = THIS_MODULE,
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,0,0)
    .unlocked_ioctl = elxsli_ioctl,
#else
    .ioctl = elxsli_ioctl,
#endif
#ifdef CONFIG_COMPAT
    .compat_ioctl = elxsli_compat_ioctl,
#endif
    .release = elxsli_release,
};

/**
 * Function: elxsli_cdev_init - Initial driver entrypoint
 * This routine is invoked when the driver is loaded
 * @return 0 - successful, other values - error
 */
static int __init elxsli_cdev_init(void)
{
    if (elxsli_baronly) {
        printk(ELXSLI_MODULE_DESC " - BAR only\n");
    } else {
        printk(ELXSLI_MODULE_DESC "\n");
    }
    printk(ELXSLI_COPYRIGHT "\n");

    elxsli_major = register_chrdev(0, ELXSLI_DRIVER_NAME, &elxsli_fops);
    if (elxsli_major < 0) {
        printk(KERN_WARNING "%s: unable to register \"%s\" device\n", __FUNCTION__, ELXSLI_DRIVER_NAME);
        return (elxsli_major);
    }

    elxsli_loadtime = jiffies;
    elxsli_init();
    return (0);
}

/**
 * Function: elxsli_cdev_exit - driver unload entrypoint
 * This routine is invoked when the user initiates a driver unload
 */
static void __exit elxsli_cdev_exit(void)
{
    elxsli_uninit();
    unregister_chrdev(elxsli_major, ELXSLI_DRIVER_NAME);
}

module_init(elxsli_cdev_init);
module_exit(elxsli_cdev_exit);




