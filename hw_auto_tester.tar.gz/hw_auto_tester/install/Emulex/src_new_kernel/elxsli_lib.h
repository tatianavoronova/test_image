/*************************************************************************
 * Broadcom Inc. Copyright (c) 2020 Broadcom.
 * All Rights Reserved.
 * The term "Broadcom" refers to Broadcom Inc. and/or its subsidiaries.
 *************************************************************************/
// File: elxsli_lib.h

#include <list.h>
#include "elxsli_ioctl.h"
#include "elxsli_version.h"

#include <byteswap.h>
#undef __LITTLE_ENDIAN
#undef __BIG_ENDIAN

#include <asm/types.h>

#ifdef __CHECKER__
#define __bitwise__ __attribute__((bitwise))
#else
#define __bitwise__
#endif
#ifdef __CHECK_ENDIAN__
#define __bitwise __bitwise__
#else
#define __bitwise
#endif

typedef __u32 __bitwise __le32;

/*
 * Defines for library version get updated from top level Makefile
 * to match elxsli_version.h
 */
#define ELXSLI_LIB_MAJOR_VER ELXSLI_DRIVER_MAJOR_VER
#define ELXSLI_LIB_MINOR_VER ELXSLI_DRIVER_MINOR_VER
#define ELXSLI_LIB_BUILD_VER ELXSLI_DRIVER_BUILD_VER

#define ELXSLI_LIB_VER_BUF_LEN  20

/* Defines for error codes */

#define ELXSLI_ERR_GENERAL_ERROR             0x1
#define ELXSLI_ERR_MBOX_ERROR                0x2
#define ELXSLI_ERR_INCORRECT_VER             0x2
#define ELXSLI_ERR_INVALID_ID                0x2
#define ELXSLI_ERR_TIMEOUT                   0x2
#define ELXSLI_ERR_BUFFER_OVERFLOW           0x3
#define ELXSLI_ERR_NO_RPI                    0x3
#define ELXSLI_ERR_INVALID_LOOPBACK_TYPE     0x3
#define ELXSLI_ERR_NOT_SUPPORTED             0x4
#define ELXSLI_ERR_INVALID_RESET_TYPE        0x4
#define ELXSLI_ERR_NO_XMIT                   0x6

#if defined __BIG_ENDIAN__ || defined _BIG_ENDIAN
#define __LITTLE_ENDIAN   0      /* Host bit ordering - set to 0 or 1 */
#define __BIG_ENDIAN      1
#define __BIG_ENDIAN_BITFIELD 1
#define SWAP_BYTES32(x) (x)
#define SWAP_BYTES16(x) (x)
#define SWAP_PCIMEM32(x) bswap_32(x)
#else
#define __LITTLE_ENDIAN   1      /* Host bit ordering - set to 0 or 1 */
#define __BIG_ENDIAN      0
#define __LITTLE_ENDIAN_BITFIELD 1
#define SWAP_BYTES32(x) bswap_32(x)
#define SWAP_BYTES16(x) bswap_16(x)
#define SWAP_PCIMEM32(x) (x)
#endif


