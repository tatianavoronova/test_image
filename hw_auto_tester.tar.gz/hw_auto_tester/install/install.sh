#!/bin/bash

### Script should be runned on Ubuntu 22.04

# On host: Copy installation scripts and sources 
cd hw_auto_tester
rsync -avz ./ --exclude-from=rex.txt ubuntu@192.168.138.50:./hw_auto_tester

ssh ubuntu@192.168.138.50
sudo -s

######################## On target 
# Remove asking password
echo "ubuntu ALL=(ALL) NOPASSWD:ALL" | sudo tee "/etc/sudoers.d/ubuntu"

######## Install software
# Add repos
add-apt-repository main
add-apt-repository universe
add-apt-repository restricted
add-apt-repository multiverse 

export DEBIAN_FRONTEND="noninteractive"
apt-get update -y -q

apt-get install -y -q vim \
    stress-ng \
    python3-pip \
    inxi \
    ipmitool \
    smartmontools \
    libreoffice-calc

pip install openpyxl pyoo

ssh-keygen 
# save generated "/root/.ssh/id_rsa.pub" to install in .ssh/athorizes_keys on report_server

# Make user ubuntu user runs ./hw_auto_tester/autostart.sh on booting
...

# Compile and install emulex driver
mkdir /home/ubuntu/Emulex
cp -a hw_auto_tester/install/Emulex/elxmctp-bin /home/ubuntu/Emulex

# Compile emulex driver
cd Install/Emulex/src_new_kernel 
install gcc-13
make install
# Install emulex driver


# make sure /home/ubuntu/hw_auto_tester