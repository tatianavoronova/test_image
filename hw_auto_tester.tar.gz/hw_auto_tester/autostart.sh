#!/bin/bash 

echo "Start run $(date)" > /home/ubuntu/run.log

# Get server SN 
SN=$(sudo inxi -Fx | grep -m 1 serial | awk -F: '{print $2}'| xargs | tr -d ' ')
FILE_Log="reports_raw/smart_rack_$(date +%Y%m%d_%H%M%S)_${SN}.log"

# Rederict stdout and stderr to logfile
exec > >(tee -a "${FILE_Log}" )
exec 2> >(tee -a "${FILE_Log}" >&2)

# Log its SN to remote server
ssh report-server -o ConnectTimeout=30 -o StrictHostKeyChecking=accept-new  "echo $SN >> ./ssh_ok_serials.log" 

# Rsync files and run install.sh from report-server
rsync -rzav report-server:./hw_auto_tester /home/ubuntu/
chmod +x /home/ubuntu/hw_auto_tester/*.sh
#/home/ubuntu/hw_auto_tester/install.sh

# Run auto tests
#cd ./hw_auto_tester
./run_auto_tests.sh
echo "End run $(date)" >> /home/ubuntu/run.log
