import pyoo
import sys
import time

file_path = sys.argv[1]
desktop = pyoo.Desktop('localhost', 2002)

print(f"Open {file_path} with libreoffice")
doc = desktop.open_spreadsheet(file_path)

time.sleep(5)
print(f"Saving file")
doc.save()
time.sleep(3)
print(f"Closing file")
doc.close()
