import os
import openpyxl
from datetime import datetime
import subprocess
import time
import glob
import re
import sys

# Updates
# rsync timeout 30 sec
# rsync only one report
# write commands in report (A columns) B for logs
# removed sudo in commands
# Reports renamed to usb_reports    

REMOTE_FOLDER = 'ubuntu@192.168.1.250:./server_reports'
FOLDER_FOR_MOUNT_USB = "usb_reports"
FOLDER_FOR_TEST_REPORTS = 'reports'
FOLDER_FOR_TEST_TEMPLATES = 'reports_templates'
FOLDER_FOR_TEST_RAW_DATA = 'reports_raw'

# CONF_1_2U2N = "ACH2120A-23001" 
# CONF_1_2U1N = "ACH1120C-23001" 
# CONF_2_2U1N = "ACH1120C-23002" 

STRESS_TIME = "900s"
DEFAULT_PN = 'ACH1120C-23002'


if '--debug' in sys.argv:
    print("DEBUG=TRUE")
    STRESS_TIME = "10s"


NOW_STR = time.strftime('%d.%m.%Y_%H-%M')
RAW_REPORT_FILE = f"{FOLDER_FOR_TEST_RAW_DATA}/report_raw_{NOW_STR}.log"

def run_shell_cmd(cmd):
    p_finished = subprocess.run(cmd, shell=True, text=True, capture_output=True)
    p_output = p_finished.stdout + p_finished.stderr
    # save raw reports
    with open(RAW_REPORT_FILE, 'a') as f:
        f.write(f'### CMD: {cmd} ### OUTPUT:\n')
        f.write(p_output)
    return p_output

def run_shell_commands(commands):
    cmd_log_list = []
    for cmd in commands.strip().split('\n'):
        cmd = cmd.strip()
        if not cmd:
            continue # Skip empty strings
        print(cmd)
        log = run_shell_cmd(cmd).split('\n')
        cmd_log_list.append({"cmd": cmd, "log": log})
    return cmd_log_list


def rsync_reports_to_remote_server(report_path):
    cmd = f'rsync -rzav {report_path} {FOLDER_FOR_TEST_RAW_DATA} {REMOTE_FOLDER} --timeout 30 2>&1'
    print(cmd)
    result = run_shell_cmd(cmd)
    print('rsync result:', result)
    if 'error' in result:
        return False
    else:
        return True


def main():                 
    if not os.path.exists(FOLDER_FOR_TEST_REPORTS):
        os.makedirs(FOLDER_FOR_TEST_REPORTS)

    file_name, file_date = find_xlsx()
    print("V 5.5")
    print("Uploaded a file to work :\n", file_name, 
           'The date of last changes:', file_date, "\n")

    print("Start tests one by one")
    logs_data_bmc = bmc_tests()
    logs_data_id_common   = id_common_tests()
    logs_data_id_cpu      = id_cpu_tests()
    logs_data_id_discs    = id_discs_tests()
    logs_data_id_memory   = id_memory_tests()
    logs_data_id_ethernet = id_ethernet_tests()
    logs_data_load        = stress_test()
    report_path = save_log_xsls(logs_data_bmc, 
        logs_data_id_common, 
        logs_data_id_cpu, 
        logs_data_id_discs, 
        logs_data_id_memory, 
        logs_data_id_ethernet, 
        logs_data_load)
    errors = open_and_read_errors_count(report_path)

    if not rsync_reports_to_remote_server(report_path):
        copy_and_past_to_usb_disc(report_path)
    else: 
        shutdown_server()
    
    input("The work of the program is completed.")

def bmc_tests():            
    print("Start BMC test.")
    commands = """
    ipmitool mc info
    ipmitool getsysinfo system_fw_version    
    ipmitool sdr
    ipmitool sensor
    ipmitool fru
    ipmitool fru print 1
    ipmitool dcmi sensors
    ipmitool dcmi get_temp_reading
    ipmitool dcmi get_mc_id_string
    ipmitool nm alert get
    ipmitool lan print
    #ipmitool chassis identify 255
    """
    cmd_log_list = run_shell_commands(commands) 
    print('\nCheck the flashing of the blue LED on the front panel. LED will be blinling about 4,5 minuts.\n')
    return cmd_log_list

def id_common_tests(): 
    print("Start reading data from commodity.", "\n")   
    return run_shell_commands("inxi -Fx")

def id_cpu_tests():         
    print("Start reading data from CPU.")
    return run_shell_commands('lscpu')


def id_discs_tests():       
    print("Start reading data from discs.")
    commands = """
    mdadm --detail --scan --verbose
    mdadm -D /dev/md125
    mdadm -D /dev/md126
    mdadm -D /dev/md127
    lsblk
    smartctl --scan
    smartctl -a /dev/sd
    """.strip()
    for letter in 'abcdefghijklmnopqrstuvwxyz':
        commands += f"smartctl -a /dev/sd{letter}\n"
    for num in range(0, 15+1):
        commands += f"smartctl -a /dev/nvme{num}\n"
    return run_shell_commands(commands) 

def id_memory_tests():      
    print("Start reading data from DIMM memory.")
    return run_shell_commands("dmidecode -t memory")

def id_ethernet_tests():    
    print("Start reading data from pci ethernet cards.")
    commands = """
    lspci -v -mm -nn
    ip address
    /home/ubuntu/Emulex/elxmctp-bin -q
    """
    return run_shell_commands(commands)

def stress_test():           
    print(f"Start stress tests {STRESS_TIME}.")
    commands = f"""
    ipmitool sensor
    nproc
    stress-ng --cpu $(nproc) --vm 1 --vm-bytes 80% --iomix $(nproc) --metrics-brief --timeout {STRESS_TIME} --metrics-brief
    ipmitool sensor
    nproc
    """
    return run_shell_commands(commands)

def write_cmd_log_to_sheet(cmd_log_list, sheet):
    row_i = 1
    for cmd_log in cmd_log_list:
        sheet[f'A{row_i}'] = cmd_log["cmd"]
        for log_line in cmd_log["log"]:
            sheet[f'B{row_i}'] = log_line
            row_i+=1

def get_server_sn():
    log = run_shell_cmd("inxi -Fx | grep -m 1 serial | awk -F: '{print $2}'")
    # Replace with _ chars which can not be used in file path
    server_sn = re.sub(r'[^\w_.-]', '_', log.strip()) 
    print(f"Server SN: {server_sn}")
    return server_sn

def get_server_pn():
    log = run_shell_cmd("ipmitool fru print 1 2>&1 | grep -m 1 'Product Part Number' | awk -F: '{print $2}'")
    # Replace with _ chars which can not be used in file path
    server_pn = re.sub(r'[^\w_.-]', '_', log.strip()) 
    if not server_pn:
        server_pn = DEFAULT_PN
    print(f"Server PN: {server_pn}")
    return server_pn

def server_led_off():
    print("Server led off")
    run_shell_cmd("ipmitool chassis identify 0")

def server_led_blinking():
    print("Server led blinking")
    run_shell_cmd("ipmitool chassis identify 10")

def save_log_xsls(logs_data_bmc, logs_data_id_common, logs_data_id_cpu, logs_data_id_discs, logs_data_id_memory, logs_data_id_ethernet, logs_data_load): 
    print("Save report to a local forder.")
    file_name, _ = find_xlsx()
    print('Path to template:', file_name)
    wb = openpyxl.load_workbook(file_name)

    write_cmd_log_to_sheet(logs_data_bmc, wb['logs_data_bmc'])
    write_cmd_log_to_sheet(logs_data_id_common, wb['logs_data_id_common'])
    write_cmd_log_to_sheet(logs_data_id_cpu, wb['logs_data_id_cpu'])
    write_cmd_log_to_sheet(logs_data_id_discs, wb['logs_data_id_discs'])
    write_cmd_log_to_sheet(logs_data_id_memory, wb['logs_data_id_memory'])
    write_cmd_log_to_sheet(logs_data_id_ethernet, wb['logs_data_id_ethernet'])
    write_cmd_log_to_sheet(logs_data_load, wb['logs_data_load'])

    server_sn = get_server_sn()

    report_name = f"Smart_Rack_report_{server_sn}_{NOW_STR}.xlsx"
    report_path = os.path.join(FOLDER_FOR_TEST_REPORTS, report_name)
    wb.active = 0
    wb.save(report_path)
    print('./office-recalc.sh', report_path)
    subprocess.run(["sudo", './office-recalc.sh', report_path])  
    return report_path


def open_and_read_errors_count(report_path):
    wb = openpyxl.load_workbook(report_path, data_only=True)
    try:
        errors_count = int(wb['report']['G3'].value)
    except Exception as e:
        errors_count = -1
    with open(RAW_REPORT_FILE, 'a') as f:
        f.write(f'### EXCEL_ERROR_COUNT: {errors_count}\n')
    return errors_count

def shutdown_server():
    print("Server will shutdown in 30 seconds.\n")
    run_shell_commands("shutdown -h now")

    
def find_xlsx():
    files = glob.glob(os.path.join(FOLDER_FOR_TEST_TEMPLATES, "*.xlsx"))
    files.sort(key=lambda x: os.path.getmtime(x))
    print('all_templates', files)
    server_pn = get_server_pn()

    files_with_pn = list(filter(lambda x: server_pn in x, files))
    print('files_with_pn', files_with_pn)

    if len(files_with_pn) == 0:
        print("Folder to search reports templates is: \n", FOLDER_FOR_TEST_TEMPLATES)
        print(f'No files with extension .xlsx and containing "{server_pn}"! \n')
        input("Press any key to exit")
        exit(1)

    file_path = files_with_pn[-1] # Get last updated file
    ctime = os.path.getctime(file_path)
    file_date = datetime.fromtimestamp(ctime).strftime('%d.%m.%Y %H:%M')
    return file_path, file_date

def copy_and_past_to_usb_disc(report_path):    
    print("\nStart copy folders.")
    print("Tern on led = I am ready for copy logs.", 
            "I`m wating for plug in USB disc...", "\n")
    all_disc = []
    all_disc_and_usb = []
    path_to_usb = []
    all_disc_and_usb_source = []
    all_disc_and_usb_target = []
    usb_mount_dir = os.path.join(os.getcwd(), FOLDER_FOR_MOUNT_USB)
    print('usb_mount_dir', usb_mount_dir)
    while len(all_disc) != len(all_disc_and_usb)-1 :
        all_disc.clear()
        all_disc_and_usb.clear()

        list_dics = subprocess.run(["df", '--output=source,target'], capture_output=True)
        list_dics_decode = list_dics.stdout.decode()
        list_dics_decode_str = ''.join(list_dics_decode)
        all_disc = list_dics_decode_str.splitlines()

        log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'chassis', "identify", "10"], capture_output=True)
        if not os.path.exists(usb_mount_dir):
            os.makedirs(usb_mount_dir)
        subprocess.run(["sudo", 'mount', "/dev/sdb1", usb_mount_dir], capture_output=True)
        time.sleep(2)

        list_dics_and_usb = subprocess.run(["df", '--output=source,target'], capture_output=True)
        list_dics_and_usb_decode = list_dics_and_usb.stdout.decode()
        list_dics_and_usb_decode_str = ''.join(list_dics_and_usb_decode)
        all_disc_and_usb = list_dics_and_usb_decode_str.splitlines()

    path_to_usb = list(set(all_disc_and_usb) - set(all_disc))
    path_to_usb_str = "".join(path_to_usb)
    list_dics_and_usb_split = path_to_usb_str.split(" ", 1)
    all_disc_and_usb_source.append(list_dics_and_usb_split[0])
    all_disc_and_usb_target.append(list_dics_and_usb_split[1])
    all_disc_and_usb_target_str = ''.join(all_disc_and_usb_target)
    path_to_usb_clear = all_disc_and_usb_target_str.replace(' ', '')
    if not os.path.exists(path_to_usb_clear):
        os.makedirs(usb_mount_dir)
        z = subprocess.run(["sudo", 'mount', all_disc_and_usb_source, FOLDER_FOR_MOUNT_USB], capture_output=True)
        copy_folder = os.path.join(os.getcwd(), FOLDER_FOR_TEST_REPORTS, ".")
        past_folder = os.path.join(FOLDER_FOR_MOUNT_USB, FOLDER_FOR_TEST_REPORTS)
        print ("Usb was founded and mounted to: ", past_folder)
        print(subprocess.run(['cp', "-a", copy_folder, past_folder], capture_output=True))
    else:
        copy_folder = os.path.join(os.getcwd(), FOLDER_FOR_TEST_REPORTS, ".")
        past_folder = os.path.join(path_to_usb_clear, FOLDER_FOR_TEST_REPORTS)
        print ("Usb was founded: ", past_folder)
        print(subprocess.run(['cp', "-a", copy_folder, past_folder], capture_output=True))
    print ("Copy folder: ", copy_folder)
    print ("Past folder: ", past_folder)
    basename_log_file = os.path.basename(report_path)
    past_folder_basename_log_file = os.path.join(past_folder, basename_log_file)
    if not os.path.exists(past_folder_basename_log_file):
        print("Houston we have problems! I can`t find reports on your USB disc.", "\n" "Do it yousef I can`t.", "\n")
        time.sleep (10)
    else:
        log_ipmitool = subprocess.run(["sudo", 'ipmitool', 'chassis', "identify", "0"], capture_output=True)
        print("Tern off led = copy finished.", "\n")
        shutdown_server()
    return past_folder

if __name__ == "__main__":
    main()
