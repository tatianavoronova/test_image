#!/bin/bash 


# Define the source directory where your SSH files are located
SOURCE_DIR="./update_files/.ssh"

# Define the target directory
TARGET_DIR="/home/ubuntu/.ssh"

# Create the .ssh directory if it doesn't exist
if [ ! -d "$TARGET_DIR" ]; then
    mkdir -p "$TARGET_DIR"
    echo "Created $TARGET_DIR"
fi

# Copy the SSH files to the target directory
cp -r "$SOURCE_DIR/." "$TARGET_DIR/"
echo "Copied SSH files to $TARGET_DIR"

# Set the correct permissions for the .ssh directory and its contents
chmod 700 "$TARGET_DIR"
chmod 600 "$TARGET_DIR/id_rsa" "$TARGET_DIR/id_rsa.pub" "$TARGET_DIR/known_hosts"
echo "Set permissions for SSH files"

# Change the ownership to the ubuntu user
chown -R ubuntu:ubuntu "$TARGET_DIR"
echo "Changed ownership of $TARGET_DIR to ubuntu user"

echo "SSH setup complete!"

# Update oher scripts
cp run_auto_tests.sh /home/ubuntu/hw_auto_tester/
cp autostart.sh /home/ubuntu/hw_auto_tester/
cd /home/ubuntu/hw_auto_tester/
chmod +x *.sh
